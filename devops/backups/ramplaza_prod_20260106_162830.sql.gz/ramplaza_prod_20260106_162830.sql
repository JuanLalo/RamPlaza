-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: ram_plaza
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `address_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_address_id` int unsigned DEFAULT NULL,
  `customer_id` int unsigned DEFAULT NULL COMMENT 'null if guest checkout',
  `cart_id` int unsigned DEFAULT NULL COMMENT 'only for cart_addresses',
  `order_id` int unsigned DEFAULT NULL COMMENT 'only for order_addresses',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `vat_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_address` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'only for customer_addresses',
  `use_for_shipping` tinyint(1) NOT NULL DEFAULT '0',
  `additional` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `addresses_customer_id_foreign` (`customer_id`),
  KEY `addresses_cart_id_foreign` (`cart_id`),
  KEY `addresses_order_id_foreign` (`order_id`),
  KEY `addresses_parent_address_id_foreign` (`parent_address_id`),
  CONSTRAINT `addresses_cart_id_foreign` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `addresses_parent_address_id_foreign` FOREIGN KEY (`parent_address_id`) REFERENCES `addresses` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_password_resets`
--

DROP TABLE IF EXISTS `admin_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `admin_password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_password_resets`
--

LOCK TABLES `admin_password_resets` WRITE;
/*!40000 ALTER TABLE `admin_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_token` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` int unsigned NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`),
  UNIQUE KEY `admins_api_token_unique` (`api_token`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'johns','johnsberd@gmail.com','$2y$12$HicVlrdJOceEbERCFR/mZ.GVjB7vGMUJH64Dq0.j8Rw1rL.sZoEvy','6YaDHN1fiocNHySVWFjRGIRf8ydNDZIDlxKc5SsL3bOADtC9HLaz1gXWgKoDck4BxA0qZu76YSRoqxmg',1,1,NULL,NULL,'2025-12-11 21:04:10','2026-01-04 16:53:25'),(2,'Esaú Sánchez','esau.sanchez@feengster.com','$2y$12$duvHNbO0MTopekKSXfKGaeRrX/YjPYQc.x79Q7.l/hVHga1uvG79e','ZZLcM7XDH0oWk71WClqVVKGkuB93btxV1Rrp2wrFZZxJWzGpaGVfwMq5GUoo32QoOdzzRGnsHhgJ6H7D',1,1,NULL,NULL,'2025-12-24 13:36:00','2025-12-29 08:59:13'),(4,'Paulina','paulina.mosqueda@feengster.com','$2y$12$ZtAdMlJLoik/wQ088kK0c.T.qH58ZZFvg7EhlqUxn5JKDS3nTlFLu','wdf4WPivW5il4V5H8r6YJIdBjfkXdLbU2c8GYkafzBloDnAWq2ZtZtrnbzqblfK1Nc8TYtBRPFJ57fnp',1,1,NULL,NULL,'2025-12-27 23:22:54','2025-12-27 23:23:02');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute_families`
--

DROP TABLE IF EXISTS `attribute_families`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_families` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `is_user_defined` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_families`
--

LOCK TABLES `attribute_families` WRITE;
/*!40000 ALTER TABLE `attribute_families` DISABLE KEYS */;
INSERT INTO `attribute_families` VALUES (1,'default','RAM',0,1);
/*!40000 ALTER TABLE `attribute_families` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute_group_mappings`
--

DROP TABLE IF EXISTS `attribute_group_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_group_mappings` (
  `attribute_id` int unsigned NOT NULL,
  `attribute_group_id` int unsigned NOT NULL,
  `position` int DEFAULT NULL,
  PRIMARY KEY (`attribute_id`,`attribute_group_id`),
  KEY `attribute_group_mappings_attribute_group_id_foreign` (`attribute_group_id`),
  CONSTRAINT `attribute_group_mappings_attribute_group_id_foreign` FOREIGN KEY (`attribute_group_id`) REFERENCES `attribute_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `attribute_group_mappings_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_group_mappings`
--

LOCK TABLES `attribute_group_mappings` WRITE;
/*!40000 ALTER TABLE `attribute_group_mappings` DISABLE KEYS */;
INSERT INTO `attribute_group_mappings` VALUES (1,1,1),(2,1,3),(3,1,4),(4,1,5),(5,6,1),(6,6,2),(7,6,3),(8,6,4),(9,2,1),(10,2,2),(11,4,1),(12,4,2),(13,4,3),(14,4,4),(15,4,5),(16,3,1),(17,3,2),(18,3,3),(19,5,1),(20,5,2),(21,5,3),(22,5,4),(23,1,6),(24,1,7),(25,1,8),(26,6,5),(27,1,2),(28,7,1);
/*!40000 ALTER TABLE `attribute_group_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute_groups`
--

DROP TABLE IF EXISTS `attribute_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_family_id` int unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `column` int NOT NULL DEFAULT '1',
  `position` int NOT NULL,
  `is_user_defined` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `attribute_groups_attribute_family_id_name_unique` (`attribute_family_id`,`name`),
  CONSTRAINT `attribute_groups_attribute_family_id_foreign` FOREIGN KEY (`attribute_family_id`) REFERENCES `attribute_families` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_groups`
--

LOCK TABLES `attribute_groups` WRITE;
/*!40000 ALTER TABLE `attribute_groups` DISABLE KEYS */;
INSERT INTO `attribute_groups` VALUES (1,'general',1,'General',1,1,0),(2,'description',1,'Descripción',1,2,0),(3,'meta_description',1,'Meta Descripción',1,3,0),(4,'price',1,'Precio',2,1,0),(5,'shipping',1,'Envío',2,2,0),(6,'settings',1,'Configuraciones',2,3,0),(7,'inventories',1,'Inventarios',2,4,0);
/*!40000 ALTER TABLE `attribute_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute_option_translations`
--

DROP TABLE IF EXISTS `attribute_option_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_option_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `attribute_option_id` int unsigned NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attribute_option_locale_unique` (`attribute_option_id`,`locale`),
  CONSTRAINT `attribute_option_translations_attribute_option_id_foreign` FOREIGN KEY (`attribute_option_id`) REFERENCES `attribute_options` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_option_translations`
--

LOCK TABLES `attribute_option_translations` WRITE;
/*!40000 ALTER TABLE `attribute_option_translations` DISABLE KEYS */;
INSERT INTO `attribute_option_translations` VALUES (1,1,'es','Rojo'),(2,2,'es','Verde'),(3,3,'es','Amarillo'),(4,4,'es','Negro'),(5,5,'es','Blanco'),(6,6,'es','S'),(7,7,'es','M'),(8,8,'es','L'),(9,9,'es','XL');
/*!40000 ALTER TABLE `attribute_option_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute_options`
--

DROP TABLE IF EXISTS `attribute_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_options` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `attribute_id` int unsigned NOT NULL,
  `admin_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  `swatch_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_options_attribute_id_foreign` (`attribute_id`),
  CONSTRAINT `attribute_options_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_options`
--

LOCK TABLES `attribute_options` WRITE;
/*!40000 ALTER TABLE `attribute_options` DISABLE KEYS */;
INSERT INTO `attribute_options` VALUES (1,23,'Rojo',1,NULL),(2,23,'Verde',2,NULL),(3,23,'Amarillo',3,NULL),(4,23,'Negro',4,NULL),(5,23,'Blanco',5,NULL),(6,24,'S',1,NULL),(7,24,'M',2,NULL),(8,24,'L',3,NULL),(9,24,'XL',4,NULL);
/*!40000 ALTER TABLE `attribute_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attribute_translations`
--

DROP TABLE IF EXISTS `attribute_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attribute_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `attribute_id` int unsigned NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attribute_translations_attribute_id_locale_unique` (`attribute_id`,`locale`),
  CONSTRAINT `attribute_translations_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attribute_translations`
--

LOCK TABLES `attribute_translations` WRITE;
/*!40000 ALTER TABLE `attribute_translations` DISABLE KEYS */;
INSERT INTO `attribute_translations` VALUES (1,1,'es','SKU'),(2,2,'es','Nombre'),(3,3,'es','Clave de URL'),(4,4,'es','Categoría de Impuestos'),(5,5,'es','Nuevo'),(6,6,'es','Destacado'),(7,7,'es','Visible Individualmente'),(8,8,'es','Estado'),(9,9,'es','Descripción Corta'),(10,10,'es','Descripción'),(11,11,'es','Precio'),(12,12,'es','Costo'),(13,13,'es','Precio Especial'),(14,14,'es','Precio Especial Desde'),(15,15,'es','Precio Especial Hasta'),(16,16,'es','Meta Título'),(17,17,'es','Meta Palabras Clave'),(18,18,'es','Meta Descripción'),(19,19,'es','Longitud'),(20,20,'es','Ancho'),(21,21,'es','Altura'),(22,22,'es','Peso'),(23,23,'es','Color'),(24,24,'es','Tamaño'),(25,25,'es','Marca'),(26,26,'es','Compra de Invitado'),(27,27,'es','Número de Producto'),(28,28,'es','Gestionar Stock');
/*!40000 ALTER TABLE `attribute_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attributes`
--

DROP TABLE IF EXISTS `attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attributes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `swatch_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `regex` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` int DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '0',
  `is_unique` tinyint(1) NOT NULL DEFAULT '0',
  `is_filterable` tinyint(1) NOT NULL DEFAULT '0',
  `is_comparable` tinyint(1) NOT NULL DEFAULT '0',
  `is_configurable` tinyint(1) NOT NULL DEFAULT '0',
  `is_user_defined` tinyint(1) NOT NULL DEFAULT '1',
  `is_visible_on_front` tinyint(1) NOT NULL DEFAULT '0',
  `value_per_locale` tinyint(1) NOT NULL DEFAULT '0',
  `value_per_channel` tinyint(1) NOT NULL DEFAULT '0',
  `default_value` int DEFAULT NULL,
  `enable_wysiwyg` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `attributes_code_unique` (`code`),
  KEY `attributes_code_index` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attributes`
--

LOCK TABLES `attributes` WRITE;
/*!40000 ALTER TABLE `attributes` DISABLE KEYS */;
INSERT INTO `attributes` VALUES (1,'sku','SKU','text',NULL,NULL,NULL,1,1,1,0,0,0,0,0,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(2,'name','Nombre','text',NULL,NULL,NULL,3,1,0,0,1,0,0,0,1,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(3,'url_key','Clave de URL','text',NULL,NULL,NULL,4,1,1,0,0,0,0,0,1,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(4,'tax_category_id','Categoría de Impuestos','select',NULL,NULL,NULL,5,0,0,0,0,0,0,0,0,1,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(5,'new','Nuevo','boolean',NULL,NULL,NULL,6,0,0,0,0,0,0,0,0,0,1,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(6,'featured','Destacado','boolean',NULL,NULL,NULL,7,0,0,0,0,0,0,0,0,0,1,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(7,'visible_individually','Visible Individualmente','boolean',NULL,NULL,NULL,9,1,0,0,0,0,0,0,0,0,1,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(8,'status','Estado','boolean',NULL,NULL,NULL,10,1,0,0,0,0,0,0,0,1,1,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(9,'short_description','Descripción Corta','textarea',NULL,NULL,NULL,11,1,0,0,0,0,0,0,1,0,NULL,1,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(10,'description','Descripción','textarea',NULL,NULL,NULL,12,1,0,0,1,0,0,0,1,0,NULL,1,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(11,'price','Precio','price',NULL,'decimal',NULL,13,1,0,1,1,0,0,0,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(12,'cost','Costo','price',NULL,'decimal',NULL,14,0,0,0,0,0,1,0,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(13,'special_price','Precio Especial','price',NULL,'decimal',NULL,15,0,0,0,0,0,0,0,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(14,'special_price_from','Precio Especial Desde','date',NULL,NULL,NULL,16,0,0,0,0,0,0,0,0,1,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(15,'special_price_to','Precio Especial Hasta','date',NULL,NULL,NULL,17,0,0,0,0,0,0,0,0,1,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(16,'meta_title','Meta Título','textarea',NULL,NULL,NULL,18,0,0,0,0,0,0,0,1,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(17,'meta_keywords','Meta Palabras Clave','textarea',NULL,NULL,NULL,20,0,0,0,0,0,0,0,1,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(18,'meta_description','Meta Descripción','textarea',NULL,NULL,NULL,21,0,0,0,0,0,1,0,1,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(19,'length','Longitud','text',NULL,'decimal',NULL,22,0,0,0,0,0,1,0,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(20,'width','Ancho','text',NULL,'decimal',NULL,23,0,0,0,0,0,1,0,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(21,'height','Altura','text',NULL,'decimal',NULL,24,0,0,0,0,0,1,0,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(22,'weight','Peso','text',NULL,'decimal',NULL,25,1,0,0,0,0,0,0,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(23,'color','Color','select',NULL,NULL,NULL,26,0,0,1,0,1,1,0,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(24,'size','Tamaño','select',NULL,NULL,NULL,27,0,0,1,0,1,1,0,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(25,'brand','Marca','select',NULL,NULL,NULL,28,0,0,1,0,0,1,1,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(26,'guest_checkout','Compra de Invitado','boolean',NULL,NULL,NULL,8,1,0,0,0,0,0,0,0,0,1,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(27,'product_number','Número de Producto','text',NULL,NULL,NULL,2,0,1,0,0,0,0,0,0,0,NULL,0,'2025-12-11 21:04:07','2025-12-11 21:04:07'),(28,'manage_stock','Gestionar Stock','boolean',NULL,NULL,NULL,1,0,0,0,0,0,0,0,0,1,1,0,'2025-12-11 21:04:07','2025-12-11 21:04:07');
/*!40000 ALTER TABLE `attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_product_appointment_slots`
--

DROP TABLE IF EXISTS `booking_product_appointment_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_product_appointment_slots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_product_id` int unsigned NOT NULL,
  `duration` int DEFAULT NULL,
  `break_time` int DEFAULT NULL,
  `same_slot_all_days` tinyint(1) DEFAULT NULL,
  `slots` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_product_appointment_slots_booking_product_id_foreign` (`booking_product_id`),
  CONSTRAINT `booking_product_appointment_slots_booking_product_id_foreign` FOREIGN KEY (`booking_product_id`) REFERENCES `booking_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_product_appointment_slots`
--

LOCK TABLES `booking_product_appointment_slots` WRITE;
/*!40000 ALTER TABLE `booking_product_appointment_slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_product_appointment_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_product_default_slots`
--

DROP TABLE IF EXISTS `booking_product_default_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_product_default_slots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_product_id` int unsigned NOT NULL,
  `booking_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `duration` int DEFAULT NULL,
  `break_time` int DEFAULT NULL,
  `slots` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_product_default_slots_booking_product_id_foreign` (`booking_product_id`),
  CONSTRAINT `booking_product_default_slots_booking_product_id_foreign` FOREIGN KEY (`booking_product_id`) REFERENCES `booking_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_product_default_slots`
--

LOCK TABLES `booking_product_default_slots` WRITE;
/*!40000 ALTER TABLE `booking_product_default_slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_product_default_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_product_event_ticket_translations`
--

DROP TABLE IF EXISTS `booking_product_event_ticket_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_product_event_ticket_translations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_product_event_ticket_id` bigint unsigned NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bpet_locale_unique` (`booking_product_event_ticket_id`,`locale`),
  CONSTRAINT `bpet_translations_fk` FOREIGN KEY (`booking_product_event_ticket_id`) REFERENCES `booking_product_event_tickets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_product_event_ticket_translations`
--

LOCK TABLES `booking_product_event_ticket_translations` WRITE;
/*!40000 ALTER TABLE `booking_product_event_ticket_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_product_event_ticket_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_product_event_tickets`
--

DROP TABLE IF EXISTS `booking_product_event_tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_product_event_tickets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_product_id` int unsigned NOT NULL,
  `price` decimal(12,4) DEFAULT '0.0000',
  `qty` int DEFAULT '0',
  `special_price` decimal(12,4) DEFAULT NULL,
  `special_price_from` datetime DEFAULT NULL,
  `special_price_to` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_product_event_tickets_booking_product_id_foreign` (`booking_product_id`),
  CONSTRAINT `booking_product_event_tickets_booking_product_id_foreign` FOREIGN KEY (`booking_product_id`) REFERENCES `booking_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_product_event_tickets`
--

LOCK TABLES `booking_product_event_tickets` WRITE;
/*!40000 ALTER TABLE `booking_product_event_tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_product_event_tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_product_rental_slots`
--

DROP TABLE IF EXISTS `booking_product_rental_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_product_rental_slots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_product_id` int unsigned NOT NULL,
  `renting_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `daily_price` decimal(12,4) DEFAULT '0.0000',
  `hourly_price` decimal(12,4) DEFAULT '0.0000',
  `same_slot_all_days` tinyint(1) DEFAULT NULL,
  `slots` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_product_rental_slots_booking_product_id_foreign` (`booking_product_id`),
  CONSTRAINT `booking_product_rental_slots_booking_product_id_foreign` FOREIGN KEY (`booking_product_id`) REFERENCES `booking_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_product_rental_slots`
--

LOCK TABLES `booking_product_rental_slots` WRITE;
/*!40000 ALTER TABLE `booking_product_rental_slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_product_rental_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_product_table_slots`
--

DROP TABLE IF EXISTS `booking_product_table_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_product_table_slots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `booking_product_id` int unsigned NOT NULL,
  `price_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guest_limit` int NOT NULL DEFAULT '0',
  `duration` int NOT NULL,
  `break_time` int NOT NULL,
  `prevent_scheduling_before` int NOT NULL,
  `same_slot_all_days` tinyint(1) DEFAULT NULL,
  `slots` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_product_table_slots_booking_product_id_foreign` (`booking_product_id`),
  CONSTRAINT `booking_product_table_slots_booking_product_id_foreign` FOREIGN KEY (`booking_product_id`) REFERENCES `booking_products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_product_table_slots`
--

LOCK TABLES `booking_product_table_slots` WRITE;
/*!40000 ALTER TABLE `booking_product_table_slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_product_table_slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_products`
--

DROP TABLE IF EXISTS `booking_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_products` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty` int DEFAULT '0',
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_location` tinyint(1) NOT NULL DEFAULT '0',
  `available_every_week` tinyint(1) DEFAULT NULL,
  `available_from` datetime DEFAULT NULL,
  `available_to` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_products_product_id_foreign` (`product_id`),
  CONSTRAINT `booking_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_products`
--

LOCK TABLES `booking_products` WRITE;
/*!40000 ALTER TABLE `booking_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned DEFAULT NULL,
  `order_item_id` int unsigned DEFAULT NULL,
  `order_id` int unsigned DEFAULT NULL,
  `qty` int DEFAULT '0',
  `from` int DEFAULT NULL,
  `to` int DEFAULT NULL,
  `booking_product_event_ticket_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bookings_order_item_id_foreign` (`order_item_id`),
  KEY `bookings_booking_product_event_ticket_id_foreign` (`booking_product_event_ticket_id`),
  KEY `bookings_order_id_foreign` (`order_id`),
  KEY `bookings_product_id_foreign` (`product_id`),
  CONSTRAINT `bookings_booking_product_event_ticket_id_foreign` FOREIGN KEY (`booking_product_event_ticket_id`) REFERENCES `booking_product_event_tickets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `bookings_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `bookings_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE SET NULL,
  CONSTRAINT `bookings_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `customer_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_gift` tinyint(1) NOT NULL DEFAULT '0',
  `items_count` int DEFAULT NULL,
  `items_qty` decimal(12,4) DEFAULT NULL,
  `exchange_rate` decimal(12,4) DEFAULT NULL,
  `global_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `base_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cart_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grand_total` decimal(12,4) DEFAULT '0.0000',
  `base_grand_total` decimal(12,4) DEFAULT '0.0000',
  `sub_total` decimal(12,4) DEFAULT '0.0000',
  `base_sub_total` decimal(12,4) DEFAULT '0.0000',
  `tax_total` decimal(12,4) DEFAULT '0.0000',
  `base_tax_total` decimal(12,4) DEFAULT '0.0000',
  `discount_amount` decimal(12,4) DEFAULT '0.0000',
  `base_discount_amount` decimal(12,4) DEFAULT '0.0000',
  `shipping_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_shipping_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `shipping_amount_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_shipping_amount_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `sub_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_sub_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `checkout_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_guest` tinyint(1) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `applied_cart_rule_ids` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` int unsigned DEFAULT NULL,
  `channel_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_customer_id_foreign` (`customer_id`),
  KEY `cart_channel_id_foreign` (`channel_id`),
  CONSTRAINT `cart_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES (1,NULL,NULL,NULL,NULL,NULL,0,1,1.0000,NULL,'MXN','MXN','MXN','MXN',90.0000,90.0000,90.0000,90.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,90.0000,90.0000,NULL,1,1,NULL,NULL,1,'2025-12-12 12:15:49','2025-12-12 13:10:30'),(2,NULL,NULL,NULL,NULL,NULL,0,1,1.0000,NULL,'MXN','MXN','MXN','MXN',90.0000,90.0000,90.0000,90.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,90.0000,90.0000,NULL,1,1,NULL,NULL,1,'2025-12-19 16:02:28','2025-12-19 16:02:43'),(3,'tonalfan@gmail.com','Esau','Sanchez',NULL,NULL,0,1,1.0000,NULL,'MXN','MXN','MXN','MXN',90.0000,90.0000,90.0000,90.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,90.0000,90.0000,NULL,0,1,NULL,2,1,'2025-12-22 17:15:47','2025-12-22 17:16:22'),(4,NULL,NULL,NULL,NULL,NULL,0,1,1.0000,NULL,'MXN','MXN','MXN','MXN',90.0000,90.0000,90.0000,90.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,90.0000,90.0000,NULL,1,1,NULL,NULL,1,'2025-12-26 16:30:38','2025-12-26 18:05:47'),(8,NULL,NULL,NULL,NULL,NULL,0,2,4.0000,NULL,'MXN','MXN','MXN','USD',1105.0000,1105.0000,1105.0000,1105.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,1105.0000,1105.0000,NULL,1,1,NULL,NULL,1,'2025-12-27 21:14:53','2025-12-27 21:23:46'),(9,NULL,NULL,NULL,NULL,NULL,0,1,1.0000,NULL,'MXN','MXN','MXN','MXN',100.0000,100.0000,100.0000,100.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,100.0000,100.0000,NULL,1,1,NULL,NULL,1,'2025-12-27 22:38:40','2025-12-27 23:01:35'),(10,'eduardorosales720@gmail.com','Eduardo','Rosales',NULL,NULL,0,1,1.0000,NULL,'MXN','MXN','MXN','USD',0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,0,1,NULL,1,1,'2025-12-28 01:17:54','2025-12-28 05:03:02'),(12,NULL,NULL,NULL,NULL,NULL,0,2,6.0000,NULL,'MXN','MXN','MXN','MXN',9670.0000,9670.0000,9670.0000,9670.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,9670.0000,9670.0000,NULL,1,1,NULL,NULL,1,'2025-12-28 07:11:00','2025-12-28 08:01:39'),(13,NULL,NULL,NULL,NULL,NULL,0,2,10.0000,NULL,'MXN','MXN','MXN','MXN',162.0000,162.0000,162.0000,162.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,162.0000,162.0000,NULL,1,1,NULL,NULL,1,'2025-12-29 19:27:28','2025-12-29 19:28:29'),(14,NULL,NULL,NULL,NULL,NULL,0,1,5.0000,NULL,'MXN','MXN','MXN','MXN',0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,1,1,NULL,NULL,1,'2025-12-29 20:55:27','2025-12-29 21:20:09'),(15,NULL,NULL,NULL,NULL,NULL,0,1,7.0000,NULL,'MXN','MXN','MXN','MXN',2513.0000,2513.0000,2513.0000,2513.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,2513.0000,2513.0000,NULL,1,1,NULL,NULL,1,'2025-12-30 18:09:42','2025-12-30 18:11:13'),(16,NULL,NULL,NULL,NULL,NULL,0,1,7.0000,NULL,'MXN','MXN','MXN','MXN',5635.0000,5635.0000,5635.0000,5635.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,5635.0000,5635.0000,NULL,1,1,NULL,NULL,1,'2025-12-30 21:18:34','2025-12-30 21:19:22'),(17,NULL,NULL,NULL,NULL,NULL,0,1,18.0000,NULL,'MXN','MXN','MXN','MXN',0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,1,1,NULL,NULL,1,'2025-12-31 09:40:21','2025-12-31 09:41:38'),(18,NULL,NULL,NULL,NULL,NULL,0,1,6.0000,NULL,'MXN','MXN','MXN','MXN',0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,1,1,NULL,NULL,1,'2026-01-02 13:53:57','2026-01-02 13:57:11'),(19,NULL,NULL,NULL,NULL,NULL,0,1,4.0000,NULL,'MXN','MXN','MXN','MXN',0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,1,1,NULL,NULL,1,'2026-01-03 10:02:36','2026-01-03 10:02:46'),(20,NULL,NULL,NULL,NULL,NULL,0,2,13.0000,NULL,'MXN','MXN','MXN','MXN',0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,1,1,NULL,NULL,1,'2026-01-05 10:23:20','2026-01-05 12:28:35'),(21,NULL,NULL,NULL,NULL,NULL,0,1,5.0000,NULL,'MXN','MXN','MXN','MXN',500.0000,500.0000,500.0000,500.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,500.0000,500.0000,NULL,1,1,NULL,NULL,1,'2026-01-05 14:58:48','2026-01-05 14:58:51'),(22,NULL,NULL,NULL,NULL,NULL,0,1,1.0000,NULL,'MXN','MXN','MXN','MXN',100.0000,100.0000,100.0000,100.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,100.0000,100.0000,NULL,1,1,NULL,NULL,1,'2026-01-05 17:40:05','2026-01-05 17:55:16'),(23,NULL,NULL,NULL,NULL,NULL,0,1,4.0000,NULL,'MXN','MXN','MXN','MXN',400.0000,400.0000,400.0000,400.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,400.0000,400.0000,NULL,1,1,NULL,NULL,1,'2026-01-05 21:40:07','2026-01-05 21:41:46'),(24,NULL,NULL,NULL,NULL,NULL,0,1,1.0000,NULL,'MXN','MXN','MXN','MXN',100.0000,100.0000,100.0000,100.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,100.0000,100.0000,NULL,1,1,NULL,NULL,1,'2026-01-05 23:08:57','2026-01-05 23:10:29'),(25,NULL,NULL,NULL,NULL,NULL,0,1,4.0000,NULL,'MXN','MXN','MXN','MXN',3220.0000,3220.0000,3220.0000,3220.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,3220.0000,3220.0000,NULL,1,1,NULL,NULL,1,'2026-01-06 14:56:34','2026-01-06 14:56:37');
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_item_inventories`
--

DROP TABLE IF EXISTS `cart_item_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_item_inventories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `qty` int unsigned NOT NULL DEFAULT '0',
  `inventory_source_id` int unsigned DEFAULT NULL,
  `cart_item_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_item_inventories`
--

LOCK TABLES `cart_item_inventories` WRITE;
/*!40000 ALTER TABLE `cart_item_inventories` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_item_inventories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_items`
--

DROP TABLE IF EXISTS `cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_items` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `quantity` int unsigned NOT NULL DEFAULT '0',
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weight` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `total_weight` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_total_weight` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `price` decimal(12,4) NOT NULL DEFAULT '1.0000',
  `base_price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `custom_price` decimal(12,4) DEFAULT NULL,
  `total` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_total` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `tax_percent` decimal(12,4) DEFAULT '0.0000',
  `tax_amount` decimal(12,4) DEFAULT '0.0000',
  `base_tax_amount` decimal(12,4) DEFAULT '0.0000',
  `discount_percent` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `discount_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_discount_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `applied_tax_rate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int unsigned DEFAULT NULL,
  `product_id` int unsigned NOT NULL,
  `cart_id` int unsigned NOT NULL,
  `tax_category_id` int unsigned DEFAULT NULL,
  `applied_cart_rule_ids` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_items_parent_id_foreign` (`parent_id`),
  KEY `cart_items_product_id_foreign` (`product_id`),
  KEY `cart_items_cart_id_foreign` (`cart_id`),
  KEY `cart_items_tax_category_id_foreign` (`tax_category_id`),
  CONSTRAINT `cart_items_cart_id_foreign` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `cart_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_items_tax_category_id_foreign` FOREIGN KEY (`tax_category_id`) REFERENCES `tax_categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_items`
--

LOCK TABLES `cart_items` WRITE;
/*!40000 ALTER TABLE `cart_items` DISABLE KEYS */;
INSERT INTO `cart_items` VALUES (1,1,'001','simple','Prueba',NULL,0.0000,0.0000,0.0000,90.0000,90.0000,NULL,90.0000,90.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,90.0000,90.0000,90.0000,90.0000,NULL,NULL,1,1,NULL,NULL,'{\"cart_id\": 1, \"quantity\": 1, \"is_buy_now\": \"0\", \"product_id\": \"1\"}','2025-12-12 12:15:49','2025-12-12 12:15:49'),(2,1,'001','simple','Prueba',NULL,0.0000,0.0000,0.0000,90.0000,90.0000,NULL,90.0000,90.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,90.0000,90.0000,90.0000,90.0000,NULL,NULL,1,2,NULL,NULL,'{\"cart_id\": 2, \"quantity\": 1, \"product_id\": 1}','2025-12-19 16:02:28','2025-12-19 16:02:28'),(3,1,'001','simple','Prueba',NULL,0.0000,0.0000,0.0000,90.0000,90.0000,NULL,90.0000,90.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,90.0000,90.0000,90.0000,90.0000,NULL,NULL,1,3,NULL,NULL,'{\"cart_id\": 3, \"quantity\": 1, \"is_buy_now\": \"0\", \"product_id\": \"1\"}','2025-12-22 17:15:47','2025-12-22 17:15:47'),(4,1,'RAM-FOOD-008','simple','Sensei Sushi Bar',NULL,0.0000,0.0000,0.0000,90.0000,90.0000,NULL,90.0000,90.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,90.0000,90.0000,90.0000,90.0000,NULL,NULL,10,4,NULL,NULL,'{\"cart_id\": 4, \"quantity\": 1, \"product_id\": 10}','2025-12-26 16:30:38','2025-12-26 16:30:38'),(9,3,'RAM-FOOD-011','simple','100%Natural',NULL,0.0000,0.0000,0.0000,100.0000,100.0000,NULL,300.0000,300.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,100.0000,100.0000,300.0000,300.0000,NULL,NULL,11,8,NULL,NULL,'{\"cart_id\": 8, \"quantity\": 3, \"is_buy_now\": \"0\", \"product_id\": \"11\"}','2025-12-27 21:14:53','2025-12-27 21:15:31'),(10,1,'RAM-SERV-PAR-006','simple','Urban Art',NULL,0.0000,0.0000,0.0000,805.0000,805.0000,NULL,805.0000,805.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,805.0000,805.0000,805.0000,805.0000,NULL,NULL,31,8,NULL,NULL,'{\"cart_id\": 8, \"quantity\": 1, \"product_id\": 31}','2025-12-27 21:22:23','2025-12-27 21:22:23'),(11,1,'RAM-PLAZA-005','simple','Plaza Cancún Mall',NULL,0.0000,0.0000,0.0000,100.0000,100.0000,NULL,100.0000,100.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,100.0000,100.0000,100.0000,100.0000,NULL,NULL,22,9,NULL,NULL,'{\"cart_id\": 9, \"quantity\": 1, \"product_id\": 22}','2025-12-27 22:38:40','2025-12-27 22:38:40'),(13,1,'RAM-SERV-MED-002','simple','Cosmodent',NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,43,10,NULL,NULL,'{\"cart_id\": 10, \"quantity\": 1, \"is_buy_now\": \"0\", \"product_id\": \"43\"}','2025-12-28 01:48:32','2025-12-28 01:48:32'),(19,2,'RAM-SERV-PAR-003','simple','Whale Shark México',NULL,0.0000,0.0000,0.0000,2149.0000,2149.0000,NULL,4298.0000,4298.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,2149.0000,2149.0000,4298.0000,4298.0000,NULL,NULL,28,12,NULL,NULL,'{\"cart_id\": 12, \"quantity\": 2, \"is_buy_now\": \"0\", \"product_id\": \"28\"}','2025-12-28 07:11:00','2025-12-28 07:11:00'),(20,4,'RAM-SERV-DISC-002','simple','Coco Bongo',NULL,0.0000,0.0000,0.0000,1343.0000,1343.0000,NULL,5372.0000,5372.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,1343.0000,1343.0000,5372.0000,5372.0000,NULL,NULL,35,12,NULL,NULL,'{\"cart_id\": 12, \"quantity\": 4, \"is_buy_now\": \"0\", \"product_id\": \"35\"}','2025-12-28 07:17:44','2025-12-28 07:17:44'),(21,1,'RAM-ROP-001','simple','Cuidado Con El Perro',NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,62,13,NULL,NULL,'{\"cart_id\": 13, \"quantity\": 1, \"product_id\": 62}','2025-12-29 19:27:29','2025-12-29 19:27:29'),(22,9,'RAM-PROD-004','simple','Ondinas',NULL,0.0000,0.0000,0.0000,18.0000,18.0000,NULL,162.0000,162.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,18.0000,18.0000,162.0000,162.0000,NULL,NULL,61,13,NULL,NULL,'{\"cart_id\": 13, \"quantity\": 9, \"is_buy_now\": \"0\", \"product_id\": \"61\"}','2025-12-29 19:27:51','2025-12-29 19:27:56'),(23,5,'RAM-SERV-DEP-002','simple','360 Deportes',NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,38,14,NULL,NULL,'{\"cart_id\": 14, \"quantity\": 5, \"is_buy_now\": \"0\", \"product_id\": \"38\"}','2025-12-29 20:55:27','2025-12-29 20:55:27'),(24,7,'RAM-SERV-PAR-004','simple','Aquarium Cancún',NULL,0.0000,0.0000,0.0000,359.0000,359.0000,NULL,2513.0000,2513.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,359.0000,359.0000,2513.0000,2513.0000,NULL,NULL,29,15,NULL,NULL,'{\"cart_id\": 15, \"quantity\": 7, \"is_buy_now\": \"0\", \"product_id\": \"29\"}','2025-12-30 18:09:42','2025-12-30 18:09:42'),(25,7,'RAM-SERV-PAR-006','simple','Urban Art',NULL,0.0000,0.0000,0.0000,805.0000,805.0000,NULL,5635.0000,5635.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,805.0000,805.0000,5635.0000,5635.0000,NULL,NULL,31,16,NULL,NULL,'{\"cart_id\": 16, \"quantity\": 7, \"is_buy_now\": \"0\", \"product_id\": \"31\"}','2025-12-30 21:18:34','2025-12-30 21:18:34'),(26,18,'RAM-COM-001','simple','7ELEVEN',NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,46,17,NULL,NULL,'{\"cart_id\": 17, \"quantity\": 18, \"is_buy_now\": \"0\", \"product_id\": \"46\"}','2025-12-31 09:40:21','2025-12-31 09:40:26'),(27,6,'RAM-SERV-DEP-002','simple','360 Deportes',NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,38,18,NULL,NULL,'{\"cart_id\": 18, \"quantity\": 6, \"is_buy_now\": \"0\", \"product_id\": \"38\"}','2026-01-02 13:53:57','2026-01-02 13:54:08'),(28,4,'RAM-SERV-DEP-002','simple','360 Deportes',NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,38,19,NULL,NULL,'{\"cart_id\": 19, \"quantity\": 4, \"is_buy_now\": \"0\", \"product_id\": \"38\"}','2026-01-03 10:02:36','2026-01-03 10:02:36'),(29,6,'RAM-COM-001','simple','7ELEVEN',NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,46,20,NULL,NULL,'{\"cart_id\": 20, \"quantity\": 6, \"is_buy_now\": \"0\", \"product_id\": \"46\"}','2026-01-05 10:23:20','2026-01-05 10:23:32'),(30,7,'RAM-ROP-001','simple','Cuidado Con El Perro',NULL,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,NULL,NULL,62,20,NULL,NULL,'{\"cart_id\": 20, \"quantity\": 7, \"is_buy_now\": \"0\", \"product_id\": \"62\"}','2026-01-05 12:28:30','2026-01-05 12:28:30'),(31,5,'RAM-FOOD-011','simple','100%Natural',NULL,0.0000,0.0000,0.0000,100.0000,100.0000,NULL,500.0000,500.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,100.0000,100.0000,500.0000,500.0000,NULL,NULL,11,21,NULL,NULL,'{\"cart_id\": 21, \"quantity\": 5, \"is_buy_now\": \"0\", \"product_id\": \"11\"}','2026-01-05 14:58:49','2026-01-05 14:58:49'),(32,1,'RAM-FOOD-011','simple','100%Natural',NULL,0.0000,0.0000,0.0000,100.0000,100.0000,NULL,100.0000,100.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,100.0000,100.0000,100.0000,100.0000,NULL,NULL,11,22,NULL,NULL,'{\"cart_id\": 22, \"quantity\": 1, \"is_buy_now\": \"0\", \"product_id\": \"11\"}','2026-01-05 17:40:05','2026-01-05 17:40:05'),(33,4,'RAM-FOOD-011','simple','100%Natural',NULL,0.0000,0.0000,0.0000,100.0000,100.0000,NULL,400.0000,400.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,100.0000,100.0000,400.0000,400.0000,NULL,NULL,11,23,NULL,NULL,'{\"cart_id\": 23, \"quantity\": 4, \"is_buy_now\": \"0\", \"product_id\": \"11\"}','2026-01-05 21:40:07','2026-01-05 21:40:07'),(34,1,'RAM-FOOD-011','simple','100%Natural',NULL,0.0000,0.0000,0.0000,100.0000,100.0000,NULL,100.0000,100.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,100.0000,100.0000,100.0000,100.0000,NULL,NULL,11,24,NULL,NULL,'{\"cart_id\": 24, \"quantity\": 1, \"product_id\": 11}','2026-01-05 23:08:57','2026-01-05 23:08:57'),(35,4,'RAM-SERV-PAR-006','simple','Urban Art',NULL,0.0000,0.0000,0.0000,805.0000,805.0000,NULL,3220.0000,3220.0000,0.0000,0.0000,0.0000,0.0000,0.0000,0.0000,805.0000,805.0000,3220.0000,3220.0000,NULL,NULL,31,25,NULL,NULL,'{\"cart_id\": 25, \"quantity\": 4, \"is_buy_now\": \"0\", \"product_id\": \"31\"}','2026-01-06 14:56:34','2026-01-06 14:56:34');
/*!40000 ALTER TABLE `cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_payment`
--

DROP TABLE IF EXISTS `cart_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_payment` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cart_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_payment_cart_id_foreign` (`cart_id`),
  CONSTRAINT `cart_payment_cart_id_foreign` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_payment`
--

LOCK TABLES `cart_payment` WRITE;
/*!40000 ALTER TABLE `cart_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_rule_channels`
--

DROP TABLE IF EXISTS `cart_rule_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_rule_channels` (
  `cart_rule_id` int unsigned NOT NULL,
  `channel_id` int unsigned NOT NULL,
  PRIMARY KEY (`cart_rule_id`,`channel_id`),
  KEY `cart_rule_channels_channel_id_foreign` (`channel_id`),
  CONSTRAINT `cart_rule_channels_cart_rule_id_foreign` FOREIGN KEY (`cart_rule_id`) REFERENCES `cart_rules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_rule_channels_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_rule_channels`
--

LOCK TABLES `cart_rule_channels` WRITE;
/*!40000 ALTER TABLE `cart_rule_channels` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_rule_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_rule_coupon_usage`
--

DROP TABLE IF EXISTS `cart_rule_coupon_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_rule_coupon_usage` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `times_used` int NOT NULL DEFAULT '0',
  `cart_rule_coupon_id` int unsigned NOT NULL,
  `customer_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_rule_coupon_usage_cart_rule_coupon_id_foreign` (`cart_rule_coupon_id`),
  KEY `cart_rule_coupon_usage_customer_id_foreign` (`customer_id`),
  CONSTRAINT `cart_rule_coupon_usage_cart_rule_coupon_id_foreign` FOREIGN KEY (`cart_rule_coupon_id`) REFERENCES `cart_rule_coupons` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_rule_coupon_usage_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_rule_coupon_usage`
--

LOCK TABLES `cart_rule_coupon_usage` WRITE;
/*!40000 ALTER TABLE `cart_rule_coupon_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_rule_coupon_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_rule_coupons`
--

DROP TABLE IF EXISTS `cart_rule_coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_rule_coupons` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usage_limit` int unsigned NOT NULL DEFAULT '0',
  `usage_per_customer` int unsigned NOT NULL DEFAULT '0',
  `times_used` int unsigned NOT NULL DEFAULT '0',
  `type` int unsigned NOT NULL DEFAULT '0',
  `is_primary` tinyint(1) NOT NULL DEFAULT '0',
  `expired_at` date DEFAULT NULL,
  `cart_rule_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_rule_coupons_cart_rule_id_foreign` (`cart_rule_id`),
  CONSTRAINT `cart_rule_coupons_cart_rule_id_foreign` FOREIGN KEY (`cart_rule_id`) REFERENCES `cart_rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_rule_coupons`
--

LOCK TABLES `cart_rule_coupons` WRITE;
/*!40000 ALTER TABLE `cart_rule_coupons` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_rule_coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_rule_customer_groups`
--

DROP TABLE IF EXISTS `cart_rule_customer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_rule_customer_groups` (
  `cart_rule_id` int unsigned NOT NULL,
  `customer_group_id` int unsigned NOT NULL,
  PRIMARY KEY (`cart_rule_id`,`customer_group_id`),
  KEY `cart_rule_customer_groups_customer_group_id_foreign` (`customer_group_id`),
  CONSTRAINT `cart_rule_customer_groups_cart_rule_id_foreign` FOREIGN KEY (`cart_rule_id`) REFERENCES `cart_rules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_rule_customer_groups_customer_group_id_foreign` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_rule_customer_groups`
--

LOCK TABLES `cart_rule_customer_groups` WRITE;
/*!40000 ALTER TABLE `cart_rule_customer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_rule_customer_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_rule_customers`
--

DROP TABLE IF EXISTS `cart_rule_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_rule_customers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `times_used` bigint unsigned NOT NULL DEFAULT '0',
  `customer_id` int unsigned NOT NULL,
  `cart_rule_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_rule_customers_cart_rule_id_foreign` (`cart_rule_id`),
  KEY `cart_rule_customers_customer_id_foreign` (`customer_id`),
  CONSTRAINT `cart_rule_customers_cart_rule_id_foreign` FOREIGN KEY (`cart_rule_id`) REFERENCES `cart_rules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cart_rule_customers_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_rule_customers`
--

LOCK TABLES `cart_rule_customers` WRITE;
/*!40000 ALTER TABLE `cart_rule_customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_rule_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_rule_translations`
--

DROP TABLE IF EXISTS `cart_rule_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_rule_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` text COLLATE utf8mb4_unicode_ci,
  `cart_rule_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cart_rule_translations_cart_rule_id_locale_unique` (`cart_rule_id`,`locale`),
  CONSTRAINT `cart_rule_translations_cart_rule_id_foreign` FOREIGN KEY (`cart_rule_id`) REFERENCES `cart_rules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_rule_translations`
--

LOCK TABLES `cart_rule_translations` WRITE;
/*!40000 ALTER TABLE `cart_rule_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_rule_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_rules`
--

DROP TABLE IF EXISTS `cart_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_rules` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `starts_from` datetime DEFAULT NULL,
  `ends_till` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `coupon_type` int NOT NULL DEFAULT '1',
  `use_auto_generation` tinyint(1) NOT NULL DEFAULT '0',
  `usage_per_customer` int NOT NULL DEFAULT '0',
  `uses_per_coupon` int NOT NULL DEFAULT '0',
  `times_used` int unsigned NOT NULL DEFAULT '0',
  `condition_type` tinyint(1) NOT NULL DEFAULT '1',
  `conditions` json DEFAULT NULL,
  `end_other_rules` tinyint(1) NOT NULL DEFAULT '0',
  `uses_attribute_conditions` tinyint(1) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `discount_quantity` int NOT NULL DEFAULT '1',
  `discount_step` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `apply_to_shipping` tinyint(1) NOT NULL DEFAULT '0',
  `free_shipping` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_rules`
--

LOCK TABLES `cart_rules` WRITE;
/*!40000 ALTER TABLE `cart_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_shipping_rates`
--

DROP TABLE IF EXISTS `cart_shipping_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_shipping_rates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `carrier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `carrier_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` double DEFAULT '0',
  `base_price` double DEFAULT '0',
  `discount_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_discount_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `tax_percent` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `tax_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_tax_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `applied_tax_rate` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_calculate_tax` tinyint(1) NOT NULL DEFAULT '1',
  `cart_address_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `cart_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_shipping_rates_cart_id_foreign` (`cart_id`),
  CONSTRAINT `cart_shipping_rates_cart_id_foreign` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_shipping_rates`
--

LOCK TABLES `cart_shipping_rates` WRITE;
/*!40000 ALTER TABLE `cart_shipping_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_shipping_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_rule_channels`
--

DROP TABLE IF EXISTS `catalog_rule_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `catalog_rule_channels` (
  `catalog_rule_id` int unsigned NOT NULL,
  `channel_id` int unsigned NOT NULL,
  PRIMARY KEY (`catalog_rule_id`,`channel_id`),
  KEY `catalog_rule_channels_channel_id_foreign` (`channel_id`),
  CONSTRAINT `catalog_rule_channels_catalog_rule_id_foreign` FOREIGN KEY (`catalog_rule_id`) REFERENCES `catalog_rules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `catalog_rule_channels_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_rule_channels`
--

LOCK TABLES `catalog_rule_channels` WRITE;
/*!40000 ALTER TABLE `catalog_rule_channels` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalog_rule_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_rule_customer_groups`
--

DROP TABLE IF EXISTS `catalog_rule_customer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `catalog_rule_customer_groups` (
  `catalog_rule_id` int unsigned NOT NULL,
  `customer_group_id` int unsigned NOT NULL,
  PRIMARY KEY (`catalog_rule_id`,`customer_group_id`),
  KEY `catalog_rule_customer_groups_customer_group_id_foreign` (`customer_group_id`),
  CONSTRAINT `catalog_rule_customer_groups_catalog_rule_id_foreign` FOREIGN KEY (`catalog_rule_id`) REFERENCES `catalog_rules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `catalog_rule_customer_groups_customer_group_id_foreign` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_rule_customer_groups`
--

LOCK TABLES `catalog_rule_customer_groups` WRITE;
/*!40000 ALTER TABLE `catalog_rule_customer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalog_rule_customer_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_rule_product_prices`
--

DROP TABLE IF EXISTS `catalog_rule_product_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `catalog_rule_product_prices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `rule_date` date NOT NULL,
  `starts_from` datetime DEFAULT NULL,
  `ends_till` datetime DEFAULT NULL,
  `product_id` int unsigned NOT NULL,
  `customer_group_id` int unsigned NOT NULL,
  `catalog_rule_id` int unsigned NOT NULL,
  `channel_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catalog_rule_product_prices_product_id_foreign` (`product_id`),
  KEY `catalog_rule_product_prices_customer_group_id_foreign` (`customer_group_id`),
  KEY `catalog_rule_product_prices_catalog_rule_id_foreign` (`catalog_rule_id`),
  KEY `catalog_rule_product_prices_channel_id_foreign` (`channel_id`),
  CONSTRAINT `catalog_rule_product_prices_catalog_rule_id_foreign` FOREIGN KEY (`catalog_rule_id`) REFERENCES `catalog_rules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `catalog_rule_product_prices_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `catalog_rule_product_prices_customer_group_id_foreign` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `catalog_rule_product_prices_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_rule_product_prices`
--

LOCK TABLES `catalog_rule_product_prices` WRITE;
/*!40000 ALTER TABLE `catalog_rule_product_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalog_rule_product_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_rule_products`
--

DROP TABLE IF EXISTS `catalog_rule_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `catalog_rule_products` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `starts_from` datetime DEFAULT NULL,
  `ends_till` datetime DEFAULT NULL,
  `end_other_rules` tinyint(1) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `product_id` int unsigned NOT NULL,
  `customer_group_id` int unsigned NOT NULL,
  `catalog_rule_id` int unsigned NOT NULL,
  `channel_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catalog_rule_products_product_id_foreign` (`product_id`),
  KEY `catalog_rule_products_customer_group_id_foreign` (`customer_group_id`),
  KEY `catalog_rule_products_catalog_rule_id_foreign` (`catalog_rule_id`),
  KEY `catalog_rule_products_channel_id_foreign` (`channel_id`),
  CONSTRAINT `catalog_rule_products_catalog_rule_id_foreign` FOREIGN KEY (`catalog_rule_id`) REFERENCES `catalog_rules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `catalog_rule_products_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `catalog_rule_products_customer_group_id_foreign` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `catalog_rule_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_rule_products`
--

LOCK TABLES `catalog_rule_products` WRITE;
/*!40000 ALTER TABLE `catalog_rule_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalog_rule_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `catalog_rules`
--

DROP TABLE IF EXISTS `catalog_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `catalog_rules` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `starts_from` date DEFAULT NULL,
  `ends_till` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `condition_type` tinyint(1) NOT NULL DEFAULT '1',
  `conditions` json DEFAULT NULL,
  `end_other_rules` tinyint(1) NOT NULL DEFAULT '0',
  `action_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `catalog_rules`
--

LOCK TABLES `catalog_rules` WRITE;
/*!40000 ALTER TABLE `catalog_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `catalog_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `position` int NOT NULL DEFAULT '0',
  `logo_path` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `display_mode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'products_and_description',
  `_lft` int unsigned NOT NULL DEFAULT '0',
  `_rgt` int unsigned NOT NULL DEFAULT '0',
  `parent_id` int unsigned DEFAULT NULL,
  `additional` json DEFAULT NULL,
  `banner_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories__lft__rgt_parent_id_index` (`_lft`,`_rgt`,`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,1,NULL,1,'products_and_description',1,6,NULL,NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(2,1,NULL,1,'products_and_description',7,8,NULL,NULL,NULL,'2025-12-27 13:54:46','2025-12-27 16:01:22'),(3,1,NULL,1,'products_and_description',9,10,NULL,NULL,NULL,'2025-12-27 13:55:33','2025-12-27 16:01:15'),(4,1,NULL,1,'products_and_description',11,12,NULL,NULL,NULL,'2025-12-27 13:55:52','2025-12-27 16:01:08'),(5,1,NULL,1,'products_and_description',13,14,NULL,NULL,NULL,'2025-12-27 13:56:05','2025-12-27 16:00:59');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_filterable_attributes`
--

DROP TABLE IF EXISTS `category_filterable_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_filterable_attributes` (
  `category_id` int unsigned NOT NULL,
  `attribute_id` int unsigned NOT NULL,
  KEY `category_filterable_attributes_category_id_foreign` (`category_id`),
  KEY `category_filterable_attributes_attribute_id_foreign` (`attribute_id`),
  CONSTRAINT `category_filterable_attributes_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_filterable_attributes_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_filterable_attributes`
--

LOCK TABLES `category_filterable_attributes` WRITE;
/*!40000 ALTER TABLE `category_filterable_attributes` DISABLE KEYS */;
INSERT INTO `category_filterable_attributes` VALUES (1,11),(2,25),(3,25),(4,25),(5,25);
/*!40000 ALTER TABLE `category_filterable_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category_translations`
--

DROP TABLE IF EXISTS `category_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url_path` varchar(2048) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci,
  `locale_id` int unsigned DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_translations_category_id_slug_locale_unique` (`category_id`,`slug`,`locale`),
  KEY `category_translations_locale_id_foreign` (`locale_id`),
  CONSTRAINT `category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `category_translations_locale_id_foreign` FOREIGN KEY (`locale_id`) REFERENCES `locales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category_translations`
--

LOCK TABLES `category_translations` WRITE;
/*!40000 ALTER TABLE `category_translations` DISABLE KEYS */;
INSERT INTO `category_translations` VALUES (1,1,'Productos RAM','productos-ram','','<p>Descripci&oacute;n de la Categor&iacute;a Ra&iacute;z</p>','','','',NULL,'es'),(2,2,'Alimentos','alimentos','','<p>Alimentos</p>','','','',1,'es'),(3,3,'Servicios','servicios','','<p>Servicios</p>','','','',1,'es'),(4,4,'Productos','productos','','<p>Productos</p>','','','',1,'es'),(5,5,'Ropa','ropa','','<p>Ropa</p>','','','',1,'es');
/*!40000 ALTER TABLE `category_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_currencies`
--

DROP TABLE IF EXISTS `channel_currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channel_currencies` (
  `channel_id` int unsigned NOT NULL,
  `currency_id` int unsigned NOT NULL,
  PRIMARY KEY (`channel_id`,`currency_id`),
  KEY `channel_currencies_currency_id_foreign` (`currency_id`),
  KEY `channel_currencies_cid_cyid_idx` (`channel_id`,`currency_id`),
  CONSTRAINT `channel_currencies_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `channel_currencies_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_currencies`
--

LOCK TABLES `channel_currencies` WRITE;
/*!40000 ALTER TABLE `channel_currencies` DISABLE KEYS */;
INSERT INTO `channel_currencies` VALUES (1,1),(1,2);
/*!40000 ALTER TABLE `channel_currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_inventory_sources`
--

DROP TABLE IF EXISTS `channel_inventory_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channel_inventory_sources` (
  `channel_id` int unsigned NOT NULL,
  `inventory_source_id` int unsigned NOT NULL,
  UNIQUE KEY `channel_inventory_source_unique` (`channel_id`,`inventory_source_id`),
  KEY `channel_inventory_sources_inventory_source_id_foreign` (`inventory_source_id`),
  CONSTRAINT `channel_inventory_sources_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `channel_inventory_sources_inventory_source_id_foreign` FOREIGN KEY (`inventory_source_id`) REFERENCES `inventory_sources` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_inventory_sources`
--

LOCK TABLES `channel_inventory_sources` WRITE;
/*!40000 ALTER TABLE `channel_inventory_sources` DISABLE KEYS */;
INSERT INTO `channel_inventory_sources` VALUES (1,1);
/*!40000 ALTER TABLE `channel_inventory_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_locales`
--

DROP TABLE IF EXISTS `channel_locales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channel_locales` (
  `channel_id` int unsigned NOT NULL,
  `locale_id` int unsigned NOT NULL,
  PRIMARY KEY (`channel_id`,`locale_id`),
  KEY `channel_locales_locale_id_foreign` (`locale_id`),
  KEY `channel_locales_cid_lid_idx` (`channel_id`,`locale_id`),
  CONSTRAINT `channel_locales_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `channel_locales_locale_id_foreign` FOREIGN KEY (`locale_id`) REFERENCES `locales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_locales`
--

LOCK TABLES `channel_locales` WRITE;
/*!40000 ALTER TABLE `channel_locales` DISABLE KEYS */;
INSERT INTO `channel_locales` VALUES (1,1);
/*!40000 ALTER TABLE `channel_locales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channel_translations`
--

DROP TABLE IF EXISTS `channel_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channel_translations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `channel_id` int unsigned NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `maintenance_mode_text` text COLLATE utf8mb4_unicode_ci,
  `home_seo` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `channel_translations_channel_id_locale_unique` (`channel_id`,`locale`),
  KEY `channel_translations_locale_index` (`locale`),
  CONSTRAINT `channel_translations_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channel_translations`
--

LOCK TABLES `channel_translations` WRITE;
/*!40000 ALTER TABLE `channel_translations` DISABLE KEYS */;
INSERT INTO `channel_translations` VALUES (1,1,'es','Predeterminado','','Estamos trabajando para mejorar tu experiencia, vuelva en un momento.','{\"meta_title\": \"RAM Plaza\", \"meta_keywords\": \"RAM Plaza el e-commerce de RedActivaMexico.\", \"meta_description\": \"Encuentra todos los productos de RedActivaMexico al mejor precio.\"}',NULL,'2025-12-27 19:59:17');
/*!40000 ALTER TABLE `channel_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channels`
--

DROP TABLE IF EXISTS `channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `channels` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timezone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hostname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `home_seo` json DEFAULT NULL,
  `is_maintenance_on` tinyint(1) NOT NULL DEFAULT '0',
  `allowed_ips` text COLLATE utf8mb4_unicode_ci,
  `root_category_id` int unsigned DEFAULT NULL,
  `default_locale_id` int unsigned NOT NULL,
  `base_currency_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `channels_root_category_id_foreign` (`root_category_id`),
  KEY `channels_default_locale_id_foreign` (`default_locale_id`),
  KEY `channels_base_currency_id_foreign` (`base_currency_id`),
  KEY `channels_hostname_idx` (`hostname`),
  CONSTRAINT `channels_base_currency_id_foreign` FOREIGN KEY (`base_currency_id`) REFERENCES `currencies` (`id`),
  CONSTRAINT `channels_default_locale_id_foreign` FOREIGN KEY (`default_locale_id`) REFERENCES `locales` (`id`),
  CONSTRAINT `channels_root_category_id_foreign` FOREIGN KEY (`root_category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channels`
--

LOCK TABLES `channels` WRITE;
/*!40000 ALTER TABLE `channels` DISABLE KEYS */;
INSERT INTO `channels` VALUES (1,'default',NULL,'default','https://plaza.redactivamexico.net','channel/1/OrFmQKqku4pcbN9qTKCCNKfLypCUOER4Qr4OQ7hg.png','channel/1/PsmPA8CPArdAGHIaZiOPTVNly5Jy1LitmE2rU722.png',NULL,0,'',1,1,1,'2025-12-11 21:04:08','2025-12-27 19:59:17');
/*!40000 ALTER TABLE `channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_page_channels`
--

DROP TABLE IF EXISTS `cms_page_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_page_channels` (
  `cms_page_id` int unsigned NOT NULL,
  `channel_id` int unsigned NOT NULL,
  UNIQUE KEY `cms_page_channels_cms_page_id_channel_id_unique` (`cms_page_id`,`channel_id`),
  KEY `cms_page_channels_channel_id_foreign` (`channel_id`),
  CONSTRAINT `cms_page_channels_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cms_page_channels_cms_page_id_foreign` FOREIGN KEY (`cms_page_id`) REFERENCES `cms_pages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_page_channels`
--

LOCK TABLES `cms_page_channels` WRITE;
/*!40000 ALTER TABLE `cms_page_channels` DISABLE KEYS */;
INSERT INTO `cms_page_channels` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1);
/*!40000 ALTER TABLE `cms_page_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_page_translations`
--

DROP TABLE IF EXISTS `cms_page_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_page_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `html_content` longtext COLLATE utf8mb4_unicode_ci,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cms_page_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cms_page_translations_cms_page_id_url_key_locale_unique` (`cms_page_id`,`url_key`,`locale`),
  CONSTRAINT `cms_page_translations_cms_page_id_foreign` FOREIGN KEY (`cms_page_id`) REFERENCES `cms_pages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_page_translations`
--

LOCK TABLES `cms_page_translations` WRITE;
/*!40000 ALTER TABLE `cms_page_translations` DISABLE KEYS */;
INSERT INTO `cms_page_translations` VALUES (1,'Acerca de Nosotros','about-us','<div style=\"background-color: #1d252c; color: #e0e0e0; font-family: \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; line-height: 1.8; padding: clamp(20px, 5%, 40px); border-radius: 20px; width: 100%; box-sizing: border-box;\">\r\n<div style=\"max-width: 900px; margin: 0 auto; text-align: center; margin-bottom: clamp(30px, 5%, 40px);\">\r\n<h2 style=\"font-size: clamp(2rem, 8vw, 3rem); margin-bottom: 10px; color: #ffffff; font-weight: 800; line-height: 1.2;\">Bienvenidos a <span style=\"background: linear-gradient(90deg, #ff2f92 0%, #a42eff 100%); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;\"> RAM Plaza </span></h2>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.2rem); color: rgba(224,224,224,.65); font-style: italic; padding: 0 10px; margin: 0;\">La infraestructura de comercio electr&oacute;nico de Red Activa M&eacute;xico. Gesti&oacute;n profesional al alcance de tu negocio.</p>\r\n</div>\r\n<div style=\"margin-bottom: 50px; text-align: center; max-width: 800px; margin-left: auto; margin-right: auto;\">\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.5rem, 6vw, 1.8rem); margin-bottom: 20px; border-bottom: 2px solid rgba(255,255,255,.10); display: inline-block; padding-bottom: 10px;\">&iquest;Qui&eacute;nes somos?</h3>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.1rem); color: rgba(224,224,224,.78); padding: 0 10px; margin: 0;\">RAM Plaza es la soluci&oacute;n integral de <strong>e-commerce gestionado</strong>. No solo somos una tienda, somos un equipo que crea, administra y opera tu presencia comercial digital, permitiendo que los negocios vendan productos f&iacute;sicos y servicios con una imagen profesional y confianza total.</p>\r\n</div>\r\n<div style=\"text-align: center; margin-bottom: 30px;\">\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.5rem, 6vw, 1.8rem); margin-bottom: 10px;\">Nuestra Propuesta de Valor</h3>\r\n<p style=\"color: rgba(224,224,224,.60); max-width: 700px; margin: 0 auto; font-size: clamp(0.95rem, 3vw, 1rem); padding: 0 10px;\">Delegue la complejidad t&eacute;cnica. Nosotros nos encargamos de convertir su inventario en ventas mediante tres pilares operativos:</p>\r\n</div>\r\n<div style=\"display: flex; flex-wrap: wrap; gap: 25px; justify-content: center; margin-bottom: 50px;\"><!-- Card 1 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(20px, 4%, 30px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/7HuWcp0XpnsZucGC5fQ2adUlUBwDGgSH92PMZWpc.svg\" alt=\"security icon\" width=\"18\" height=\"18\"> </span> Gesti&oacute;n Operativa</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">RAM crea sus fichas de productos con <strong>fotograf&iacute;a profesional</strong>, gestiona inventarios, procesa pedidos y coordina la log&iacute;stica de env&iacute;os. Usted solo se ocupa de su negocio.</p>\r\n</div>\r\n<!-- Card 2 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(20px, 4%, 30px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/83cHG3SGZWrJ6E3TyAcECEqFKfjnXbmpxt66r5wO.svg\" alt=\"list icon\" width=\"18\" height=\"18\"> </span> Modelo H&iacute;brido</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">Presencia en nuestra <strong>Plaza General</strong> para descubrimiento masivo, o una <strong>Tienda Dedicada</strong> Premium con branding exclusivo y dominio propio para su marca.</p>\r\n</div>\r\n<!-- Card 3 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(20px, 4%, 30px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/sEK2eITt4HaXZDko5Dj80YEnTW8cxb0uvpknTnOh.svg\" alt=\"offer icon\" width=\"18\" height=\"18\"> </span> Cat&aacute;logo F&iacute;sico</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">Especializados en la comercializaci&oacute;n de productos tangibles: desde alimentos y textiles hasta <strong>Gift Cards</strong> y art&iacute;culos promocionales con atenci&oacute;n al cliente integrada.</p>\r\n</div>\r\n</div>\r\n<!-- Callout -->\r\n<div style=\"background: linear-gradient(135deg, #1d252c 0%, #161c21 100%); padding: clamp(25px, 5%, 40px); border-radius: 20px; border-left: 5px solid #a42eff; border: 1px solid rgba(255,255,255,.06); margin-bottom: 40px; box-sizing: border-box; box-shadow: none;\">\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.4rem, 5vw, 1.6rem); margin-top: 0; margin-bottom: 10px;\">Para los Negocios</h3>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.1rem); color: rgba(224,224,224,.78); margin-bottom: 0;\">Integrarse a RAM Plaza significa profesionalizar su canal de ventas. RAM gestiona su stock, activa promociones estrat&eacute;gicas y proyecta su marca hacia una comunidad que busca confianza, calidad y una experiencia de compra sin fricciones.</p>\r\n</div>\r\n<div style=\"text-align: center; margin-top: 20px;\"><span style=\"background: linear-gradient(90deg, #ff2f92 0%, #a42eff 100%); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; font-weight: 800; font-size: clamp(1.1rem, 5vw, 1.5rem);\"> RAM Plaza: Conectando a M&eacute;xico con el comercio profesional. </span></div>\r\n</div>','about us','','aboutus','es',1),(2,'Política de Retorno','return-policy','<div style=\"background-color: #1d252c; color: #e0e0e0; font-family: \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; line-height: 1.8; padding: clamp(20px, 5%, 40px); border-radius: 20px; width: 100%; box-sizing: border-box;\">\r\n<div style=\"max-width: 900px; margin: 0 auto; text-align: center; margin-bottom: clamp(30px, 5%, 50px);\">\r\n<h2 style=\"font-size: clamp(2rem, 8vw, 3rem); margin-bottom: 10px; color: #ffffff; font-weight: 800; line-height: 1.2;\">Garant&iacute;a de <span style=\"background: linear-gradient(90deg, #ff2f92 0%, #a42eff 100%); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;\"> Servicio y Gesti&oacute;n </span></h2>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.2rem); color: rgba(224,224,224,.65); padding: 0 10px; margin: 0;\">Transparencia y respaldo total en cada compra dentro de RAM Plaza.</p>\r\n</div>\r\n<div style=\"margin-bottom: clamp(30px, 5%, 40px); text-align: center; max-width: 800px; margin-left: auto; margin-right: auto;\">\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.1rem); color: rgba(224,224,224,.78); padding: 0 10px; margin: 0;\">En <strong>RAM Plaza</strong>, la confianza es nuestro motor. A diferencia de otros sitios, nosotros gestionamos directamente la presencia de los negocios para asegurar que cada producto, precio y promoci&oacute;n sea real y profesional.</p>\r\n</div>\r\n<div style=\"display: flex; flex-wrap: wrap; gap: 25px; justify-content: center; margin-bottom: 50px;\"><!-- Card 1 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/WMTt0bsoXZLeLjp6ZDEHdTgAWuKjsBg25ReBVU79.svg\" alt=\"icon view\" width=\"18\" height=\"18\"> </span> Verificaci&oacute;n Total</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">Todos los productos en RAM Plaza son reales y est&aacute;n vigentes. Nuestro equipo supervisa las fotos, descripciones y existencias para evitar sorpresas al momento de tu compra.</p>\r\n</div>\r\n<!-- Card 2 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/treiUgk6988wo7csetJtbgBO89n3sco3frATM5dw.svg\" alt=\"icon info\" width=\"18\" height=\"18\"> </span> Gesti&oacute;n de Pagos</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">Como plataforma centralizada, RAM Plaza gestiona la transacci&oacute;n comercial para que tu dinero est&eacute; respaldado por un entorno profesional y seguro en cada orden procesada.</p>\r\n</div>\r\n<!-- Card 3 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/8cNBKpOZh6CEgoof27mC2uOa5nFsUuNAkJA5vZc5.svg\" alt=\"Garant&iacute;a de red segura\" width=\"18\" height=\"18\"> </span> Log&iacute;stica Garantizada</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">RAM Plaza se encarga de coordinar el env&iacute;o de tus productos f&iacute;sicos o la entrega de tus <strong>Gift Cards</strong>, asegurando que el negocio cumpla con los tiempos y calidad pactados.</p>\r\n</div>\r\n</div>\r\n<!-- Callout -->\r\n<div style=\"background: linear-gradient(135deg, #1d252c 0%, #161c21 100%); padding: clamp(25px, 5%, 40px); border-radius: 20px; border-left: 5px solid #a42eff; border: 1px solid rgba(255,255,255,.06); margin-bottom: 40px; box-sizing: border-box; box-shadow: none;\">\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.4rem, 6vw, 1.6rem); margin-top: 0; margin-bottom: 20px;\">&iquest;Alg&uacute;n inconveniente con tu pedido?</h3>\r\n<p style=\"color: rgba(224,224,224,.78); margin: 0 0 18px; font-size: clamp(1rem, 4vw, 1.1rem);\">Si realizaste una compra y el producto no coincide con la descripci&oacute;n o hubo un problema en la entrega:</p>\r\n<ul style=\"list-style: none; padding: 0; margin: 0; color: rgba(224,224,224,.78); font-size: clamp(0.95rem, 3vw, 1rem);\">\r\n<li style=\"margin-bottom: 15px; display: flex; align-items: flex-start;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 10px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 12px; flex: 0 0 26px; color: #ffffff; font-weight: 800; font-size: .95rem;\"> 1 </span>\r\n<div>Revisa el n&uacute;mero de orden enviado a tu correo tras la transacci&oacute;n en RAM Plaza.</div>\r\n</li>\r\n<li style=\"margin-bottom: 15px; display: flex; align-items: flex-start;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 10px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 12px; flex: 0 0 26px; color: #ffffff; font-weight: 800; font-size: .95rem;\"> 2 </span>\r\n<div>Contacta a nuestro soporte centralizado indicando los detalles del inconveniente.</div>\r\n</li>\r\n<li style=\"margin-bottom: 0; display: flex; align-items: flex-start;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 10px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 12px; flex: 0 0 26px; color: #ffffff; font-weight: 800; font-size: .95rem;\"> 3 </span>\r\n<div>Nosotros gestionamos la soluci&oacute;n directamente con el negocio para garantizar tu satisfacci&oacute;n.</div>\r\n</li>\r\n</ul>\r\n</div>\r\n</div>','return policy','','return, policy','es',2),(3,'Política de Devolución','refund-policy','<div style=\"background-color: #1d252c; color: #e0e0e0; font-family: \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; line-height: 1.8; padding: clamp(20px, 5%, 40px); border-radius: 20px; width: 100%; box-sizing: border-box;\">\r\n<div style=\"max-width: 900px; margin: 0 auto; text-align: center; margin-bottom: clamp(30px, 5%, 50px);\">\r\n<h2 style=\"font-size: clamp(2rem, 8vw, 3rem); margin-bottom: 10px; color: #ffffff; font-weight: 800; line-height: 1.2;\">Pol&iacute;tica de <span style=\"background: linear-gradient(90deg, #ff2f92 0%, #a42eff 100%); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;\"> Devoluciones y Cambios </span></h2>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.2rem); color: rgba(224,224,224,.65); padding: 0 10px; margin: 0;\">Lineamientos sobre productos f&iacute;sicos y servicios gestionados por RAM Plaza.</p>\r\n</div>\r\n<div style=\"margin-bottom: clamp(30px, 5%, 40px); text-align: center; max-width: 800px; margin-left: auto; margin-right: auto;\">\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.1rem); color: rgba(224,224,224,.78); padding: 0 10px; margin: 0;\">En <strong>RAM Plaza</strong>, gestionamos de forma integral la venta de productos de nuestros clientes. Al ser nosotros quienes administramos el cat&aacute;logo y procesamos los pedidos, garantizamos un canal de comunicaci&oacute;n directo para resolver cualquier inconveniente con tu compra.</p>\r\n</div>\r\n<div style=\"display: flex; flex-wrap: wrap; gap: 25px; justify-content: center; margin-bottom: 50px;\"><!-- Card 1 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <!-- Icon opcional: si no quieres icono aquí, borra este span completo --> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/92N6hrjjnqnqLpg0YlZR4mO6O6IOOz16Ur9g22tj.svg\" alt=\"box\" width=\"18\" height=\"18\"> </span> Productos F&iacute;sicos</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">Para productos como alimentos embotellados o textiles, los cambios aplican por defectos de fabricaci&oacute;n o da&ntilde;os durante el env&iacute;o. RAM Plaza coordina con el negocio la reposici&oacute;n del art&iacute;culo para asegurar tu satisfacci&oacute;n.</p>\r\n</div>\r\n<!-- Card 2 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/sEK2eITt4HaXZDko5Dj80YEnTW8cxb0uvpknTnOh.svg\" alt=\"giftcard\" width=\"18\" height=\"18\"> </span> Tarjetas de Regalo</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">Las <strong>Gift Cards</strong> adquiridas en la plataforma son finales una vez emitidas. Debido a su naturaleza de consumo inmediato o programado, no cuentan con cambios ni devoluciones una vez que el c&oacute;digo ha sido enviado al usuario.</p>\r\n</div>\r\n<!-- Card 3 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/83cHG3SGZWrJ6E3TyAcECEqFKfjnXbmpxt66r5wO.svg\" alt=\"alert\" width=\"18\" height=\"18\"> </span> Gesti&oacute;n de Errores</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">Si existiera un error en el procesamiento del pedido o en la aplicaci&oacute;n de una promoci&oacute;n vigente al momento de la compra en la plataforma, RAM Plaza realizar&aacute; la correcci&oacute;n administrativa correspondiente de forma directa.</p>\r\n</div>\r\n</div>\r\n<!-- Callout (ajuste de gradiente + lista con chips y sin icono “neón”) -->\r\n<div style=\"background: linear-gradient(135deg, #1d252c 0%, #161c21 100%); padding: clamp(25px, 5%, 40px); border-radius: 20px; border-left: 5px solid #a42eff; border: 1px solid rgba(255,255,255,.06); margin-bottom: 40px; box-sizing: border-box; box-shadow: none;\">\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.4rem, 6vw, 1.6rem); margin-top: 0; margin-bottom: 20px;\">Aclaraciones sobre Reembolsos</h3>\r\n<ul style=\"list-style: none; padding: 0; margin: 0; color: rgba(224,224,224,.78); font-size: clamp(0.95rem, 3vw, 1rem);\">\r\n<li style=\"margin-bottom: 15px; display: flex; align-items: flex-start;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 10px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 12px; flex: 0 0 26px;\"> <img style=\"width: 16px; height: 16px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/0bK2s3Li9hZJEStqZ5XjyzynFWT7A4Tv63XDeFpa.svg\" alt=\"arrow\" width=\"16\" height=\"16\"> </span>\r\n<div>Toda solicitud debe presentarse dentro de los primeros 5 d&iacute;as h&aacute;biles posteriores a la recepci&oacute;n del producto.</div>\r\n</li>\r\n<li style=\"margin-bottom: 15px; display: flex; align-items: flex-start;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 10px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 12px; flex: 0 0 26px;\"> <img style=\"width: 16px; height: 16px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/0bK2s3Li9hZJEStqZ5XjyzynFWT7A4Tv63XDeFpa.svg\" alt=\"arrow\" width=\"16\" height=\"16\"> </span>\r\n<div>RAM Plaza evaluar&aacute; cada caso para determinar si procede el reembolso o la reposici&oacute;n f&iacute;sica del art&iacute;culo seg&uacute;n la disponibilidad en inventario.</div>\r\n</li>\r\n<li style=\"margin-bottom: 0; display: flex; align-items: flex-start;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 10px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 12px; flex: 0 0 26px;\"> <img style=\"width: 16px; height: 16px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/0bK2s3Li9hZJEStqZ5XjyzynFWT7A4Tv63XDeFpa.svg\" alt=\"arrow\" width=\"16\" height=\"16\"> </span>\r\n<div>Para compras de servicios o sesiones profesionales, la pol&iacute;tica de cancelaci&oacute;n se rige bajo los t&eacute;rminos espec&iacute;ficos publicados en la ficha del prestador dentro de nuestra tienda.</div>\r\n</li>\r\n</ul>\r\n</div>\r\n</div>','Refund policy','','refund, policy','es',3),(4,'Términos y Condiciones','terms-conditions','<div style=\"background-color: #1d252c; color: #e0e0e0; font-family: \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; line-height: 1.8; padding: clamp(20px, 5%, 40px); border-radius: 20px; width: 100%; box-sizing: border-box;\">\r\n<div style=\"max-width: 900px; margin: 0 auto; text-align: center; margin-bottom: clamp(30px, 5%, 50px);\">\r\n<h2 style=\"font-size: clamp(2rem, 8vw, 3rem); margin-bottom: 10px; color: #ffffff; font-weight: 800; line-height: 1.2;\">T&eacute;rminos y <span style=\"background: linear-gradient(90deg, #ff2f92 0%, #a42eff 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;\">Condiciones</span></h2>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.2rem); color: #b0b0b0; padding: 0 10px;\">Reglas de uso para la comunidad comercial de RAM Plaza.</p>\r\n</div>\r\n<div style=\"margin-bottom: clamp(30px, 5%, 40px); text-align: center; max-width: 800px; margin-left: auto; margin-right: auto;\">\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.1rem); color: #cccccc; padding: 0 10px;\">Bienvenido a <strong>RAM Plaza</strong>. Al utilizar nuestra plataforma gestionada de e-commerce, aceptas los presentes t&eacute;rminos. Operamos bajo un modelo donde RAM administra el contenido y presencia de los comercios para garantizarte una experiencia de compra profesional.</p>\r\n</div>\r\n<div style=\"display: flex; flex-wrap: wrap; gap: 25px; justify-content: center; margin-bottom: 50px;\">\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: left; box-sizing: border-box;\">\r\n<h4 style=\"margin-top: 0; color: #ff2f92; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center;\">1. Gesti&oacute;n del Servicio</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; line-height: 1.6;\">RAM Plaza es una plataforma de <strong>comercio gestionado</strong>. El equipo de RAM es responsable de la creaci&oacute;n de cat&aacute;logos, administraci&oacute;n de inventarios y procesamiento de &oacute;rdenes en nombre de los comercios afiliados.</p>\r\n</div>\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: left; box-sizing: border-box;\">\r\n<h4 style=\"margin-top: 0; color: #bc2eff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center;\">2. Transacciones y Pagos</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; line-height: 1.6;\">Las compras realizadas se procesan dentro del ecosistema RAM Plaza. Al adquirir productos f&iacute;sicos o <strong>Gift Cards</strong>, el usuario acepta las condiciones de precio y env&iacute;o establecidas en la ficha gestionada del producto.</p>\r\n</div>\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: left; box-sizing: border-box;\">\r\n<h4 style=\"margin-top: 0; color: #ff2f92; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center;\">3. Compromiso de Calidad</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; line-height: 1.6;\">Aunque RAM Plaza gestiona la venta, el negocio afiliado es el responsable final del producto. RAM Plaza intervendr&aacute; en cualquier disputa para asegurar que se cumpla con la calidad y la entrega pactada.</p>\r\n</div>\r\n</div>\r\n<div style=\"background: linear-gradient(135deg, #1d252c 0%, #161c21 100%); padding: clamp(25px, 5%, 40px); border-radius: 20px; border-left: 5px solid #a42eff; margin-bottom: 40px; box-sizing: border-box;\">\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.4rem, 6vw, 1.6rem); margin-top: 0; margin-bottom: 20px;\">Reglas Generales de la Comunidad</h3>\r\n<ul style=\"list-style: none; padding: 0; margin: 0; color: #cccccc; font-size: clamp(0.95rem, 3vw, 1rem);\">\r\n<li style=\"margin-bottom: 20px; display: flex; align-items: start;\"><img style=\"margin-right: 15px; min-width: 24px; flex-shrink: 0; vertical-align: middle;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/QMPP1dUpPojy3pDzh0xstR2hMwpR9lkzskv0CF0A.svg\" alt=\"icon\" width=\"24\" height=\"24\">\r\n<div><strong style=\"color: #e0e0e0;\">Veracidad Comercial:</strong> RAM Plaza supervisa que la informaci&oacute;n de los negocios sea real y profesional para tu seguridad.</div>\r\n</li>\r\n<li style=\"margin-bottom: 20px; display: flex; align-items: start;\"><img style=\"margin-right: 15px; min-width: 24px; flex-shrink: 0; vertical-align: middle;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/zKjFEOSPAJjce16kVkuBXQFMUf7GdN1U1BLctCnM.svg\" alt=\"icon\" width=\"24\" height=\"24\">\r\n<div><strong style=\"color: #e0e0e0;\">Actualizaci&oacute;n de Inventarios:</strong> RAM Plaza actualiza existencias y precios conforme el negocio lo provee, reserv&aacute;ndose el derecho de cancelar &oacute;rdenes por falta de stock coordinada con el aliado.</div>\r\n</li>\r\n<li style=\"margin-bottom: 0; display: flex; align-items: start;\"><img style=\"margin-right: 15px; min-width: 24px; flex-shrink: 0; vertical-align: middle;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/EGZYqTo2mPTPdF13DkN76mNPIuV0Pl4UWrc3j9FE.svg\" alt=\"icon\" width=\"24\" height=\"24\">\r\n<div><strong style=\"color: #e0e0e0;\">Propiedad de Contenido:</strong> Toda fotograf&iacute;a y dise&ntilde;o creado por RAM para los comercios es propiedad del ecosistema Red Activa M&eacute;xico.</div>\r\n</li>\r\n</ul>\r\n</div>\r\n<div style=\"text-align: center; margin-top: 30px; border-top: 1px solid #333; padding-top: 20px;\">\r\n<p style=\"color: #666; font-size: clamp(0.75rem, 3vw, 0.85rem);\">Al realizar una compra, aceptas estos t&eacute;rminos en su totalidad. <br>&Uacute;ltima actualizaci&oacute;n: Enero 2025.</p>\r\n</div>\r\n</div>','Terms & Conditions','','term, conditions','es',4),(5,'Términos de Uso','terms-of-use','<div style=\"background-color: #1d252c; color: #e0e0e0; font-family: \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; line-height: 1.8; padding: clamp(20px, 5%, 40px); border-radius: 20px; width: 100%; box-sizing: border-box;\">\r\n<div style=\"max-width: 900px; margin: 0 auto; text-align: center; margin-bottom: clamp(30px, 5%, 50px);\">\r\n<h2 style=\"font-size: clamp(2rem, 8vw, 3rem); margin-bottom: 10px; color: #ffffff; font-weight: 800; line-height: 1.2;\">T&eacute;rminos de <span style=\"background: linear-gradient(90deg, #ff2f92 0%, #a42eff 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;\">Uso Digital</span></h2>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.2rem); color: #b0b0b0; padding: 0 10px;\">C&oacute;digo de conducta y reglas para interactuar en RAM Plaza.</p>\r\n</div>\r\n<div style=\"margin-bottom: clamp(30px, 5%, 40px); text-align: center; max-width: 800px; margin-left: auto; margin-right: auto;\">\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.1rem); color: #cccccc; padding: 0 10px;\">El acceso a <strong>RAM Plaza</strong> y la adquisici&oacute;n de productos gestionados implica la aceptaci&oacute;n de estas reglas. Nuestra plataforma centraliza el comercio de confianza para que realices tus compras con total transparencia y seguridad profesional.</p>\r\n</div>\r\n<div style=\"display: flex; flex-wrap: wrap; gap: 25px; justify-content: center; margin-bottom: 50px;\">\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: left; box-sizing: border-box;\">\r\n<h4 style=\"margin-top: 0; color: #ff2f92; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center;\"><img style=\"margin-right: 10px; vertical-align: middle;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/bX3Vmx16KaaIUPIA7Xycn9EcuOYd2oZFPqB2IbJY.svg\" alt=\"icon lock\" width=\"24\" height=\"24\"> Seguridad de Cuenta</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; line-height: 1.6;\">Eres responsable de la confidencialidad de tus credenciales. El acceso a los precios gestionados y promociones es personal; cualquier pedido realizado desde tu cuenta ser&aacute; procesado bajo tu responsabilidad.</p>\r\n</div>\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: left; box-sizing: border-box;\">\r\n<h4 style=\"margin-top: 0; color: #bc2eff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center;\"><img style=\"margin-right: 10px; vertical-align: middle;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/3otoW8ckjmfOhLXsGpsoIm9TbSCF6i5tFnEyfKCC.svg\" alt=\"icon block\" width=\"24\" height=\"24\"> Uso Prohibido</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; line-height: 1.6;\">Queda prohibido el uso de la plataforma para fines il&iacute;citos, suplantaci&oacute;n o manipulaci&oacute;n t&eacute;cnica. Cualquier intento de alterar los precios gestionados o el flujo de pedidos resultar&aacute; en la baja inmediata.</p>\r\n</div>\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: left; box-sizing: border-box;\">\r\n<h4 style=\"margin-top: 0; color: #ff2f92; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center;\"><img style=\"margin-right: 10px; vertical-align: middle;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/akYng0YGnmDUkORqvm1b7CPrEba3r8DzBcj8t5Hs.svg\" alt=\"icon signal\" width=\"24\" height=\"24\"> Veracidad de Informaci&oacute;n</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; line-height: 1.6;\">RAM Plaza supervisa directamente las im&aacute;genes y descripciones. Los precios y el stock son administrados por nuestro equipo para asegurar que lo que ves sea lo que recibes tras tu compra.</p>\r\n</div>\r\n</div>\r\n<div style=\"background: linear-gradient(135deg, #1d252c 0%, #161c21 100%); padding: clamp(25px, 5%, 40px); border-radius: 20px; border-left: 5px solid #a42eff; margin-bottom: 40px; box-sizing: border-box;\">\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.4rem, 6vw, 1.6rem); margin-top: 0; margin-bottom: 20px;\">Propiedad Intelectual</h3>\r\n<ul style=\"list-style: none; padding: 0; margin: 0; color: #cccccc; font-size: clamp(0.95rem, 3vw, 1rem);\">\r\n<li style=\"margin-bottom: 20px; display: flex; align-items: start;\">\r\n<div><strong style=\"color: #e0e0e0;\">Derechos de Autor:</strong> Todo el cat&aacute;logo visual, las fotograf&iacute;as profesionales de productos creadas por nuestro equipo y el software de RAM Plaza son propiedad exclusiva de Red Activa M&eacute;xico.</div>\r\n</li>\r\n<li style=\"margin-bottom: 0; display: flex; align-items: start;\">\r\n<div><strong style=\"color: #e0e0e0;\">Uso de Marcas:</strong> Los logotipos de los negocios afiliados se utilizan exclusivamente para identificar el origen de los productos ofrecidos dentro del cat&aacute;logo gestionado de RAM Plaza.</div>\r\n</li>\r\n</ul>\r\n</div>\r\n</div>','Terms of use','','term, use','es',5),(6,'Servicio al Cliente','customer-service','<div style=\"background-color: #1d252c; color: #e0e0e0; font-family: \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; line-height: 1.8; padding: clamp(20px, 5%, 40px); border-radius: 20px; width: 100%; box-sizing: border-box;\">\r\n<div style=\"max-width: 900px; margin: 0 auto; text-align: center; margin-bottom: clamp(30px, 5%, 50px);\">\r\n<h2 style=\"font-size: clamp(2rem, 8vw, 3rem); margin-bottom: 10px; color: #ffffff; font-weight: 800; line-height: 1.2;\">Estamos aqu&iacute; para <span style=\"background: linear-gradient(90deg, #ff2f92 0%, #a42eff 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;\">Ayudarte</span></h2>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.2rem); color: #b0b0b0; padding: 0 10px;\">Tu experiencia en RAM Plaza es nuestra prioridad. &iquest;C&oacute;mo podemos asistirte hoy?</p>\r\n</div>\r\n<div style=\"display: flex; flex-wrap: wrap; gap: 25px; justify-content: center; margin-bottom: 50px;\">\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: center; box-sizing: border-box;\">\r\n<div style=\"margin-bottom: 15px;\"><img src=\"https://plaza.redactivamexico.net/storage/tinymce/iP0vwUYw1oZHNp9BqeK7x4B19UDoBl2EGTYWThMk.svg\" alt=\"soporte ventas\" width=\"48\" height=\"48\"></div>\r\n<h4 style=\"margin-top: 0; color: #ff2f92; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 10px;\">Soporte de Pedidos</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; margin-bottom: 20px;\">&iquest;Problemas con tu compra, pago o seguimiento de env&iacute;o? &iquest;Necesitas ayuda con tu pedido?</p>\r\n<a style=\"color: #bc2eff; text-decoration: none; font-weight: bold; border-bottom: 1px solid #bc2eff; font-size: 1rem;\" href=\"mailto:soporte@redactivamexico.net?subject=Soporte de Pedidos RAM Plaza\"> Contactar Soporte &rarr; </a></div>\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: center; box-sizing: border-box;\">\r\n<div style=\"margin-bottom: 15px;\"><img src=\"https://plaza.redactivamexico.net/storage/tinymce/qzYhFx1eDkJva2Adsug6bO8HZhwEqRcqZNB3x5Mq.svg\" alt=\"reportar pedido\" width=\"48\" height=\"48\"></div>\r\n<h4 style=\"margin-top: 0; color: #bc2eff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 10px;\">Reportar Incidente</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; margin-bottom: 20px;\">&iquest;Tu producto no coincide con la descripci&oacute;n del cat&aacute;logo gestionado?</p>\r\n<a style=\"color: #ff2f92; text-decoration: none; font-weight: bold; border-bottom: 1px solid #ff2f92; font-size: 1rem;\" href=\"mailto:denuncias@redactivamexico.net?subject=Reporte de Producto - RAM Plaza\"> Abrir Reporte &rarr; </a></div>\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: center; box-sizing: border-box;\">\r\n<div style=\"margin-bottom: 15px;\"><img src=\"https://plaza.redactivamexico.net/storage/tinymce/CUU5d1XHcWhPGsKEWKFmLM2ky94TUEnsri4LOvDq.svg\" alt=\"negocios\" width=\"48\" height=\"48\"></div>\r\n<h4 style=\"margin-top: 0; color: #ff2f92; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 10px;\">Vende en Plaza</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; margin-bottom: 20px;\">&iquest;Quieres gestionar tu inventario en RAM?</p>\r\n<a style=\"color: #bc2eff; text-decoration: none; font-weight: bold; border-bottom: 1px solid #bc2eff; font-size: 1rem;\" href=\"mailto:aliados@redactivamexico.net?subject=Ventas RAM Plaza\"> Quiero Vender &rarr; </a></div>\r\n</div>\r\n<div style=\"background: linear-gradient(135deg, #1d252c 0%, #161c21 100%); padding: clamp(25px, 5%, 40px); border-radius: 20px; border-left: 5px solid #a42eff; margin-bottom: 40px; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 30px; box-sizing: border-box;\">\r\n<div style=\"flex: 1; min-width: 280px;\">\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.5rem, 6vw, 1.8rem); margin-top: 0; margin-bottom: 10px;\">Atenci&oacute;n Centralizada</h3>\r\n<p style=\"color: #cccccc; font-size: clamp(0.95rem, 3vw, 1rem);\">Nuestro equipo de gesti&oacute;n comercial est&aacute; disponible para resolver dudas sobre tus pedidos en:</p>\r\n<ul style=\"list-style: none; padding: 0; color: #bbb; font-size: clamp(0.9rem, 3vw, 1rem);\">\r\n<li style=\"margin-bottom: 5px; display: flex; align-items: center;\"><img style=\"margin-right: 10px;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/MIbflMQFccCAMdV5RemfkQBZT2xsxnARFdRhyBwd.svg\" alt=\"lunes\" width=\"18\" height=\"18\"> <strong>Lunes a Viernes:</strong> 9:00 AM - 7:00 PM</li>\r\n<li style=\"display: flex; align-items: center;\"><img style=\"margin-right: 10px;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/MIbflMQFccCAMdV5RemfkQBZT2xsxnARFdRhyBwd.svg\" alt=\"sabado\" width=\"18\" height=\"18\"> <strong>S&aacute;bados:</strong> 10:00 AM - 2:00 PM</li>\r\n</ul>\r\n</div>\r\n<div style=\"flex: 0 0 auto; width: 100%; max-width: 300px; text-align: center; margin: 0 auto;\"><a style=\"background: linear-gradient(90deg, #ff2f92 0%, #a42eff 100%); color: white; padding: 15px 40px; border-radius: 10px; text-decoration: none; font-weight: bold; font-size: 1.1rem; display: block; box-shadow: 0 0 20px rgba(188, 46, 255, 0.3); text-align: center;\" href=\"mailto:hola@redactivamexico.net\"> Escribir a RAM Plaza </a></div>\r\n</div>\r\n<div style=\"text-align: center; max-width: 700px; margin: 0 auto; padding: 0 10px;\">\r\n<h4 style=\"color: #fff; font-size: clamp(1.1rem, 4vw, 1.2rem);\">&iquest;Buscas una respuesta r&aacute;pida?</h4>\r\n<p style=\"color: #888; font-size: clamp(0.9rem, 3vw, 0.95rem); margin-bottom: 20px;\">Dudas sobre env&iacute;os, medios de pago y gesti&oacute;n de tiendas dedicadas.</p>\r\n<a style=\"color: #e0e0e0; text-decoration: underline; font-size: 1rem;\" href=\"#\"> Visita nuestro Centro de Ayuda &rarr; </a></div>\r\n</div>','Customer Service','','customer, service','es',6),(7,'Novedades','whats-new','<div style=\"background-color: #1d252c; color: #e0e0e0; font-family: \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; line-height: 1.8; padding: clamp(20px, 5%, 40px); border-radius: 20px; width: 100%; box-sizing: border-box;\">\r\n<div style=\"max-width: 900px; margin: 0 auto; text-align: center; margin-bottom: clamp(30px, 5%, 50px);\">\r\n<h2 style=\"font-size: clamp(2rem, 8vw, 3rem); margin-bottom: 10px; color: #ffffff; font-weight: 800; line-height: 1.2;\">Lo Nuevo en <span style=\"background: linear-gradient(90deg, #ff2f92 0%, #a42eff 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;\">RAM Plaza</span></h2>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.2rem); color: #b0b0b0; padding: 0 10px;\">Mantente al d&iacute;a con las &uacute;ltimas actualizaciones y tiendas gestionadas de tu plataforma.</p>\r\n</div>\r\n<div style=\"background: linear-gradient(135deg, #1d252c 0%, #161c21 100%); padding: clamp(25px, 5%, 40px); border-radius: 20px; border: 1px solid #333; margin-bottom: 50px; display: flex; flex-wrap: wrap; align-items: center; box-sizing: border-box;\">\r\n<div style=\"flex: 1; min-width: 280px; padding-right: clamp(0px, 2%, 20px);\">\r\n<div style=\"margin-bottom: 15px;\"><span style=\"background-color: #a42eff; color: white; padding: 5px 12px; border-radius: 50px; font-size: 0.8rem; font-weight: bold; text-transform: uppercase;\"> Actualizaci&oacute;n Comercial </span></div>\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.5rem, 6vw, 2rem); margin-top: 0; margin-bottom: 15px;\">Tiendas Premium y Gesti&oacute;n Total</h3>\r\n<p style=\"color: #cccccc; margin-bottom: 20px; font-size: clamp(0.95rem, 3vw, 1rem);\">Hemos expandido nuestra infraestructura de e-commerce. Ahora, adem&aacute;s de nuestra <strong>Plaza General</strong>, habilitamos nuevas <strong>Tiendas Dedicadas</strong> para marcas que buscan una experiencia exclusiva. Explora productos f&iacute;sicos de alta calidad, desde alimentos regionales hasta art&iacute;culos de dise&ntilde;o, todos gestionados profesionalmente por RAM.</p>\r\n<a style=\"color: #ff2f92; text-decoration: none; font-weight: bold; border-bottom: 1px solid #ff2f92; font-size: 1rem;\" href=\"#\"> Explorar el Cat&aacute;logo Unificado &rarr; </a></div>\r\n</div>\r\n<div style=\"display: flex; flex-wrap: wrap; gap: 25px; justify-content: center; margin-bottom: 50px;\">\r\n<div style=\"background-color: #1d252c; padding: clamp(20px, 4%, 30px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; box-sizing: border-box;\">\r\n<div style=\"margin-bottom: 15px;\"><img src=\"https://plaza.redactivamexico.net/storage/tinymce/x1O2gzBpTkZmSSyztbQP6oD1bu4QTXIr0jiN6wbN.svg\" alt=\"nuevos negocios\" width=\"40\" height=\"40\"></div>\r\n<h4 style=\"margin-top: 0; color: #fff; font-size: clamp(1.2rem, 5vw, 1.3rem); margin-bottom: 10px;\">Nuevas Marcas</h4>\r\n<p style=\"font-size: clamp(0.9rem, 3vw, 0.95rem); color: #bbb;\">Damos la bienvenida a m&aacute;s de 50 nuevos negocios al ecosistema. Descubre sus productos f&iacute;sicos y servicios profesionales en las nuevas categor&iacute;as de nuestra plaza comercial.</p>\r\n</div>\r\n<div style=\"background-color: #1d252c; padding: clamp(20px, 4%, 30px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; box-sizing: border-box;\">\r\n<div style=\"margin-bottom: 15px;\"><img src=\"https://plaza.redactivamexico.net/storage/tinymce/92N6hrjjnqnqLpg0YlZR4mO6O6IOOz16Ur9g22tj.svg\" alt=\"gift card\" width=\"40\" height=\"40\"></div>\r\n<h4 style=\"margin-top: 0; color: #fff; font-size: clamp(1.2rem, 5vw, 1.3rem); margin-bottom: 10px;\">Gift Cards Activas</h4>\r\n<p style=\"font-size: clamp(0.9rem, 3vw, 0.95rem); color: #bbb;\">Hemos optimizado la compra de tarjetas de regalo. Adqui&eacute;relas de forma segura para tus negocios favoritos y rec&iacute;belas digitalmente con la gesti&oacute;n directa de RAM Plaza.</p>\r\n</div>\r\n<div style=\"background-color: #1d252c; padding: clamp(20px, 4%, 30px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; box-sizing: border-box;\">\r\n<div style=\"margin-bottom: 15px;\"><img src=\"https://plaza.redactivamexico.net/storage/tinymce/xOnw5hRbH787Hva5xjR3vRpaAhHtNp7PxlzGPoGM.svg\" alt=\"notificaciones\" width=\"40\" height=\"40\"></div>\r\n<h4 style=\"margin-top: 0; color: #fff; font-size: clamp(1.2rem, 5vw, 1.3rem); margin-bottom: 10px;\">Alertas de Stock</h4>\r\n<p style=\"font-size: clamp(0.9rem, 3vw, 0.95rem); color: #bbb;\">&iexcl;Ent&eacute;rate primero! Recibe avisos cuando se agreguen nuevos productos a las tiendas premium o cuando relancemos stock de tus art&iacute;culos f&iacute;sicos preferidos.</p>\r\n</div>\r\n</div>\r\n</div>','What\'s New','','new','es',7),(8,'Política de Pago','payment-policy','<div style=\"background-color: #1d252c; color: #e0e0e0; font-family: \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; line-height: 1.8; padding: clamp(20px, 5%, 40px); border-radius: 20px; width: 100%; box-sizing: border-box;\">\r\n<div style=\"max-width: 900px; margin: 0 auto; text-align: center; margin-bottom: clamp(30px, 5%, 50px);\">\r\n<h2 style=\"font-size: clamp(2rem, 8vw, 3rem); margin-bottom: 10px; color: #ffffff; font-weight: 800; line-height: 1.2;\">Pol&iacute;tica de <span style=\"background: linear-gradient(90deg, #ff2f92 0%, #a42eff 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;\">Pago</span></h2>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.2rem); color: #b0b0b0; padding: 0 10px;\">Transacciones seguras y gesti&oacute;n profesional en RAM Plaza.</p>\r\n</div>\r\n<div style=\"margin-bottom: clamp(30px, 5%, 40px); text-align: center; max-width: 800px; margin-left: auto; margin-right: auto;\">\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.1rem); color: #cccccc; padding: 0 10px;\">En <strong>RAM Plaza</strong>, centralizamos el procesamiento de pagos para tu seguridad. Al adquirir productos del cat&aacute;logo gestionado o servicios profesionales, tu transacci&oacute;n es administrada por nuestra plataforma para garantizar el cumplimiento de la orden.</p>\r\n</div>\r\n<div style=\"display: flex; flex-wrap: wrap; gap: 25px; justify-content: center; margin-bottom: 50px;\">\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: left; box-sizing: border-box;\">\r\n<div style=\"margin-bottom: 15px;\">&nbsp;</div>\r\n<h4 style=\"margin-top: 0; color: #ff2f92; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 10px;\">Compras Gestionadas</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; line-height: 1.6;\">RAM Plaza <strong>procesa directamente los pagos</strong> de productos f&iacute;sicos y <strong>Gift Cards</strong>. Esto nos permite asegurar que el monto sea correcto y que el negocio inicie la preparaci&oacute;n de tu pedido de inmediato.</p>\r\n</div>\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: left; box-sizing: border-box;\">\r\n<div style=\"margin-bottom: 15px;\">&nbsp;</div>\r\n<h4 style=\"margin-top: 0; color: #bc2eff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 10px;\">Seguridad Online</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; line-height: 1.6;\">Aceptamos tarjetas de cr&eacute;dito, d&eacute;bito y transferencias digitales. Utilizamos pasarelas encriptadas de &uacute;ltima generaci&oacute;n para proteger tus datos bancarios en cada paso de la compra.</p>\r\n</div>\r\n<div style=\"background-color: #1d252c; padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid #333; flex: 1; min-width: 280px; text-align: left; box-sizing: border-box;\">\r\n<div style=\"margin-bottom: 15px;\">&nbsp;</div>\r\n<h4 style=\"margin-top: 0; color: #ff2f92; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 10px;\">Facturaci&oacute;n</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: #bbbbbb; line-height: 1.6;\">Al ser transacciones gestionadas, puedes solicitar tu comprobante fiscal directamente a trav&eacute;s de nuestro soporte, indicando tu n&uacute;mero de orden procesada en la plataforma.</p>\r\n</div>\r\n</div>\r\n<div style=\"background: linear-gradient(135deg, #1d252c 0%, #161c21 100%); padding: clamp(25px, 5%, 40px); border-radius: 20px; border-left: 5px solid #a42eff; margin-bottom: 40px; display: flex; flex-wrap: wrap; align-items: center; box-sizing: border-box;\">\r\n<div style=\"flex: 1; min-width: 280px;\">\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.4rem, 6vw, 1.6rem); margin-top: 0; margin-bottom: 10px;\">Respaldo de Red Activa M&eacute;xico</h3>\r\n<p style=\"color: #cccccc; margin: 0; font-size: clamp(0.95rem, 3vw, 1rem);\">RAM Plaza act&uacute;a como el procesador y gestor de tu orden. Nunca almacenamos los datos sensibles de tus tarjetas, garantizando un entorno de confianza donde tu &uacute;nica preocupaci&oacute;n sea elegir el mejor producto.</p>\r\n</div>\r\n</div>\r\n</div>','Payment Policy','','payment, policy','es',8),(9,'Política de Envío','shipping-policy','<div style=\"background-color: #1d252c; color: #e0e0e0; font-family: \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; line-height: 1.8; padding: clamp(20px, 5%, 40px); border-radius: 20px; width: 100%; box-sizing: border-box;\">\r\n<div style=\"max-width: 900px; margin: 0 auto; text-align: center; margin-bottom: clamp(30px, 5%, 50px);\">\r\n<h2 style=\"font-size: clamp(2rem, 8vw, 3rem); margin-bottom: 10px; color: #ffffff; font-weight: 800; line-height: 1.2;\">Pol&iacute;tica de <span style=\"background: linear-gradient(90deg, #ff2f92 0%, #a42eff 100%); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;\"> Env&iacute;o y Entrega </span></h2>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.2rem); color: rgba(224,224,224,.65); padding: 0 10px; margin: 0;\">Informaci&oacute;n sobre la entrega de servicios digitales y beneficios de aliados.</p>\r\n</div>\r\n<div style=\"margin-bottom: clamp(30px, 5%, 40px); text-align: center; max-width: 800px; margin-left: auto; margin-right: auto;\">\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.1rem); color: rgba(224,224,224,.78); padding: 0 10px; margin: 0;\">RAM Plaza conecta a la comunidad con ahorros garantizados. Mientras que nuestros servicios digitales son inmediatos, los productos f&iacute;sicos adquiridos con descuentos del <strong>10% al 40%</strong> dependen de la log&iacute;stica de cada <strong>Negocio Verificado</strong>.</p>\r\n</div>\r\n<div style=\"display: flex; flex-wrap: wrap; gap: 25px; justify-content: center; margin-bottom: 50px;\"><!-- Card 1 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/92N6hrjjnqnqLpg0YlZR4mO6O6IOOz16Ur9g22tj.svg\" alt=\"digital icon\" width=\"18\" height=\"18\"> </span> Entrega Digital</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">Al adquirir tu <strong>Membres&iacute;a</strong> o activar un cup&oacute;n, la entrega de los beneficios es <strong>inmediata</strong>. Recibir&aacute;s tus accesos y c&oacute;digos de descuento directamente en tu correo electr&oacute;nico registrado y en tu perfil de plataforma.</p>\r\n</div>\r\n<!-- Card 2 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/83cHG3SGZWrJ6E3TyAcECEqFKfjnXbmpxt66r5wO.svg\" alt=\"delivery icon\" width=\"18\" height=\"18\"> </span> Env&iacute;os de Aliados</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">Si utilizas un beneficio para pedir productos a domicilio, <strong>el env&iacute;o es gestionado por el establecimiento aliado</strong>. Los tiempos de entrega y coberturas son definidos por el comercio, asegurando que se aplique tu descuento pactado (10% al 40%) en tu nota final.</p>\r\n</div>\r\n<!-- Card 3 -->\r\n<div style=\"background: rgba(255,255,255,.02); padding: clamp(25px, 4%, 35px); border-radius: 20px; border: 1px solid rgba(255,255,255,.07); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box; box-shadow: none;\">\r\n<h4 style=\"margin-top: 0; color: #ffffff; font-size: clamp(1.2rem, 5vw, 1.4rem); margin-bottom: 15px; display: flex; align-items: center; font-weight: bold;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 34px; height: 34px; border-radius: 12px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 10px;\"> <img style=\"width: 18px; height: 18px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/sEK2eITt4HaXZDko5Dj80YEnTW8cxb0uvpknTnOh.svg\" alt=\"cost icon\" width=\"18\" height=\"18\"> </span> Tarifas y Descuentos</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(224,224,224,.72); line-height: 1.6; margin: 0;\">El acceso a la plataforma RAM Plaza no genera costos de env&iacute;o. Sin embargo, el negocio afiliado podr&iacute;a cobrar una tarifa de entrega independiente al descuento otorgado. Sugerimos confirmar el costo de env&iacute;o con el negocio al realizar tu pedido.</p>\r\n</div>\r\n</div>\r\n<!-- Callout -->\r\n<div style=\"background: linear-gradient(135deg, #1d252c 0%, #161c21 100%); padding: clamp(25px, 5%, 40px); border-radius: 20px; border-left: 5px solid #a42eff; border: 1px solid rgba(255,255,255,.06); margin-bottom: 40px; box-sizing: border-box; box-shadow: none;\">\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.4rem, 6vw, 1.6rem); margin-top: 0; margin-bottom: 20px;\">Responsabilidad en Entregas F&iacute;sicas</h3>\r\n<ul style=\"list-style: none; padding: 0; margin: 0; color: rgba(224,224,224,.78); font-size: clamp(0.95rem, 3vw, 1rem);\">\r\n<li style=\"margin-bottom: 15px; display: flex; align-items: flex-start;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 10px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 15px; flex: 0 0 26px;\"> <img style=\"width: 16px; height: 16px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/Ign7Z75VyH4kEer5gHbF73bKeG79O6ADj0Rwt04I.svg\" alt=\"check\" width=\"16\" height=\"16\"> </span>\r\n<div>RAM Plaza no cuenta con flotilla propia. No nos hacemos responsables por la log&iacute;stica, tiempos de espera o estado de los productos entregados por el negocio aliado o servicios externos.</div>\r\n</li>\r\n<li style=\"margin-bottom: 0; display: flex; align-items: flex-start;\"><span style=\"display: inline-flex; align-items: center; justify-content: center; width: 26px; height: 26px; border-radius: 10px; background: rgba(255,255,255,.04); border: 1px solid rgba(255,255,255,.08); margin-right: 15px; flex: 0 0 26px;\"> <img style=\"width: 16px; height: 16px; display: block; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/Ign7Z75VyH4kEer5gHbF73bKeG79O6ADj0Rwt04I.svg\" alt=\"check\" width=\"16\" height=\"16\"> </span>\r\n<div>El compromiso del aliado es garantizar el descuento del 10% al 40% sobre el valor del producto o servicio contratado.</div>\r\n</li>\r\n</ul>\r\n</div>\r\n</div>','Shipping Policy','','shipping, policy','es',9),(10,'Política de Privacidad','privacy-policy','<div style=\"width: min(1100px, 100%); margin: 32px auto; background: rgba(255,255,255,.06); border: 1px solid rgba(255,255,255,.12); box-shadow: 0 12px 40px rgba(0,0,0,.45); backdrop-filter: blur(12px); -webkit-backdrop-filter: blur(12px); color: rgba(255,255,255,.85); font-family: \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; line-height: 1.8; padding: clamp(20px, 5%, 40px); border-radius: 20px; box-sizing: border-box;\">\r\n<div style=\"max-width: 900px; margin: 0 auto; text-align: center; margin-bottom: clamp(22px, 4%, 40px);\">\r\n<h2 style=\"font-size: clamp(2rem, 8vw, 3rem); margin-bottom: 10px; color: #ffffff; font-weight: 800; line-height: 1.15;\">Aviso de <span style=\"background: linear-gradient(90deg, #ff3e9a 0%, #8b5cf6 100%); -webkit-background-clip: text; -webkit-text-fill-color: transparent;\"> Privacidad </span></h2>\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.2rem); color: rgba(255,255,255,.70); padding: 0 10px;\">C&oacute;mo protegemos y utilizamos tus datos en el ecosistema RAM Plaza.</p>\r\n</div>\r\n<div style=\"margin-bottom: clamp(22px, 4%, 34px); text-align: center; max-width: 850px; margin-left: auto; margin-right: auto;\">\r\n<p style=\"font-size: clamp(1rem, 4vw, 1.05rem); color: rgba(255,255,255,.78); padding: 0 10px;\">En <strong style=\"color: #fff;\">RAM Plaza</strong> (parte de Red Activa M&eacute;xico), valoramos tu confianza. Este documento detalla c&oacute;mo recopilamos, usamos y protegemos tu informaci&oacute;n personal al utilizar nuestra plataforma de beneficios y la generaci&oacute;n de <strong style=\"color: #fff;\">Cupones Digitales</strong> de descuento.</p>\r\n</div>\r\n<div style=\"display: flex; flex-wrap: wrap; gap: 18px; justify-content: center; margin-bottom: 34px;\">\r\n<div style=\"background: rgba(255,255,255,.05); padding: clamp(20px, 4%, 28px); border-radius: 18px; border: 1px solid rgba(255,255,255,.12); flex: 1; min-width: 280px; text-align: left; box-sizing: border-box;\">\r\n<h4 style=\"margin-top: 0; color: #ff3e9a; font-size: clamp(1.15rem, 5vw, 1.35rem); margin-bottom: 12px; display: flex; align-items: center;\"><img style=\"margin-right: 10px; vertical-align: middle; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/z42cc5wIxwJtN1qFk5qvw3mNHIWzNq6dK0cJ44sj.svg\" alt=\"seguridad\" width=\"24\" height=\"24\"> Compartir Datos</h4>\r\n<p style=\"font-size: clamp(0.95rem, 3vw, 1rem); color: rgba(255,255,255,.75); line-height: 1.6; margin: 0;\">No vendemos tus datos a externos. Solo compartimos la validaci&oacute;n de tu membres&iacute;a con el <strong style=\"color: #fff;\">Negocio Afiliado</strong> al momento de solicitar tu descuento del 10% al 40%, para confirmar que tu perfil es leg&iacute;timo y tienes acceso al beneficio pactado.</p>\r\n</div>\r\n</div>\r\n<div style=\"background: linear-gradient(135deg, rgba(255,255,255,.06) 0%, rgba(255,255,255,.03) 100%); padding: clamp(20px, 5%, 32px); border-radius: 18px; border: 1px solid rgba(255,255,255,.12); border-left: 5px solid #8b5cf6; margin-bottom: 32px; box-sizing: border-box;\">\r\n<h3 style=\"color: #ffffff; font-size: clamp(1.25rem, 6vw, 1.5rem); margin-top: 0; margin-bottom: 14px;\">Tus Derechos (ARCO)</h3>\r\n<p style=\"color: rgba(255,255,255,.74); margin-bottom: 14px; font-size: clamp(0.95rem, 3vw, 1rem);\">Como usuario, tienes el control total sobre tu informaci&oacute;n. Puedes ejercer tus derechos en cualquier momento:</p>\r\n<ul style=\"list-style: none; padding: 0; margin: 0; color: rgba(255,255,255,.78); font-size: clamp(0.95rem, 3vw, 1rem);\">\r\n<li style=\"margin-bottom: 12px; display: flex; align-items: start;\"><img style=\"margin-right: 10px; min-width: 20px; vertical-align: middle; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/Ign7Z75VyH4kEer5gHbF73bKeG79O6ADj0Rwt04I.svg\" alt=\"check\" width=\"20\" height=\"20\">\r\n<div><span style=\"color: #ff3e9a; font-weight: bold;\">Acceso:</span> Conocer qu&eacute; datos tenemos de ti.</div>\r\n</li>\r\n<li style=\"margin-bottom: 12px; display: flex; align-items: start;\"><img style=\"margin-right: 10px; min-width: 20px; vertical-align: middle; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/Ign7Z75VyH4kEer5gHbF73bKeG79O6ADj0Rwt04I.svg\" alt=\"check\" width=\"20\" height=\"20\">\r\n<div><span style=\"color: #ff3e9a; font-weight: bold;\">Rectificaci&oacute;n:</span> Corregir datos inexactos en tu perfil.</div>\r\n</li>\r\n<li style=\"margin-bottom: 12px; display: flex; align-items: start;\"><img style=\"margin-right: 10px; min-width: 20px; vertical-align: middle; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/Ign7Z75VyH4kEer5gHbF73bKeG79O6ADj0Rwt04I.svg\" alt=\"check\" width=\"20\" height=\"20\">\r\n<div><span style=\"color: #ff3e9a; font-weight: bold;\">Cancelaci&oacute;n:</span> Solicitar la eliminaci&oacute;n de tu cuenta y datos asociados.</div>\r\n</li>\r\n<li style=\"margin-bottom: 0; display: flex; align-items: start;\"><img style=\"margin-right: 10px; min-width: 20px; vertical-align: middle; filter: brightness(0) invert(1); opacity: .9;\" src=\"https://plaza.redactivamexico.net/storage/tinymce/Ign7Z75VyH4kEer5gHbF73bKeG79O6ADj0Rwt04I.svg\" alt=\"check\" width=\"20\" height=\"20\">\r\n<div><span style=\"color: #ff3e9a; font-weight: bold;\">Oposici&oacute;n:</span> Oponerte a que usemos tus datos para fines espec&iacute;ficos (ej. boletines).</div>\r\n</li>\r\n</ul>\r\n</div>\r\n<div style=\"text-align: left; max-width: 850px; margin: 0 auto; padding: 0 6px;\">\r\n<h4 style=\"color: #ffffff; font-size: clamp(1.1rem, 4vw, 1.25rem); margin: 0 0 8px 0;\">Uso de Cookies</h4>\r\n<p style=\"color: rgba(255,255,255,.65); font-size: clamp(0.9rem, 3vw, 0.95rem); margin: 0;\">Utilizamos cookies temporales para mantener tu sesi&oacute;n activa y recordar tus preferencias de visualizaci&oacute;n (como el modo oscuro) dentro de RAM Plaza. Puedes deshabilitarlas en tu navegador, aunque esto podr&iacute;a afectar la fluidez de tu experiencia al navegar por el cat&aacute;logo de beneficios.</p>\r\n</div>\r\n</div>','Privacy Policy','','privacy, policy','es',10);
/*!40000 ALTER TABLE `cms_page_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cms_pages`
--

DROP TABLE IF EXISTS `cms_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cms_pages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `layout` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cms_pages`
--

LOCK TABLES `cms_pages` WRITE;
/*!40000 ALTER TABLE `cms_pages` DISABLE KEYS */;
INSERT INTO `cms_pages` VALUES (1,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(2,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(3,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(4,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(5,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(6,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(7,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(8,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(9,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(10,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08');
/*!40000 ALTER TABLE `cms_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compare_items`
--

DROP TABLE IF EXISTS `compare_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compare_items` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL,
  `customer_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `compare_items_product_id_foreign` (`product_id`),
  KEY `compare_items_customer_id_foreign` (`customer_id`),
  CONSTRAINT `compare_items_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `compare_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compare_items`
--

LOCK TABLES `compare_items` WRITE;
/*!40000 ALTER TABLE `compare_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `compare_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_config`
--

DROP TABLE IF EXISTS `core_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `core_config` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locale_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_config`
--

LOCK TABLES `core_config` WRITE;
/*!40000 ALTER TABLE `core_config` DISABLE KEYS */;
INSERT INTO `core_config` VALUES (1,'sales.checkout.shopping_cart.allow_guest_checkout','1',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(2,'emails.general.notifications.emails.general.notifications.registration','1',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(3,'emails.general.notifications.emails.general.notifications.customer_registration_confirmation_mail_to_admin','0',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(4,'emails.general.notifications.emails.general.notifications.customer_account_credentials','1',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(5,'emails.general.notifications.emails.general.notifications.new_order','1',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(6,'emails.general.notifications.emails.general.notifications.new_order_mail_to_admin','1',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(7,'emails.general.notifications.emails.general.notifications.new_invoice','1',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(8,'emails.general.notifications.emails.general.notifications.new_invoice_mail_to_admin','0',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(9,'emails.general.notifications.emails.general.notifications.new_refund','1',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(10,'emails.general.notifications.emails.general.notifications.new_refund_mail_to_admin','0',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(11,'emails.general.notifications.emails.general.notifications.new_shipment','1',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(12,'emails.general.notifications.emails.general.notifications.new_shipment_mail_to_admin','0',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(13,'emails.general.notifications.emails.general.notifications.new_inventory_source','1',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(14,'emails.general.notifications.emails.general.notifications.cancel_order','1',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(15,'emails.general.notifications.emails.general.notifications.cancel_order_mail_to_admin','0',NULL,NULL,'2025-12-11 21:04:08','2025-12-11 21:04:08'),(16,'customer.settings.social_login.enable_facebook','0','default',NULL,'2025-12-11 21:04:09','2025-12-27 19:54:09'),(17,'customer.settings.social_login.enable_twitter','0','default',NULL,'2025-12-11 21:04:09','2025-12-27 19:54:09'),(18,'customer.settings.social_login.enable_google','0','default',NULL,'2025-12-11 21:04:09','2025-12-27 19:54:09'),(19,'customer.settings.social_login.enable_linkedin','1','default',NULL,'2025-12-11 21:04:09','2025-12-11 21:04:09'),(20,'customer.settings.social_login.enable_github','0','default',NULL,'2025-12-11 21:04:09','2025-12-27 19:54:10'),(21,'general.design.categories.category_view','default',NULL,NULL,'2025-12-11 21:35:28','2025-12-27 19:57:38'),(24,'general.design.admin_logo.favicon','configuration/OAcg9o2gT3P96VVZsRpdjPvdJTF8hVgACjAiFH3v.png',NULL,NULL,'2025-12-12 12:05:26','2025-12-12 12:05:26'),(25,'general.design.admin_logo.logo_image','configuration/hxflTkAMOZyEZKKWANWtN9rtpDg9ECiVATlccZIj.png',NULL,NULL,'2025-12-12 12:05:39','2025-12-12 12:05:39'),(26,'general.content.header_offer.title','10, 20, 30 y hasta 40 % de descuento!',NULL,NULL,'2025-12-26 11:27:41','2025-12-27 14:48:04'),(27,'general.content.header_offer.redirection_title','ve al Muro LOCO!',NULL,NULL,'2025-12-26 11:27:41','2025-12-27 14:48:04'),(28,'general.content.header_offer.redirection_link','https://redactivamexico.net/muro-loco',NULL,NULL,'2025-12-26 11:27:41','2025-12-27 14:48:04'),(29,'general.content.speculation_rules.enabled','1',NULL,NULL,'2025-12-26 11:27:41','2025-12-26 11:27:41'),(30,'general.content.speculation_rules.prerender_enabled','1',NULL,NULL,'2025-12-26 11:27:41','2025-12-26 11:27:41'),(31,'general.content.speculation_rules.prerender_ignore_urls','account|checkout|onepage|cart',NULL,NULL,'2025-12-26 11:27:41','2025-12-26 11:27:41'),(32,'general.content.speculation_rules.prerender_ignore_url_params','',NULL,NULL,'2025-12-26 11:27:42','2025-12-26 11:27:42'),(33,'general.content.speculation_rules.prerender_eagerness','moderate',NULL,NULL,'2025-12-26 11:27:42','2025-12-26 11:27:42'),(34,'general.content.speculation_rules.prefetch_enabled','0',NULL,NULL,'2025-12-26 11:27:42','2025-12-26 11:27:42'),(35,'general.content.custom_scripts.custom_css','','default',NULL,'2025-12-26 11:27:42','2025-12-29 09:09:14'),(36,'general.content.custom_scripts.custom_javascript','','default',NULL,'2025-12-26 11:27:42','2025-12-27 14:47:05'),(37,'customer.settings.wishlist.wishlist_option','1',NULL,NULL,'2025-12-27 19:54:08','2025-12-27 19:54:08'),(38,'customer.settings.login_options.redirected_to_page','home',NULL,NULL,'2025-12-27 19:54:08','2025-12-27 19:54:08'),(39,'customer.settings.create_new_account_options.default_group','general',NULL,NULL,'2025-12-27 19:54:08','2025-12-27 19:54:08'),(40,'customer.settings.create_new_account_options.news_letter','1',NULL,NULL,'2025-12-27 19:54:08','2025-12-27 19:54:08'),(41,'customer.settings.newsletter.subscription','1',NULL,NULL,'2025-12-27 19:54:09','2025-12-27 19:54:09'),(42,'customer.settings.email.verification','0',NULL,NULL,'2025-12-27 19:54:09','2025-12-27 19:54:09'),(43,'customer.settings.social_login.enable_linkedin-openid','0','default',NULL,'2025-12-27 19:54:10','2025-12-27 19:54:10'),(44,'catalog.rich_snippets.products.enable','0',NULL,NULL,'2025-12-27 19:55:02','2025-12-27 19:55:02'),(45,'catalog.rich_snippets.products.show_sku','0',NULL,NULL,'2025-12-27 19:55:04','2025-12-27 19:55:04'),(46,'catalog.rich_snippets.products.show_weight','0',NULL,NULL,'2025-12-27 19:55:06','2025-12-27 19:55:06'),(47,'catalog.rich_snippets.products.show_categories','0',NULL,NULL,'2025-12-27 19:55:06','2025-12-27 19:55:06'),(48,'catalog.rich_snippets.products.show_images','0',NULL,NULL,'2025-12-27 19:55:06','2025-12-27 19:55:06'),(49,'catalog.rich_snippets.products.show_reviews','0',NULL,NULL,'2025-12-27 19:55:08','2025-12-27 19:55:08'),(50,'catalog.rich_snippets.products.show_ratings','0',NULL,NULL,'2025-12-27 19:55:08','2025-12-27 19:55:08'),(51,'catalog.rich_snippets.products.show_offers','0',NULL,NULL,'2025-12-27 19:55:08','2025-12-27 19:55:08'),(52,'catalog.rich_snippets.categories.enable','1',NULL,NULL,'2025-12-27 19:55:09','2025-12-27 19:55:09'),(53,'catalog.rich_snippets.categories.show_search_input_field','0',NULL,NULL,'2025-12-27 19:55:09','2025-12-27 19:55:09'),(54,'catalog.products.settings.compare_option','1',NULL,NULL,'2025-12-27 19:56:43','2025-12-27 19:56:43'),(55,'catalog.products.settings.image_search','1',NULL,NULL,'2025-12-27 19:56:43','2025-12-27 19:56:43'),(56,'catalog.products.search.engine','database',NULL,NULL,'2025-12-27 19:56:44','2025-12-27 19:56:44'),(57,'catalog.products.search.admin_mode','database',NULL,NULL,'2025-12-27 19:56:44','2025-12-27 19:56:44'),(58,'catalog.products.search.storefront_mode','database',NULL,NULL,'2025-12-27 19:56:44','2025-12-27 19:56:44'),(59,'catalog.products.search.min_query_length','0',NULL,NULL,'2025-12-27 19:56:44','2025-12-27 19:56:44'),(60,'catalog.products.search.max_query_length','1000',NULL,NULL,'2025-12-27 19:56:44','2025-12-27 19:56:44'),(61,'catalog.products.product_view_page.no_of_related_products','',NULL,NULL,'2025-12-27 19:56:45','2025-12-27 19:56:45'),(62,'catalog.products.product_view_page.no_of_up_sells_products','',NULL,NULL,'2025-12-27 19:56:45','2025-12-27 19:56:45'),(63,'catalog.products.cart_view_page.no_of_cross_sells_products','',NULL,NULL,'2025-12-27 19:56:45','2025-12-27 19:56:45'),(64,'catalog.products.storefront.mode','grid','default',NULL,'2025-12-27 19:56:45','2025-12-27 19:56:45'),(65,'catalog.products.storefront.products_per_page','4','default',NULL,'2025-12-27 19:56:46','2025-12-27 19:56:46'),(66,'catalog.products.storefront.sort_by','created_at-desc','default',NULL,'2025-12-27 19:56:46','2025-12-27 19:56:46'),(67,'catalog.products.storefront.buy_now_button_display','0',NULL,NULL,'2025-12-27 19:56:46','2025-12-27 19:56:46'),(68,'catalog.products.cache_small_image.width','',NULL,NULL,'2025-12-27 19:56:46','2025-12-27 19:56:46'),(69,'catalog.products.cache_small_image.height','',NULL,NULL,'2025-12-27 19:56:46','2025-12-27 19:56:46'),(70,'catalog.products.cache_medium_image.width','',NULL,NULL,'2025-12-27 19:56:46','2025-12-27 19:56:46'),(71,'catalog.products.cache_medium_image.height','',NULL,NULL,'2025-12-27 19:56:47','2025-12-27 19:56:47'),(72,'catalog.products.cache_large_image.width','',NULL,NULL,'2025-12-27 19:56:47','2025-12-27 19:56:47'),(73,'catalog.products.cache_large_image.height','',NULL,NULL,'2025-12-27 19:56:47','2025-12-27 19:56:47'),(74,'catalog.products.review.guest_review','0',NULL,NULL,'2025-12-27 19:56:47','2025-12-27 19:56:47'),(75,'catalog.products.review.customer_review','1',NULL,NULL,'2025-12-27 19:56:48','2025-12-27 19:56:48'),(76,'catalog.products.review.censoring_reviewer_name','1',NULL,NULL,'2025-12-27 19:56:48','2025-12-27 19:56:48'),(77,'catalog.products.review.summary','review_counts',NULL,NULL,'2025-12-27 19:56:48','2025-12-27 19:56:48'),(78,'catalog.products.attribute.image_attribute_upload_size','',NULL,NULL,'2025-12-27 19:56:48','2025-12-27 19:56:48'),(79,'catalog.products.attribute.file_attribute_upload_size','',NULL,NULL,'2025-12-27 19:56:48','2025-12-27 19:56:48'),(80,'catalog.products.social_share.enabled','0',NULL,NULL,'2025-12-27 19:56:49','2025-12-27 19:56:49'),(81,'catalog.products.social_share.facebook','0',NULL,NULL,'2025-12-27 19:56:49','2025-12-27 19:56:49'),(82,'catalog.products.social_share.twitter','0',NULL,NULL,'2025-12-27 19:56:49','2025-12-27 19:56:49'),(83,'catalog.products.social_share.pinterest','0',NULL,NULL,'2025-12-27 19:56:49','2025-12-27 19:56:49'),(84,'catalog.products.social_share.whatsapp','0',NULL,NULL,'2025-12-27 19:56:50','2025-12-27 19:56:50'),(85,'catalog.products.social_share.linkedin','0',NULL,NULL,'2025-12-27 19:56:50','2025-12-27 19:56:50'),(86,'catalog.products.social_share.email','0',NULL,NULL,'2025-12-27 19:56:50','2025-12-27 19:56:50'),(87,'catalog.products.social_share.share_message','',NULL,NULL,'2025-12-27 19:56:50','2025-12-27 19:56:50');
/*!40000 ALTER TABLE `core_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'AF','Afghanistan'),(2,'AX','Åland Islands'),(3,'AL','Albania'),(4,'DZ','Algeria'),(5,'AS','American Samoa'),(6,'AD','Andorra'),(7,'AO','Angola'),(8,'AI','Anguilla'),(9,'AQ','Antarctica'),(10,'AG','Antigua & Barbuda'),(11,'AR','Argentina'),(12,'AM','Armenia'),(13,'AW','Aruba'),(14,'AC','Ascension Island'),(15,'AU','Australia'),(16,'AT','Austria'),(17,'AZ','Azerbaijan'),(18,'BS','Bahamas'),(19,'BH','Bahrain'),(20,'BD','Bangladesh'),(21,'BB','Barbados'),(22,'BY','Belarus'),(23,'BE','Belgium'),(24,'BZ','Belize'),(25,'BJ','Benin'),(26,'BM','Bermuda'),(27,'BT','Bhutan'),(28,'BO','Bolivia'),(29,'BA','Bosnia & Herzegovina'),(30,'BW','Botswana'),(31,'BR','Brazil'),(32,'IO','British Indian Ocean Territory'),(33,'VG','British Virgin Islands'),(34,'BN','Brunei'),(35,'BG','Bulgaria'),(36,'BF','Burkina Faso'),(37,'BI','Burundi'),(38,'KH','Cambodia'),(39,'CM','Cameroon'),(40,'CA','Canada'),(41,'IC','Canary Islands'),(42,'CV','Cape Verde'),(43,'BQ','Caribbean Netherlands'),(44,'KY','Cayman Islands'),(45,'CF','Central African Republic'),(46,'EA','Ceuta & Melilla'),(47,'TD','Chad'),(48,'CL','Chile'),(49,'CN','China'),(50,'CX','Christmas Island'),(51,'CC','Cocos (Keeling) Islands'),(52,'CO','Colombia'),(53,'KM','Comoros'),(54,'CG','Congo - Brazzaville'),(55,'CD','Congo - Kinshasa'),(56,'CK','Cook Islands'),(57,'CR','Costa Rica'),(58,'CI','Côte d’Ivoire'),(59,'HR','Croatia'),(60,'CU','Cuba'),(61,'CW','Curaçao'),(62,'CY','Cyprus'),(63,'CZ','Czechia'),(64,'DK','Denmark'),(65,'DG','Diego Garcia'),(66,'DJ','Djibouti'),(67,'DM','Dominica'),(68,'DO','Dominican Republic'),(69,'EC','Ecuador'),(70,'EG','Egypt'),(71,'SV','El Salvador'),(72,'GQ','Equatorial Guinea'),(73,'ER','Eritrea'),(74,'EE','Estonia'),(75,'ET','Ethiopia'),(76,'EZ','Eurozone'),(77,'FK','Falkland Islands'),(78,'FO','Faroe Islands'),(79,'FJ','Fiji'),(80,'FI','Finland'),(81,'FR','France'),(82,'GF','French Guiana'),(83,'PF','French Polynesia'),(84,'TF','French Southern Territories'),(85,'GA','Gabon'),(86,'GM','Gambia'),(87,'GE','Georgia'),(88,'DE','Germany'),(89,'GH','Ghana'),(90,'GI','Gibraltar'),(91,'GR','Greece'),(92,'GL','Greenland'),(93,'GD','Grenada'),(94,'GP','Guadeloupe'),(95,'GU','Guam'),(96,'GT','Guatemala'),(97,'GG','Guernsey'),(98,'GN','Guinea'),(99,'GW','Guinea-Bissau'),(100,'GY','Guyana'),(101,'HT','Haiti'),(102,'HN','Honduras'),(103,'HK','Hong Kong SAR China'),(104,'HU','Hungary'),(105,'IS','Iceland'),(106,'IN','India'),(107,'ID','Indonesia'),(108,'IR','Iran'),(109,'IQ','Iraq'),(110,'IE','Ireland'),(111,'IM','Isle of Man'),(112,'IL','Israel'),(113,'IT','Italy'),(114,'JM','Jamaica'),(115,'JP','Japan'),(116,'JE','Jersey'),(117,'JO','Jordan'),(118,'KZ','Kazakhstan'),(119,'KE','Kenya'),(120,'KI','Kiribati'),(121,'XK','Kosovo'),(122,'KW','Kuwait'),(123,'KG','Kyrgyzstan'),(124,'LA','Laos'),(125,'LV','Latvia'),(126,'LB','Lebanon'),(127,'LS','Lesotho'),(128,'LR','Liberia'),(129,'LY','Libya'),(130,'LI','Liechtenstein'),(131,'LT','Lithuania'),(132,'LU','Luxembourg'),(133,'MO','Macau SAR China'),(134,'MK','Macedonia'),(135,'MG','Madagascar'),(136,'MW','Malawi'),(137,'MY','Malaysia'),(138,'MV','Maldives'),(139,'ML','Mali'),(140,'MT','Malta'),(141,'MH','Marshall Islands'),(142,'MQ','Martinique'),(143,'MR','Mauritania'),(144,'MU','Mauritius'),(145,'YT','Mayotte'),(146,'MX','Mexico'),(147,'FM','Micronesia'),(148,'MD','Moldova'),(149,'MC','Monaco'),(150,'MN','Mongolia'),(151,'ME','Montenegro'),(152,'MS','Montserrat'),(153,'MA','Morocco'),(154,'MZ','Mozambique'),(155,'MM','Myanmar (Burma)'),(156,'NA','Namibia'),(157,'NR','Nauru'),(158,'NP','Nepal'),(159,'NL','Netherlands'),(160,'NC','New Caledonia'),(161,'NZ','New Zealand'),(162,'NI','Nicaragua'),(163,'NE','Niger'),(164,'NG','Nigeria'),(165,'NU','Niue'),(166,'NF','Norfolk Island'),(167,'KP','North Korea'),(168,'MP','Northern Mariana Islands'),(169,'NO','Norway'),(170,'OM','Oman'),(171,'PK','Pakistan'),(172,'PW','Palau'),(173,'PS','Palestinian Territories'),(174,'PA','Panama'),(175,'PG','Papua New Guinea'),(176,'PY','Paraguay'),(177,'PE','Peru'),(178,'PH','Philippines'),(179,'PN','Pitcairn Islands'),(180,'PL','Poland'),(181,'PT','Portugal'),(182,'PR','Puerto Rico'),(183,'QA','Qatar'),(184,'RE','Réunion'),(185,'RO','Romania'),(186,'RU','Russia'),(187,'RW','Rwanda'),(188,'WS','Samoa'),(189,'SM','San Marino'),(190,'ST','São Tomé & Príncipe'),(191,'SA','Saudi Arabia'),(192,'SN','Senegal'),(193,'RS','Serbia'),(194,'SC','Seychelles'),(195,'SL','Sierra Leone'),(196,'SG','Singapore'),(197,'SX','Sint Maarten'),(198,'SK','Slovakia'),(199,'SI','Slovenia'),(200,'SB','Solomon Islands'),(201,'SO','Somalia'),(202,'ZA','South Africa'),(203,'GS','South Georgia & South Sandwich Islands'),(204,'KR','South Korea'),(205,'SS','South Sudan'),(206,'ES','Spain'),(207,'LK','Sri Lanka'),(208,'BL','St. Barthélemy'),(209,'SH','St. Helena'),(210,'KN','St. Kitts & Nevis'),(211,'LC','St. Lucia'),(212,'MF','St. Martin'),(213,'PM','St. Pierre & Miquelon'),(214,'VC','St. Vincent & Grenadines'),(215,'SD','Sudan'),(216,'SR','Suriname'),(217,'SJ','Svalbard & Jan Mayen'),(218,'SZ','Swaziland'),(219,'SE','Sweden'),(220,'CH','Switzerland'),(221,'SY','Syria'),(222,'TW','Taiwan'),(223,'TJ','Tajikistan'),(224,'TZ','Tanzania'),(225,'TH','Thailand'),(226,'TL','Timor-Leste'),(227,'TG','Togo'),(228,'TK','Tokelau'),(229,'TO','Tonga'),(230,'TT','Trinidad & Tobago'),(231,'TA','Tristan da Cunha'),(232,'TN','Tunisia'),(233,'TR','Turkey'),(234,'TM','Turkmenistan'),(235,'TC','Turks & Caicos Islands'),(236,'TV','Tuvalu'),(237,'UM','U.S. Outlying Islands'),(238,'VI','U.S. Virgin Islands'),(239,'UG','Uganda'),(240,'UA','Ukraine'),(241,'AE','United Arab Emirates'),(242,'GB','United Kingdom'),(244,'US','United States'),(245,'UY','Uruguay'),(246,'UZ','Uzbekistan'),(247,'VU','Vanuatu'),(248,'VA','Vatican City'),(249,'VE','Venezuela'),(250,'VN','Vietnam'),(251,'WF','Wallis & Futuna'),(252,'EH','Western Sahara'),(253,'YE','Yemen'),(254,'ZM','Zambia'),(255,'ZW','Zimbabwe');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country_state_translations`
--

DROP TABLE IF EXISTS `country_state_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_state_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `country_state_id` int unsigned NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_name` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `country_state_translations_country_state_id_foreign` (`country_state_id`),
  CONSTRAINT `country_state_translations_country_state_id_foreign` FOREIGN KEY (`country_state_id`) REFERENCES `country_states` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country_state_translations`
--

LOCK TABLES `country_state_translations` WRITE;
/*!40000 ALTER TABLE `country_state_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `country_state_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country_states`
--

DROP TABLE IF EXISTS `country_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_states` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `country_id` int unsigned DEFAULT NULL,
  `country_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `country_states_country_id_foreign` (`country_id`),
  CONSTRAINT `country_states_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=587 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country_states`
--

LOCK TABLES `country_states` WRITE;
/*!40000 ALTER TABLE `country_states` DISABLE KEYS */;
INSERT INTO `country_states` VALUES (1,244,'US','AL','Alabama'),(2,244,'US','AK','Alaska'),(3,244,'US','AS','American Samoa'),(4,244,'US','AZ','Arizona'),(5,244,'US','AR','Arkansas'),(6,244,'US','AE','Armed Forces Africa'),(7,244,'US','AA','Armed Forces Americas'),(8,244,'US','AE','Armed Forces Canada'),(9,244,'US','AE','Armed Forces Europe'),(10,244,'US','AE','Armed Forces Middle East'),(11,244,'US','AP','Armed Forces Pacific'),(12,244,'US','CA','California'),(13,244,'US','CO','Colorado'),(14,244,'US','CT','Connecticut'),(15,244,'US','DE','Delaware'),(16,244,'US','DC','District of Columbia'),(17,244,'US','FM','Federated States Of Micronesia'),(18,244,'US','FL','Florida'),(19,244,'US','GA','Georgia'),(20,244,'US','GU','Guam'),(21,244,'US','HI','Hawaii'),(22,244,'US','ID','Idaho'),(23,244,'US','IL','Illinois'),(24,244,'US','IN','Indiana'),(25,244,'US','IA','Iowa'),(26,244,'US','KS','Kansas'),(27,244,'US','KY','Kentucky'),(28,244,'US','LA','Louisiana'),(29,244,'US','ME','Maine'),(30,244,'US','MH','Marshall Islands'),(31,244,'US','MD','Maryland'),(32,244,'US','MA','Massachusetts'),(33,244,'US','MI','Michigan'),(34,244,'US','MN','Minnesota'),(35,244,'US','MS','Mississippi'),(36,244,'US','MO','Missouri'),(37,244,'US','MT','Montana'),(38,244,'US','NE','Nebraska'),(39,244,'US','NV','Nevada'),(40,244,'US','NH','New Hampshire'),(41,244,'US','NJ','New Jersey'),(42,244,'US','NM','New Mexico'),(43,244,'US','NY','New York'),(44,244,'US','NC','North Carolina'),(45,244,'US','ND','North Dakota'),(46,244,'US','MP','Northern Mariana Islands'),(47,244,'US','OH','Ohio'),(48,244,'US','OK','Oklahoma'),(49,244,'US','OR','Oregon'),(50,244,'US','PW','Palau'),(51,244,'US','PA','Pennsylvania'),(52,244,'US','PR','Puerto Rico'),(53,244,'US','RI','Rhode Island'),(54,244,'US','SC','South Carolina'),(55,244,'US','SD','South Dakota'),(56,244,'US','TN','Tennessee'),(57,244,'US','TX','Texas'),(58,244,'US','UT','Utah'),(59,244,'US','VT','Vermont'),(60,244,'US','VI','Virgin Islands'),(61,244,'US','VA','Virginia'),(62,244,'US','WA','Washington'),(63,244,'US','WV','West Virginia'),(64,244,'US','WI','Wisconsin'),(65,244,'US','WY','Wyoming'),(66,40,'CA','AB','Alberta'),(67,40,'CA','BC','British Columbia'),(68,40,'CA','MB','Manitoba'),(69,40,'CA','NL','Newfoundland and Labrador'),(70,40,'CA','NB','New Brunswick'),(71,40,'CA','NS','Nova Scotia'),(72,40,'CA','NT','Northwest Territories'),(73,40,'CA','NU','Nunavut'),(74,40,'CA','ON','Ontario'),(75,40,'CA','PE','Prince Edward Island'),(76,40,'CA','QC','Quebec'),(77,40,'CA','SK','Saskatchewan'),(78,40,'CA','YT','Yukon Territory'),(79,88,'DE','NDS','Niedersachsen'),(80,88,'DE','BAW','Baden-Württemberg'),(81,88,'DE','BAY','Bayern'),(82,88,'DE','BER','Berlin'),(83,88,'DE','BRG','Brandenburg'),(84,88,'DE','BRE','Bremen'),(85,88,'DE','HAM','Hamburg'),(86,88,'DE','HES','Hessen'),(87,88,'DE','MEC','Mecklenburg-Vorpommern'),(88,88,'DE','NRW','Nordrhein-Westfalen'),(89,88,'DE','RHE','Rheinland-Pfalz'),(90,88,'DE','SAR','Saarland'),(91,88,'DE','SAS','Sachsen'),(92,88,'DE','SAC','Sachsen-Anhalt'),(93,88,'DE','SCN','Schleswig-Holstein'),(94,88,'DE','THE','Thüringen'),(95,16,'AT','WI','Wien'),(96,16,'AT','NO','Niederösterreich'),(97,16,'AT','OO','Oberösterreich'),(98,16,'AT','SB','Salzburg'),(99,16,'AT','KN','Kärnten'),(100,16,'AT','ST','Steiermark'),(101,16,'AT','TI','Tirol'),(102,16,'AT','BL','Burgenland'),(103,16,'AT','VB','Vorarlberg'),(104,220,'CH','AG','Aargau'),(105,220,'CH','AI','Appenzell Innerrhoden'),(106,220,'CH','AR','Appenzell Ausserrhoden'),(107,220,'CH','BE','Bern'),(108,220,'CH','BL','Basel-Landschaft'),(109,220,'CH','BS','Basel-Stadt'),(110,220,'CH','FR','Freiburg'),(111,220,'CH','GE','Genf'),(112,220,'CH','GL','Glarus'),(113,220,'CH','GR','Graubünden'),(114,220,'CH','JU','Jura'),(115,220,'CH','LU','Luzern'),(116,220,'CH','NE','Neuenburg'),(117,220,'CH','NW','Nidwalden'),(118,220,'CH','OW','Obwalden'),(119,220,'CH','SG','St. Gallen'),(120,220,'CH','SH','Schaffhausen'),(121,220,'CH','SO','Solothurn'),(122,220,'CH','SZ','Schwyz'),(123,220,'CH','TG','Thurgau'),(124,220,'CH','TI','Tessin'),(125,220,'CH','UR','Uri'),(126,220,'CH','VD','Waadt'),(127,220,'CH','VS','Wallis'),(128,220,'CH','ZG','Zug'),(129,220,'CH','ZH','Zürich'),(130,206,'ES','A Coruсa','A Coruña'),(131,206,'ES','Alava','Alava'),(132,206,'ES','Albacete','Albacete'),(133,206,'ES','Alicante','Alicante'),(134,206,'ES','Almeria','Almeria'),(135,206,'ES','Asturias','Asturias'),(136,206,'ES','Avila','Avila'),(137,206,'ES','Badajoz','Badajoz'),(138,206,'ES','Baleares','Baleares'),(139,206,'ES','Barcelona','Barcelona'),(140,206,'ES','Burgos','Burgos'),(141,206,'ES','Caceres','Caceres'),(142,206,'ES','Cadiz','Cadiz'),(143,206,'ES','Cantabria','Cantabria'),(144,206,'ES','Castellon','Castellon'),(145,206,'ES','Ceuta','Ceuta'),(146,206,'ES','Ciudad Real','Ciudad Real'),(147,206,'ES','Cordoba','Cordoba'),(148,206,'ES','Cuenca','Cuenca'),(149,206,'ES','Girona','Girona'),(150,206,'ES','Granada','Granada'),(151,206,'ES','Guadalajara','Guadalajara'),(152,206,'ES','Guipuzcoa','Guipuzcoa'),(153,206,'ES','Huelva','Huelva'),(154,206,'ES','Huesca','Huesca'),(155,206,'ES','Jaen','Jaen'),(156,206,'ES','La Rioja','La Rioja'),(157,206,'ES','Las Palmas','Las Palmas'),(158,206,'ES','Leon','Leon'),(159,206,'ES','Lleida','Lleida'),(160,206,'ES','Lugo','Lugo'),(161,206,'ES','Madrid','Madrid'),(162,206,'ES','Malaga','Malaga'),(163,206,'ES','Melilla','Melilla'),(164,206,'ES','Murcia','Murcia'),(165,206,'ES','Navarra','Navarra'),(166,206,'ES','Ourense','Ourense'),(167,206,'ES','Palencia','Palencia'),(168,206,'ES','Pontevedra','Pontevedra'),(169,206,'ES','Salamanca','Salamanca'),(170,206,'ES','Santa Cruz de Tenerife','Santa Cruz de Tenerife'),(171,206,'ES','Segovia','Segovia'),(172,206,'ES','Sevilla','Sevilla'),(173,206,'ES','Soria','Soria'),(174,206,'ES','Tarragona','Tarragona'),(175,206,'ES','Teruel','Teruel'),(176,206,'ES','Toledo','Toledo'),(177,206,'ES','Valencia','Valencia'),(178,206,'ES','Valladolid','Valladolid'),(179,206,'ES','Vizcaya','Vizcaya'),(180,206,'ES','Zamora','Zamora'),(181,206,'ES','Zaragoza','Zaragoza'),(182,81,'FR','1','Ain'),(183,81,'FR','2','Aisne'),(184,81,'FR','3','Allier'),(185,81,'FR','4','Alpes-de-Haute-Provence'),(186,81,'FR','5','Hautes-Alpes'),(187,81,'FR','6','Alpes-Maritimes'),(188,81,'FR','7','Ardèche'),(189,81,'FR','8','Ardennes'),(190,81,'FR','9','Ariège'),(191,81,'FR','10','Aube'),(192,81,'FR','11','Aude'),(193,81,'FR','12','Aveyron'),(194,81,'FR','13','Bouches-du-Rhône'),(195,81,'FR','14','Calvados'),(196,81,'FR','15','Cantal'),(197,81,'FR','16','Charente'),(198,81,'FR','17','Charente-Maritime'),(199,81,'FR','18','Cher'),(200,81,'FR','19','Corrèze'),(201,81,'FR','2A','Corse-du-Sud'),(202,81,'FR','2B','Haute-Corse'),(203,81,'FR','21','Côte-d\'Or'),(204,81,'FR','22','Côtes-d\'Armor'),(205,81,'FR','23','Creuse'),(206,81,'FR','24','Dordogne'),(207,81,'FR','25','Doubs'),(208,81,'FR','26','Drôme'),(209,81,'FR','27','Eure'),(210,81,'FR','28','Eure-et-Loir'),(211,81,'FR','29','Finistère'),(212,81,'FR','30','Gard'),(213,81,'FR','31','Haute-Garonne'),(214,81,'FR','32','Gers'),(215,81,'FR','33','Gironde'),(216,81,'FR','34','Hérault'),(217,81,'FR','35','Ille-et-Vilaine'),(218,81,'FR','36','Indre'),(219,81,'FR','37','Indre-et-Loire'),(220,81,'FR','38','Isère'),(221,81,'FR','39','Jura'),(222,81,'FR','40','Landes'),(223,81,'FR','41','Loir-et-Cher'),(224,81,'FR','42','Loire'),(225,81,'FR','43','Haute-Loire'),(226,81,'FR','44','Loire-Atlantique'),(227,81,'FR','45','Loiret'),(228,81,'FR','46','Lot'),(229,81,'FR','47','Lot-et-Garonne'),(230,81,'FR','48','Lozère'),(231,81,'FR','49','Maine-et-Loire'),(232,81,'FR','50','Manche'),(233,81,'FR','51','Marne'),(234,81,'FR','52','Haute-Marne'),(235,81,'FR','53','Mayenne'),(236,81,'FR','54','Meurthe-et-Moselle'),(237,81,'FR','55','Meuse'),(238,81,'FR','56','Morbihan'),(239,81,'FR','57','Moselle'),(240,81,'FR','58','Nièvre'),(241,81,'FR','59','Nord'),(242,81,'FR','60','Oise'),(243,81,'FR','61','Orne'),(244,81,'FR','62','Pas-de-Calais'),(245,81,'FR','63','Puy-de-Dôme'),(246,81,'FR','64','Pyrénées-Atlantiques'),(247,81,'FR','65','Hautes-Pyrénées'),(248,81,'FR','66','Pyrénées-Orientales'),(249,81,'FR','67','Bas-Rhin'),(250,81,'FR','68','Haut-Rhin'),(251,81,'FR','69','Rhône'),(252,81,'FR','70','Haute-Saône'),(253,81,'FR','71','Saône-et-Loire'),(254,81,'FR','72','Sarthe'),(255,81,'FR','73','Savoie'),(256,81,'FR','74','Haute-Savoie'),(257,81,'FR','75','Paris'),(258,81,'FR','76','Seine-Maritime'),(259,81,'FR','77','Seine-et-Marne'),(260,81,'FR','78','Yvelines'),(261,81,'FR','79','Deux-Sèvres'),(262,81,'FR','80','Somme'),(263,81,'FR','81','Tarn'),(264,81,'FR','82','Tarn-et-Garonne'),(265,81,'FR','83','Var'),(266,81,'FR','84','Vaucluse'),(267,81,'FR','85','Vendée'),(268,81,'FR','86','Vienne'),(269,81,'FR','87','Haute-Vienne'),(270,81,'FR','88','Vosges'),(271,81,'FR','89','Yonne'),(272,81,'FR','90','Territoire-de-Belfort'),(273,81,'FR','91','Essonne'),(274,81,'FR','92','Hauts-de-Seine'),(275,81,'FR','93','Seine-Saint-Denis'),(276,81,'FR','94','Val-de-Marne'),(277,81,'FR','95','Val-d\'Oise'),(278,185,'RO','AB','Alba'),(279,185,'RO','AR','Arad'),(280,185,'RO','AG','Argeş'),(281,185,'RO','BC','Bacău'),(282,185,'RO','BH','Bihor'),(283,185,'RO','BN','Bistriţa-Năsăud'),(284,185,'RO','BT','Botoşani'),(285,185,'RO','BV','Braşov'),(286,185,'RO','BR','Brăila'),(287,185,'RO','B','Bucureşti'),(288,185,'RO','BZ','Buzău'),(289,185,'RO','CS','Caraş-Severin'),(290,185,'RO','CL','Călăraşi'),(291,185,'RO','CJ','Cluj'),(292,185,'RO','CT','Constanţa'),(293,185,'RO','CV','Covasna'),(294,185,'RO','DB','Dâmboviţa'),(295,185,'RO','DJ','Dolj'),(296,185,'RO','GL','Galaţi'),(297,185,'RO','GR','Giurgiu'),(298,185,'RO','GJ','Gorj'),(299,185,'RO','HR','Harghita'),(300,185,'RO','HD','Hunedoara'),(301,185,'RO','IL','Ialomiţa'),(302,185,'RO','IS','Iaşi'),(303,185,'RO','IF','Ilfov'),(304,185,'RO','MM','Maramureş'),(305,185,'RO','MH','Mehedinţi'),(306,185,'RO','MS','Mureş'),(307,185,'RO','NT','Neamţ'),(308,185,'RO','OT','Olt'),(309,185,'RO','PH','Prahova'),(310,185,'RO','SM','Satu-Mare'),(311,185,'RO','SJ','Sălaj'),(312,185,'RO','SB','Sibiu'),(313,185,'RO','SV','Suceava'),(314,185,'RO','TR','Teleorman'),(315,185,'RO','TM','Timiş'),(316,185,'RO','TL','Tulcea'),(317,185,'RO','VS','Vaslui'),(318,185,'RO','VL','Vâlcea'),(319,185,'RO','VN','Vrancea'),(320,80,'FI','Lappi','Lappi'),(321,80,'FI','Pohjois-Pohjanmaa','Pohjois-Pohjanmaa'),(322,80,'FI','Kainuu','Kainuu'),(323,80,'FI','Pohjois-Karjala','Pohjois-Karjala'),(324,80,'FI','Pohjois-Savo','Pohjois-Savo'),(325,80,'FI','Etelä-Savo','Etelä-Savo'),(326,80,'FI','Etelä-Pohjanmaa','Etelä-Pohjanmaa'),(327,80,'FI','Pohjanmaa','Pohjanmaa'),(328,80,'FI','Pirkanmaa','Pirkanmaa'),(329,80,'FI','Satakunta','Satakunta'),(330,80,'FI','Keski-Pohjanmaa','Keski-Pohjanmaa'),(331,80,'FI','Keski-Suomi','Keski-Suomi'),(332,80,'FI','Varsinais-Suomi','Varsinais-Suomi'),(333,80,'FI','Etelä-Karjala','Etelä-Karjala'),(334,80,'FI','Päijät-Häme','Päijät-Häme'),(335,80,'FI','Kanta-Häme','Kanta-Häme'),(336,80,'FI','Uusimaa','Uusimaa'),(337,80,'FI','Itä-Uusimaa','Itä-Uusimaa'),(338,80,'FI','Kymenlaakso','Kymenlaakso'),(339,80,'FI','Ahvenanmaa','Ahvenanmaa'),(340,74,'EE','EE-37','Harjumaa'),(341,74,'EE','EE-39','Hiiumaa'),(342,74,'EE','EE-44','Ida-Virumaa'),(343,74,'EE','EE-49','Jõgevamaa'),(344,74,'EE','EE-51','Järvamaa'),(345,74,'EE','EE-57','Läänemaa'),(346,74,'EE','EE-59','Lääne-Virumaa'),(347,74,'EE','EE-65','Põlvamaa'),(348,74,'EE','EE-67','Pärnumaa'),(349,74,'EE','EE-70','Raplamaa'),(350,74,'EE','EE-74','Saaremaa'),(351,74,'EE','EE-78','Tartumaa'),(352,74,'EE','EE-82','Valgamaa'),(353,74,'EE','EE-84','Viljandimaa'),(354,74,'EE','EE-86','Võrumaa'),(355,125,'LV','LV-DGV','Daugavpils'),(356,125,'LV','LV-JEL','Jelgava'),(357,125,'LV','Jēkabpils','Jēkabpils'),(358,125,'LV','LV-JUR','Jūrmala'),(359,125,'LV','LV-LPX','Liepāja'),(360,125,'LV','LV-LE','Liepājas novads'),(361,125,'LV','LV-REZ','Rēzekne'),(362,125,'LV','LV-RIX','Rīga'),(363,125,'LV','LV-RI','Rīgas novads'),(364,125,'LV','Valmiera','Valmiera'),(365,125,'LV','LV-VEN','Ventspils'),(366,125,'LV','Aglonas novads','Aglonas novads'),(367,125,'LV','LV-AI','Aizkraukles novads'),(368,125,'LV','Aizputes novads','Aizputes novads'),(369,125,'LV','Aknīstes novads','Aknīstes novads'),(370,125,'LV','Alojas novads','Alojas novads'),(371,125,'LV','Alsungas novads','Alsungas novads'),(372,125,'LV','LV-AL','Alūksnes novads'),(373,125,'LV','Amatas novads','Amatas novads'),(374,125,'LV','Apes novads','Apes novads'),(375,125,'LV','Auces novads','Auces novads'),(376,125,'LV','Babītes novads','Babītes novads'),(377,125,'LV','Baldones novads','Baldones novads'),(378,125,'LV','Baltinavas novads','Baltinavas novads'),(379,125,'LV','LV-BL','Balvu novads'),(380,125,'LV','LV-BU','Bauskas novads'),(381,125,'LV','Beverīnas novads','Beverīnas novads'),(382,125,'LV','Brocēnu novads','Brocēnu novads'),(383,125,'LV','Burtnieku novads','Burtnieku novads'),(384,125,'LV','Carnikavas novads','Carnikavas novads'),(385,125,'LV','Cesvaines novads','Cesvaines novads'),(386,125,'LV','Ciblas novads','Ciblas novads'),(387,125,'LV','LV-CE','Cēsu novads'),(388,125,'LV','Dagdas novads','Dagdas novads'),(389,125,'LV','LV-DA','Daugavpils novads'),(390,125,'LV','LV-DO','Dobeles novads'),(391,125,'LV','Dundagas novads','Dundagas novads'),(392,125,'LV','Durbes novads','Durbes novads'),(393,125,'LV','Engures novads','Engures novads'),(394,125,'LV','Garkalnes novads','Garkalnes novads'),(395,125,'LV','Grobiņas novads','Grobiņas novads'),(396,125,'LV','LV-GU','Gulbenes novads'),(397,125,'LV','Iecavas novads','Iecavas novads'),(398,125,'LV','Ikšķiles novads','Ikšķiles novads'),(399,125,'LV','Ilūkstes novads','Ilūkstes novads'),(400,125,'LV','Inčukalna novads','Inčukalna novads'),(401,125,'LV','Jaunjelgavas novads','Jaunjelgavas novads'),(402,125,'LV','Jaunpiebalgas novads','Jaunpiebalgas novads'),(403,125,'LV','Jaunpils novads','Jaunpils novads'),(404,125,'LV','LV-JL','Jelgavas novads'),(405,125,'LV','LV-JK','Jēkabpils novads'),(406,125,'LV','Kandavas novads','Kandavas novads'),(407,125,'LV','Kokneses novads','Kokneses novads'),(408,125,'LV','Krimuldas novads','Krimuldas novads'),(409,125,'LV','Krustpils novads','Krustpils novads'),(410,125,'LV','LV-KR','Krāslavas novads'),(411,125,'LV','LV-KU','Kuldīgas novads'),(412,125,'LV','Kārsavas novads','Kārsavas novads'),(413,125,'LV','Lielvārdes novads','Lielvārdes novads'),(414,125,'LV','LV-LM','Limbažu novads'),(415,125,'LV','Lubānas novads','Lubānas novads'),(416,125,'LV','LV-LU','Ludzas novads'),(417,125,'LV','Līgatnes novads','Līgatnes novads'),(418,125,'LV','Līvānu novads','Līvānu novads'),(419,125,'LV','LV-MA','Madonas novads'),(420,125,'LV','Mazsalacas novads','Mazsalacas novads'),(421,125,'LV','Mālpils novads','Mālpils novads'),(422,125,'LV','Mārupes novads','Mārupes novads'),(423,125,'LV','Naukšēnu novads','Naukšēnu novads'),(424,125,'LV','Neretas novads','Neretas novads'),(425,125,'LV','Nīcas novads','Nīcas novads'),(426,125,'LV','LV-OG','Ogres novads'),(427,125,'LV','Olaines novads','Olaines novads'),(428,125,'LV','Ozolnieku novads','Ozolnieku novads'),(429,125,'LV','LV-PR','Preiļu novads'),(430,125,'LV','Priekules novads','Priekules novads'),(431,125,'LV','Priekuļu novads','Priekuļu novads'),(432,125,'LV','Pārgaujas novads','Pārgaujas novads'),(433,125,'LV','Pāvilostas novads','Pāvilostas novads'),(434,125,'LV','Pļaviņu novads','Pļaviņu novads'),(435,125,'LV','Raunas novads','Raunas novads'),(436,125,'LV','Riebiņu novads','Riebiņu novads'),(437,125,'LV','Rojas novads','Rojas novads'),(438,125,'LV','Ropažu novads','Ropažu novads'),(439,125,'LV','Rucavas novads','Rucavas novads'),(440,125,'LV','Rugāju novads','Rugāju novads'),(441,125,'LV','Rundāles novads','Rundāles novads'),(442,125,'LV','LV-RE','Rēzeknes novads'),(443,125,'LV','Rūjienas novads','Rūjienas novads'),(444,125,'LV','Salacgrīvas novads','Salacgrīvas novads'),(445,125,'LV','Salas novads','Salas novads'),(446,125,'LV','Salaspils novads','Salaspils novads'),(447,125,'LV','LV-SA','Saldus novads'),(448,125,'LV','Saulkrastu novads','Saulkrastu novads'),(449,125,'LV','Siguldas novads','Siguldas novads'),(450,125,'LV','Skrundas novads','Skrundas novads'),(451,125,'LV','Skrīveru novads','Skrīveru novads'),(452,125,'LV','Smiltenes novads','Smiltenes novads'),(453,125,'LV','Stopiņu novads','Stopiņu novads'),(454,125,'LV','Strenču novads','Strenču novads'),(455,125,'LV','Sējas novads','Sējas novads'),(456,125,'LV','LV-TA','Talsu novads'),(457,125,'LV','LV-TU','Tukuma novads'),(458,125,'LV','Tērvetes novads','Tērvetes novads'),(459,125,'LV','Vaiņodes novads','Vaiņodes novads'),(460,125,'LV','LV-VK','Valkas novads'),(461,125,'LV','LV-VM','Valmieras novads'),(462,125,'LV','Varakļānu novads','Varakļānu novads'),(463,125,'LV','Vecpiebalgas novads','Vecpiebalgas novads'),(464,125,'LV','Vecumnieku novads','Vecumnieku novads'),(465,125,'LV','LV-VE','Ventspils novads'),(466,125,'LV','Viesītes novads','Viesītes novads'),(467,125,'LV','Viļakas novads','Viļakas novads'),(468,125,'LV','Viļānu novads','Viļānu novads'),(469,125,'LV','Vārkavas novads','Vārkavas novads'),(470,125,'LV','Zilupes novads','Zilupes novads'),(471,125,'LV','Ādažu novads','Ādažu novads'),(472,125,'LV','Ērgļu novads','Ērgļu novads'),(473,125,'LV','Ķeguma novads','Ķeguma novads'),(474,125,'LV','Ķekavas novads','Ķekavas novads'),(475,131,'LT','LT-AL','Alytaus Apskritis'),(476,131,'LT','LT-KU','Kauno Apskritis'),(477,131,'LT','LT-KL','Klaipėdos Apskritis'),(478,131,'LT','LT-MR','Marijampolės Apskritis'),(479,131,'LT','LT-PN','Panevėžio Apskritis'),(480,131,'LT','LT-SA','Šiaulių Apskritis'),(481,131,'LT','LT-TA','Tauragės Apskritis'),(482,131,'LT','LT-TE','Telšių Apskritis'),(483,131,'LT','LT-UT','Utenos Apskritis'),(484,131,'LT','LT-VL','Vilniaus Apskritis'),(485,31,'BR','AC','Acre'),(486,31,'BR','AL','Alagoas'),(487,31,'BR','AP','Amapá'),(488,31,'BR','AM','Amazonas'),(489,31,'BR','BA','Bahia'),(490,31,'BR','CE','Ceará'),(491,31,'BR','ES','Espírito Santo'),(492,31,'BR','GO','Goiás'),(493,31,'BR','MA','Maranhão'),(494,31,'BR','MT','Mato Grosso'),(495,31,'BR','MS','Mato Grosso do Sul'),(496,31,'BR','MG','Minas Gerais'),(497,31,'BR','PA','Pará'),(498,31,'BR','PB','Paraíba'),(499,31,'BR','PR','Paraná'),(500,31,'BR','PE','Pernambuco'),(501,31,'BR','PI','Piauí'),(502,31,'BR','RJ','Rio de Janeiro'),(503,31,'BR','RN','Rio Grande do Norte'),(504,31,'BR','RS','Rio Grande do Sul'),(505,31,'BR','RO','Rondônia'),(506,31,'BR','RR','Roraima'),(507,31,'BR','SC','Santa Catarina'),(508,31,'BR','SP','São Paulo'),(509,31,'BR','SE','Sergipe'),(510,31,'BR','TO','Tocantins'),(511,31,'BR','DF','Distrito Federal'),(512,59,'HR','HR-01','Zagrebačka županija'),(513,59,'HR','HR-02','Krapinsko-zagorska županija'),(514,59,'HR','HR-03','Sisačko-moslavačka županija'),(515,59,'HR','HR-04','Karlovačka županija'),(516,59,'HR','HR-05','Varaždinska županija'),(517,59,'HR','HR-06','Koprivničko-križevačka županija'),(518,59,'HR','HR-07','Bjelovarsko-bilogorska županija'),(519,59,'HR','HR-08','Primorsko-goranska županija'),(520,59,'HR','HR-09','Ličko-senjska županija'),(521,59,'HR','HR-10','Virovitičko-podravska županija'),(522,59,'HR','HR-11','Požeško-slavonska županija'),(523,59,'HR','HR-12','Brodsko-posavska županija'),(524,59,'HR','HR-13','Zadarska županija'),(525,59,'HR','HR-14','Osječko-baranjska županija'),(526,59,'HR','HR-15','Šibensko-kninska županija'),(527,59,'HR','HR-16','Vukovarsko-srijemska županija'),(528,59,'HR','HR-17','Splitsko-dalmatinska županija'),(529,59,'HR','HR-18','Istarska županija'),(530,59,'HR','HR-19','Dubrovačko-neretvanska županija'),(531,59,'HR','HR-20','Međimurska županija'),(532,59,'HR','HR-21','Grad Zagreb'),(533,106,'IN','AN','Andaman and Nicobar Islands'),(534,106,'IN','AP','Andhra Pradesh'),(535,106,'IN','AR','Arunachal Pradesh'),(536,106,'IN','AS','Assam'),(537,106,'IN','BR','Bihar'),(538,106,'IN','CH','Chandigarh'),(539,106,'IN','CT','Chhattisgarh'),(540,106,'IN','DN','Dadra and Nagar Haveli'),(541,106,'IN','DD','Daman and Diu'),(542,106,'IN','DL','Delhi'),(543,106,'IN','GA','Goa'),(544,106,'IN','GJ','Gujarat'),(545,106,'IN','HR','Haryana'),(546,106,'IN','HP','Himachal Pradesh'),(547,106,'IN','JK','Jammu and Kashmir'),(548,106,'IN','JH','Jharkhand'),(549,106,'IN','KA','Karnataka'),(550,106,'IN','KL','Kerala'),(551,106,'IN','LD','Lakshadweep'),(552,106,'IN','MP','Madhya Pradesh'),(553,106,'IN','MH','Maharashtra'),(554,106,'IN','MN','Manipur'),(555,106,'IN','ML','Meghalaya'),(556,106,'IN','MZ','Mizoram'),(557,106,'IN','NL','Nagaland'),(558,106,'IN','OR','Odisha'),(559,106,'IN','PY','Puducherry'),(560,106,'IN','PB','Punjab'),(561,106,'IN','RJ','Rajasthan'),(562,106,'IN','SK','Sikkim'),(563,106,'IN','TN','Tamil Nadu'),(564,106,'IN','TG','Telangana'),(565,106,'IN','TR','Tripura'),(566,106,'IN','UP','Uttar Pradesh'),(567,106,'IN','UT','Uttarakhand'),(568,106,'IN','WB','West Bengal'),(569,176,'PY','PY-16','Alto Paraguay'),(570,176,'PY','PY-10','Alto Paraná'),(571,176,'PY','PY-13','Amambay'),(572,176,'PY','PY-ASU','Asunción'),(573,176,'PY','PY-19','Boquerón'),(574,176,'PY','PY-5','Caaguazú'),(575,176,'PY','PY-6','Caazapá'),(576,176,'PY','PY-14','Canindeyú'),(577,176,'PY','PY-11','Central'),(578,176,'PY','PY-1','Concepción'),(579,176,'PY','PY-3','Cordillera'),(580,176,'PY','PY-4','Guairá'),(581,176,'PY','PY-7','Itapúa'),(582,176,'PY','PY-8','Misiones'),(583,176,'PY','PY-9','Paraguarí'),(584,176,'PY','PY-15','Presidente Hayes'),(585,176,'PY','PY-2','San Pedro'),(586,176,'PY','PY-12','Ñeembucú');
/*!40000 ALTER TABLE `country_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country_translations`
--

DROP TABLE IF EXISTS `country_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `country_id` int unsigned NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `country_translations_country_id_foreign` (`country_id`),
  CONSTRAINT `country_translations_country_id_foreign` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country_translations`
--

LOCK TABLES `country_translations` WRITE;
/*!40000 ALTER TABLE `country_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `country_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currencies` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `decimal` int unsigned NOT NULL DEFAULT '2',
  `group_separator` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ',',
  `decimal_separator` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '.',
  `currency_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'MXN','Peso Mexicano','$',2,',','.',NULL,NULL,NULL),(2,'USD','Dolares','$',2,',',',','right','2025-12-26 13:04:22','2025-12-26 13:04:22');
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_exchange_rates`
--

DROP TABLE IF EXISTS `currency_exchange_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency_exchange_rates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `rate` decimal(24,12) NOT NULL,
  `target_currency` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currency_exchange_rates_target_currency_unique` (`target_currency`),
  CONSTRAINT `currency_exchange_rates_target_currency_foreign` FOREIGN KEY (`target_currency`) REFERENCES `currencies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_exchange_rates`
--

LOCK TABLES `currency_exchange_rates` WRITE;
/*!40000 ALTER TABLE `currency_exchange_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `currency_exchange_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_groups`
--

DROP TABLE IF EXISTS `customer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_groups` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_user_defined` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_groups_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_groups`
--

LOCK TABLES `customer_groups` WRITE;
/*!40000 ALTER TABLE `customer_groups` DISABLE KEYS */;
INSERT INTO `customer_groups` VALUES (1,'guest','Invitado',0,NULL,NULL),(2,'general','General',0,NULL,NULL),(3,'wholesale','Mayorista',0,NULL,NULL);
/*!40000 ALTER TABLE `customer_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_notes`
--

DROP TABLE IF EXISTS `customer_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_notes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int unsigned DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_notified` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_notes_customer_id_foreign` (`customer_id`),
  CONSTRAINT `customer_notes_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_notes`
--

LOCK TABLES `customer_notes` WRITE;
/*!40000 ALTER TABLE `customer_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_password_resets`
--

DROP TABLE IF EXISTS `customer_password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `customer_password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_password_resets`
--

LOCK TABLES `customer_password_resets` WRITE;
/*!40000 ALTER TABLE `customer_password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_social_accounts`
--

DROP TABLE IF EXISTS `customer_social_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_social_accounts` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int unsigned NOT NULL,
  `provider_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_social_accounts_provider_id_unique` (`provider_id`),
  KEY `customer_social_accounts_customer_id_foreign` (`customer_id`),
  CONSTRAINT `customer_social_accounts_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_social_accounts`
--

LOCK TABLES `customer_social_accounts` WRITE;
/*!40000 ALTER TABLE `customer_social_accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_social_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_token` varchar(80) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_group_id` int unsigned DEFAULT NULL,
  `channel_id` int unsigned DEFAULT NULL,
  `subscribed_to_news_letter` tinyint(1) NOT NULL DEFAULT '0',
  `is_verified` tinyint(1) NOT NULL DEFAULT '0',
  `is_suspended` tinyint unsigned NOT NULL DEFAULT '0',
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_email_unique` (`email`),
  UNIQUE KEY `customers_phone_unique` (`phone`),
  UNIQUE KEY `customers_api_token_unique` (`api_token`),
  KEY `customers_customer_group_id_foreign` (`customer_group_id`),
  KEY `customers_channel_id_foreign` (`channel_id`),
  CONSTRAINT `customers_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customers_customer_group_id_foreign` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_groups` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Eduardo','Rosales',NULL,NULL,'eduardorosales720@gmail.com',NULL,NULL,1,'$2y$12$O0rTIHBsh1gfQCgrLT9z2.RpqYCsvBpE0FHO0IpKxG4wUnDp1mxV2','mgLD1cIKhJk8J4kjNMXC6HRfn6Z7ReZRF23MRMueW9O8bpwI3Uo2LyanHsZWPEC4MZHatPx4gSXCYLcs',2,1,1,1,0,'41470c68d879c1d81b44b80925cfd8be',NULL,'2025-12-13 00:06:11','2025-12-13 00:06:11'),(2,'Esau','Sanchez',NULL,NULL,'tonalfan@gmail.com',NULL,NULL,1,'$2y$12$psS0ZmIsNyOHcU6OLZDUh.zJEHtNzf.VIGYXiD91LSDF4HzHfGydW','jIiJ254LPMPi3riTE4hNlmuDhoYg1EPfjFjekbLbgjSoG29S5hxSvKNqwAbpvWaKVOXJj6KuflrJNlw7',2,1,0,1,0,'ede84074efacf0757c8598ac4be24563',NULL,'2025-12-22 17:15:10','2025-12-22 17:15:10');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datagrid_saved_filters`
--

DROP TABLE IF EXISTS `datagrid_saved_filters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `datagrid_saved_filters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `src` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applied` json NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `datagrid_saved_filters_user_id_name_src_unique` (`user_id`,`name`,`src`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datagrid_saved_filters`
--

LOCK TABLES `datagrid_saved_filters` WRITE;
/*!40000 ALTER TABLE `datagrid_saved_filters` DISABLE KEYS */;
/*!40000 ALTER TABLE `datagrid_saved_filters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `downloadable_link_purchased`
--

DROP TABLE IF EXISTS `downloadable_link_purchased`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `downloadable_link_purchased` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `download_bought` int NOT NULL DEFAULT '0',
  `download_used` int NOT NULL DEFAULT '0',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` int unsigned NOT NULL,
  `order_id` int unsigned NOT NULL,
  `order_item_id` int unsigned NOT NULL,
  `download_canceled` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `downloadable_link_purchased_customer_id_foreign` (`customer_id`),
  KEY `downloadable_link_purchased_order_id_foreign` (`order_id`),
  KEY `downloadable_link_purchased_order_item_id_foreign` (`order_item_id`),
  CONSTRAINT `downloadable_link_purchased_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `downloadable_link_purchased_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `downloadable_link_purchased_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `downloadable_link_purchased`
--

LOCK TABLES `downloadable_link_purchased` WRITE;
/*!40000 ALTER TABLE `downloadable_link_purchased` DISABLE KEYS */;
/*!40000 ALTER TABLE `downloadable_link_purchased` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
INSERT INTO `failed_jobs` VALUES (1,'b472a2df-5c63-4491-8da0-307113599db0','redis','default','{\"uuid\":\"b472a2df-5c63-4491-8da0-307113599db0\",\"timeout\":null,\"id\":\"NpxhpBfrv3SbL7qNEpCLbpJ0S3feT86p\",\"backoff\":null,\"displayName\":\"Webkul\\\\Shop\\\\Mail\\\\Customer\\\\SubscriptionNotification\",\"maxTries\":null,\"failOnTimeout\":false,\"maxExceptions\":null,\"retryUntil\":null,\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"data\":{\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:50:\\\"Webkul\\\\Shop\\\\Mail\\\\Customer\\\\SubscriptionNotification\\\":2:{s:15:\\\"subscribersList\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:34:\\\"Webkul\\\\Core\\\\Models\\\\SubscribersList\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:3:\\\"job\\\";N;}\",\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\"},\"attempts\":2}','Symfony\\Component\\Mailer\\Exception\\TransportException: Connection could not be established with host \"# e.g., smtp.gmail.com, smtp.sendgrid.net:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for # e.g., smtp.gmail.com, smtp.sendgrid.net failed: Name or service not known in /var/www/html/vendor/symfony/mailer/Transport/Smtp/Stream/SocketStream.php:154\nStack trace:\n#0 [internal function]: Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\SocketStream->Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\{closure}(2, \'stream_socket_c...\', \'/var/www/html/v...\', 157)\n#1 /var/www/html/vendor/symfony/mailer/Transport/Smtp/Stream/SocketStream.php(157): stream_socket_client(\'# e.g., smtp.gm...\', 0, \'\', 60.0, 4, Resource id #1741)\n#2 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(279): Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\SocketStream->initialize()\n#3 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(211): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->start()\n#4 /var/www/html/vendor/symfony/mailer/Transport/AbstractTransport.php(69): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->doSend(Object(Symfony\\Component\\Mailer\\SentMessage))\n#5 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(138): Symfony\\Component\\Mailer\\Transport\\AbstractTransport->send(Object(Symfony\\Component\\Mime\\Email), Object(Symfony\\Component\\Mailer\\DelayedEnvelope))\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(585): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->send(Object(Symfony\\Component\\Mime\\Email), Object(Symfony\\Component\\Mailer\\DelayedEnvelope))\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(332): Illuminate\\Mail\\Mailer->sendSymfonyMessage(Object(Symfony\\Component\\Mime\\Email))\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(206): Illuminate\\Mail\\Mailer->send(\'shop::emails.cu...\', Array, Object(Closure))\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->Illuminate\\Mail\\{closure}()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(199): Illuminate\\Mail\\Mailable->withLocale(NULL, Object(Closure))\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(83): Illuminate\\Mail\\Mailable->send(Object(Illuminate\\Mail\\MailManager))\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle(Object(Illuminate\\Mail\\MailManager))\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(126): Illuminate\\Container\\Container->call(Array)\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(130): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(126): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(Illuminate\\Mail\\SendQueuedMailable), false)\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(121): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(69): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\RedisJob), Object(Illuminate\\Mail\\SendQueuedMailable))\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\RedisJob), Array)\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(442): Illuminate\\Queue\\Jobs\\Job->fire()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(392): Illuminate\\Queue\\Worker->process(\'redis\', Object(Illuminate\\Queue\\Jobs\\RedisJob), Object(Illuminate\\Queue\\WorkerOptions))\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(178): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\RedisJob), \'redis\', Object(Illuminate\\Queue\\WorkerOptions))\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(149): Illuminate\\Queue\\Worker->daemon(\'redis\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(132): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'redis\', \'default\')\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(213): Illuminate\\Container\\Container->call(Array)\n#38 /var/www/html/vendor/symfony/console/Command/Command.php(318): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#39 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(182): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#40 /var/www/html/vendor/symfony/console/Application.php(1110): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#41 /var/www/html/vendor/symfony/console/Application.php(359): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#42 /var/www/html/vendor/symfony/console/Application.php(194): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#43 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#44 /var/www/html/artisan(35): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#45 {main}','2025-12-13 00:06:14'),(2,'3766d7b7-ba27-4adc-bd5f-2e1cde7c84df','redis','default','{\"uuid\":\"3766d7b7-ba27-4adc-bd5f-2e1cde7c84df\",\"timeout\":null,\"id\":\"XnZcy8ih7ZKXpn25vGyJMTjnD01KbxJU\",\"backoff\":null,\"displayName\":\"Webkul\\\\Shop\\\\Mail\\\\Customer\\\\RegistrationNotification\",\"maxTries\":null,\"failOnTimeout\":false,\"maxExceptions\":null,\"retryUntil\":null,\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"data\":{\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:50:\\\"Webkul\\\\Shop\\\\Mail\\\\Customer\\\\RegistrationNotification\\\":2:{s:8:\\\"customer\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:31:\\\"Webkul\\\\Customer\\\\Models\\\\Customer\\\";s:2:\\\"id\\\";i:1;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:3:\\\"job\\\";N;}\",\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\"},\"attempts\":2}','Symfony\\Component\\Mailer\\Exception\\TransportException: Connection could not be established with host \"# e.g., smtp.gmail.com, smtp.sendgrid.net:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for # e.g., smtp.gmail.com, smtp.sendgrid.net failed: Name or service not known in /var/www/html/vendor/symfony/mailer/Transport/Smtp/Stream/SocketStream.php:154\nStack trace:\n#0 [internal function]: Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\SocketStream->Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\{closure}(2, \'stream_socket_c...\', \'/var/www/html/v...\', 157)\n#1 /var/www/html/vendor/symfony/mailer/Transport/Smtp/Stream/SocketStream.php(157): stream_socket_client(\'# e.g., smtp.gm...\', 0, \'\', 60.0, 4, Resource id #1758)\n#2 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(279): Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\SocketStream->initialize()\n#3 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(211): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->start()\n#4 /var/www/html/vendor/symfony/mailer/Transport/AbstractTransport.php(69): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->doSend(Object(Symfony\\Component\\Mailer\\SentMessage))\n#5 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(138): Symfony\\Component\\Mailer\\Transport\\AbstractTransport->send(Object(Symfony\\Component\\Mime\\Email), Object(Symfony\\Component\\Mailer\\DelayedEnvelope))\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(585): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->send(Object(Symfony\\Component\\Mime\\Email), Object(Symfony\\Component\\Mailer\\DelayedEnvelope))\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(332): Illuminate\\Mail\\Mailer->sendSymfonyMessage(Object(Symfony\\Component\\Mime\\Email))\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(206): Illuminate\\Mail\\Mailer->send(\'shop::emails.cu...\', Array, Object(Closure))\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->Illuminate\\Mail\\{closure}()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(199): Illuminate\\Mail\\Mailable->withLocale(NULL, Object(Closure))\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(83): Illuminate\\Mail\\Mailable->send(Object(Illuminate\\Mail\\MailManager))\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle(Object(Illuminate\\Mail\\MailManager))\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(126): Illuminate\\Container\\Container->call(Array)\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(130): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(126): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(Illuminate\\Mail\\SendQueuedMailable), false)\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(121): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(69): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\RedisJob), Object(Illuminate\\Mail\\SendQueuedMailable))\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\RedisJob), Array)\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(442): Illuminate\\Queue\\Jobs\\Job->fire()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(392): Illuminate\\Queue\\Worker->process(\'redis\', Object(Illuminate\\Queue\\Jobs\\RedisJob), Object(Illuminate\\Queue\\WorkerOptions))\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(178): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\RedisJob), \'redis\', Object(Illuminate\\Queue\\WorkerOptions))\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(149): Illuminate\\Queue\\Worker->daemon(\'redis\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(132): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'redis\', \'default\')\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(213): Illuminate\\Container\\Container->call(Array)\n#38 /var/www/html/vendor/symfony/console/Command/Command.php(318): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#39 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(182): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#40 /var/www/html/vendor/symfony/console/Application.php(1110): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#41 /var/www/html/vendor/symfony/console/Application.php(359): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#42 /var/www/html/vendor/symfony/console/Application.php(194): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#43 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#44 /var/www/html/artisan(35): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#45 {main}','2025-12-13 00:06:14'),(3,'ee7f839a-4c13-4637-8ba1-34878843d15b','redis','default','{\"uuid\":\"ee7f839a-4c13-4637-8ba1-34878843d15b\",\"timeout\":null,\"id\":\"rRFCgrUxkHgZQPxiq3krqkIaDqKbpBzi\",\"backoff\":null,\"displayName\":\"Webkul\\\\Shop\\\\Mail\\\\Customer\\\\RegistrationNotification\",\"maxTries\":null,\"failOnTimeout\":false,\"maxExceptions\":null,\"retryUntil\":null,\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"data\":{\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:50:\\\"Webkul\\\\Shop\\\\Mail\\\\Customer\\\\RegistrationNotification\\\":2:{s:8:\\\"customer\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:31:\\\"Webkul\\\\Customer\\\\Models\\\\Customer\\\";s:2:\\\"id\\\";i:2;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:3:\\\"job\\\";N;}\",\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\"},\"attempts\":2}','Symfony\\Component\\Mailer\\Exception\\TransportException: Connection could not be established with host \"# e.g., smtp.gmail.com, smtp.sendgrid.net:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for # e.g., smtp.gmail.com, smtp.sendgrid.net failed: Name or service not known in /var/www/html/vendor/symfony/mailer/Transport/Smtp/Stream/SocketStream.php:154\nStack trace:\n#0 [internal function]: Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\SocketStream->Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\{closure}(2, \'stream_socket_c...\', \'/var/www/html/v...\', 157)\n#1 /var/www/html/vendor/symfony/mailer/Transport/Smtp/Stream/SocketStream.php(157): stream_socket_client(\'# e.g., smtp.gm...\', 0, \'\', 60.0, 4, Resource id #1612)\n#2 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(279): Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\SocketStream->initialize()\n#3 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(211): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->start()\n#4 /var/www/html/vendor/symfony/mailer/Transport/AbstractTransport.php(69): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->doSend(Object(Symfony\\Component\\Mailer\\SentMessage))\n#5 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(138): Symfony\\Component\\Mailer\\Transport\\AbstractTransport->send(Object(Symfony\\Component\\Mime\\Email), Object(Symfony\\Component\\Mailer\\DelayedEnvelope))\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(585): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->send(Object(Symfony\\Component\\Mime\\Email), Object(Symfony\\Component\\Mailer\\DelayedEnvelope))\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(332): Illuminate\\Mail\\Mailer->sendSymfonyMessage(Object(Symfony\\Component\\Mime\\Email))\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(206): Illuminate\\Mail\\Mailer->send(\'shop::emails.cu...\', Array, Object(Closure))\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->Illuminate\\Mail\\{closure}()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(199): Illuminate\\Mail\\Mailable->withLocale(NULL, Object(Closure))\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(83): Illuminate\\Mail\\Mailable->send(Object(Illuminate\\Mail\\MailManager))\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle(Object(Illuminate\\Mail\\MailManager))\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(126): Illuminate\\Container\\Container->call(Array)\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(130): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(126): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(Illuminate\\Mail\\SendQueuedMailable), false)\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(121): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(69): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\RedisJob), Object(Illuminate\\Mail\\SendQueuedMailable))\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\RedisJob), Array)\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(442): Illuminate\\Queue\\Jobs\\Job->fire()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(392): Illuminate\\Queue\\Worker->process(\'redis\', Object(Illuminate\\Queue\\Jobs\\RedisJob), Object(Illuminate\\Queue\\WorkerOptions))\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(178): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\RedisJob), \'redis\', Object(Illuminate\\Queue\\WorkerOptions))\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(149): Illuminate\\Queue\\Worker->daemon(\'redis\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(132): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'redis\', \'default\')\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(213): Illuminate\\Container\\Container->call(Array)\n#38 /var/www/html/vendor/symfony/console/Command/Command.php(318): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#39 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(182): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#40 /var/www/html/vendor/symfony/console/Application.php(1110): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#41 /var/www/html/vendor/symfony/console/Application.php(359): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#42 /var/www/html/vendor/symfony/console/Application.php(194): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#43 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#44 /var/www/html/artisan(35): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#45 {main}','2025-12-22 17:15:14'),(4,'5d0825c6-cf1f-405a-90aa-e297fb827563','redis','default','{\"uuid\":\"5d0825c6-cf1f-405a-90aa-e297fb827563\",\"timeout\":null,\"id\":\"tPg3yt9bbiKjmOMBHHiKDCUMIoPReagX\",\"backoff\":null,\"displayName\":\"Webkul\\\\Shop\\\\Mail\\\\Customer\\\\SubscriptionNotification\",\"maxTries\":null,\"failOnTimeout\":false,\"maxExceptions\":null,\"retryUntil\":null,\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"data\":{\"command\":\"O:34:\\\"Illuminate\\\\Mail\\\\SendQueuedMailable\\\":15:{s:8:\\\"mailable\\\";O:50:\\\"Webkul\\\\Shop\\\\Mail\\\\Customer\\\\SubscriptionNotification\\\":2:{s:15:\\\"subscribersList\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":5:{s:5:\\\"class\\\";s:34:\\\"Webkul\\\\Core\\\\Models\\\\SubscribersList\\\";s:2:\\\"id\\\";i:2;s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";s:15:\\\"collectionClass\\\";N;}s:6:\\\"mailer\\\";s:4:\\\"smtp\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:13:\\\"maxExceptions\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:3:\\\"job\\\";N;}\",\"commandName\":\"Illuminate\\\\Mail\\\\SendQueuedMailable\"},\"attempts\":2}','Symfony\\Component\\Mailer\\Exception\\TransportException: Connection could not be established with host \"# e.g., smtp.gmail.com, smtp.sendgrid.net:587\": stream_socket_client(): php_network_getaddresses: getaddrinfo for # e.g., smtp.gmail.com, smtp.sendgrid.net failed: Name or service not known in /var/www/html/vendor/symfony/mailer/Transport/Smtp/Stream/SocketStream.php:154\nStack trace:\n#0 [internal function]: Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\SocketStream->Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\{closure}(2, \'stream_socket_c...\', \'/var/www/html/v...\', 157)\n#1 /var/www/html/vendor/symfony/mailer/Transport/Smtp/Stream/SocketStream.php(157): stream_socket_client(\'# e.g., smtp.gm...\', 0, \'\', 60.0, 4, Resource id #1712)\n#2 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(279): Symfony\\Component\\Mailer\\Transport\\Smtp\\Stream\\SocketStream->initialize()\n#3 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(211): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->start()\n#4 /var/www/html/vendor/symfony/mailer/Transport/AbstractTransport.php(69): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->doSend(Object(Symfony\\Component\\Mailer\\SentMessage))\n#5 /var/www/html/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(138): Symfony\\Component\\Mailer\\Transport\\AbstractTransport->send(Object(Symfony\\Component\\Mime\\Email), Object(Symfony\\Component\\Mailer\\DelayedEnvelope))\n#6 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(585): Symfony\\Component\\Mailer\\Transport\\Smtp\\SmtpTransport->send(Object(Symfony\\Component\\Mime\\Email), Object(Symfony\\Component\\Mailer\\DelayedEnvelope))\n#7 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailer.php(332): Illuminate\\Mail\\Mailer->sendSymfonyMessage(Object(Symfony\\Component\\Mime\\Email))\n#8 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(206): Illuminate\\Mail\\Mailer->send(\'shop::emails.cu...\', Array, Object(Closure))\n#9 /var/www/html/vendor/laravel/framework/src/Illuminate/Support/Traits/Localizable.php(19): Illuminate\\Mail\\Mailable->Illuminate\\Mail\\{closure}()\n#10 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/Mailable.php(199): Illuminate\\Mail\\Mailable->withLocale(NULL, Object(Closure))\n#11 /var/www/html/vendor/laravel/framework/src/Illuminate/Mail/SendQueuedMailable.php(83): Illuminate\\Mail\\Mailable->send(Object(Illuminate\\Mail\\MailManager))\n#12 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Mail\\SendQueuedMailable->handle(Object(Illuminate\\Mail\\MailManager))\n#13 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#14 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#15 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#16 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#17 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(126): Illuminate\\Container\\Container->call(Array)\n#18 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Bus\\Dispatcher->Illuminate\\Bus\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#19 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#20 /var/www/html/vendor/laravel/framework/src/Illuminate/Bus/Dispatcher.php(130): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#21 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(126): Illuminate\\Bus\\Dispatcher->dispatchNow(Object(Illuminate\\Mail\\SendQueuedMailable), false)\n#22 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(170): Illuminate\\Queue\\CallQueuedHandler->Illuminate\\Queue\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#23 /var/www/html/vendor/laravel/framework/src/Illuminate/Pipeline/Pipeline.php(127): Illuminate\\Pipeline\\Pipeline->Illuminate\\Pipeline\\{closure}(Object(Illuminate\\Mail\\SendQueuedMailable))\n#24 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(121): Illuminate\\Pipeline\\Pipeline->then(Object(Closure))\n#25 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/CallQueuedHandler.php(69): Illuminate\\Queue\\CallQueuedHandler->dispatchThroughMiddleware(Object(Illuminate\\Queue\\Jobs\\RedisJob), Object(Illuminate\\Mail\\SendQueuedMailable))\n#26 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Jobs/Job.php(102): Illuminate\\Queue\\CallQueuedHandler->call(Object(Illuminate\\Queue\\Jobs\\RedisJob), Array)\n#27 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(442): Illuminate\\Queue\\Jobs\\Job->fire()\n#28 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(392): Illuminate\\Queue\\Worker->process(\'redis\', Object(Illuminate\\Queue\\Jobs\\RedisJob), Object(Illuminate\\Queue\\WorkerOptions))\n#29 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Worker.php(178): Illuminate\\Queue\\Worker->runJob(Object(Illuminate\\Queue\\Jobs\\RedisJob), \'redis\', Object(Illuminate\\Queue\\WorkerOptions))\n#30 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(149): Illuminate\\Queue\\Worker->daemon(\'redis\', \'default\', Object(Illuminate\\Queue\\WorkerOptions))\n#31 /var/www/html/vendor/laravel/framework/src/Illuminate/Queue/Console/WorkCommand.php(132): Illuminate\\Queue\\Console\\WorkCommand->runWorker(\'redis\', \'default\')\n#32 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(36): Illuminate\\Queue\\Console\\WorkCommand->handle()\n#33 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Util.php(43): Illuminate\\Container\\BoundMethod::Illuminate\\Container\\{closure}()\n#34 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(95): Illuminate\\Container\\Util::unwrapIfClosure(Object(Closure))\n#35 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/BoundMethod.php(35): Illuminate\\Container\\BoundMethod::callBoundMethod(Object(Illuminate\\Foundation\\Application), Array, Object(Closure))\n#36 /var/www/html/vendor/laravel/framework/src/Illuminate/Container/Container.php(696): Illuminate\\Container\\BoundMethod::call(Object(Illuminate\\Foundation\\Application), Array, Array, NULL)\n#37 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(213): Illuminate\\Container\\Container->call(Array)\n#38 /var/www/html/vendor/symfony/console/Command/Command.php(318): Illuminate\\Console\\Command->execute(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#39 /var/www/html/vendor/laravel/framework/src/Illuminate/Console/Command.php(182): Symfony\\Component\\Console\\Command\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Illuminate\\Console\\OutputStyle))\n#40 /var/www/html/vendor/symfony/console/Application.php(1110): Illuminate\\Console\\Command->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#41 /var/www/html/vendor/symfony/console/Application.php(359): Symfony\\Component\\Console\\Application->doRunCommand(Object(Illuminate\\Queue\\Console\\WorkCommand), Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#42 /var/www/html/vendor/symfony/console/Application.php(194): Symfony\\Component\\Console\\Application->doRun(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#43 /var/www/html/vendor/laravel/framework/src/Illuminate/Foundation/Console/Kernel.php(198): Symfony\\Component\\Console\\Application->run(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#44 /var/www/html/artisan(35): Illuminate\\Foundation\\Console\\Kernel->handle(Object(Symfony\\Component\\Console\\Input\\ArgvInput), Object(Symfony\\Component\\Console\\Output\\ConsoleOutput))\n#45 {main}','2025-12-28 06:21:36');
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gdpr_data_request`
--

DROP TABLE IF EXISTS `gdpr_data_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gdpr_data_request` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gdpr_data_request_customer_id_foreign` (`customer_id`),
  CONSTRAINT `gdpr_data_request_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gdpr_data_request`
--

LOCK TABLES `gdpr_data_request` WRITE;
/*!40000 ALTER TABLE `gdpr_data_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `gdpr_data_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_batches`
--

DROP TABLE IF EXISTS `import_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_batches` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `data` json NOT NULL,
  `summary` json DEFAULT NULL,
  `import_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `import_batches_import_id_foreign` (`import_id`),
  CONSTRAINT `import_batches_import_id_foreign` FOREIGN KEY (`import_id`) REFERENCES `imports` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_batches`
--

LOCK TABLES `import_batches` WRITE;
/*!40000 ALTER TABLE `import_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imports`
--

DROP TABLE IF EXISTS `imports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imports` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `process_in_queue` tinyint(1) NOT NULL DEFAULT '1',
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `validation_strategy` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `allowed_errors` int NOT NULL DEFAULT '0',
  `processed_rows_count` int NOT NULL DEFAULT '0',
  `invalid_rows_count` int NOT NULL DEFAULT '0',
  `errors_count` int NOT NULL DEFAULT '0',
  `errors` json DEFAULT NULL,
  `field_separator` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `images_directory_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error_file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `summary` json DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imports`
--

LOCK TABLES `imports` WRITE;
/*!40000 ALTER TABLE `imports` DISABLE KEYS */;
/*!40000 ALTER TABLE `imports` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_sources`
--

DROP TABLE IF EXISTS `inventory_sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_sources` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `contact_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_fax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `street` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postcode` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `priority` int NOT NULL DEFAULT '0',
  `latitude` decimal(10,5) DEFAULT NULL,
  `longitude` decimal(10,5) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_sources_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_sources`
--

LOCK TABLES `inventory_sources` WRITE;
/*!40000 ALTER TABLE `inventory_sources` DISABLE KEYS */;
INSERT INTO `inventory_sources` VALUES (1,'RAM','RedActivaMéxico','Inventario principal de RedActivaMéxico','Paulina Mosqueda','paulina.mosqueda@feengster.com','4771377084','','MX','Guanajuato','Guanajuato','12th Street','36250',1,0.00000,0.00000,1,NULL,'2025-12-12 13:07:36');
/*!40000 ALTER TABLE `inventory_sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_items` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `total` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_total` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `tax_amount` decimal(12,4) DEFAULT '0.0000',
  `base_tax_amount` decimal(12,4) DEFAULT '0.0000',
  `discount_percent` decimal(12,4) DEFAULT '0.0000',
  `discount_amount` decimal(12,4) DEFAULT '0.0000',
  `base_discount_amount` decimal(12,4) DEFAULT '0.0000',
  `price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `product_id` int unsigned DEFAULT NULL,
  `product_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_item_id` int unsigned DEFAULT NULL,
  `invoice_id` int unsigned DEFAULT NULL,
  `additional` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_items_invoice_id_foreign` (`invoice_id`),
  KEY `invoice_items_parent_id_foreign` (`parent_id`),
  CONSTRAINT `invoice_items_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoice_items_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `invoice_items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `increment_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_sent` tinyint(1) NOT NULL DEFAULT '0',
  `total_qty` int DEFAULT NULL,
  `base_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_total` decimal(12,4) DEFAULT '0.0000',
  `base_sub_total` decimal(12,4) DEFAULT '0.0000',
  `grand_total` decimal(12,4) DEFAULT '0.0000',
  `base_grand_total` decimal(12,4) DEFAULT '0.0000',
  `shipping_amount` decimal(12,4) DEFAULT '0.0000',
  `base_shipping_amount` decimal(12,4) DEFAULT '0.0000',
  `tax_amount` decimal(12,4) DEFAULT '0.0000',
  `base_tax_amount` decimal(12,4) DEFAULT '0.0000',
  `discount_amount` decimal(12,4) DEFAULT '0.0000',
  `base_discount_amount` decimal(12,4) DEFAULT '0.0000',
  `shipping_tax_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_shipping_tax_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `sub_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_sub_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `shipping_amount_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_shipping_amount_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `order_id` int unsigned DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reminders` int NOT NULL DEFAULT '0',
  `next_reminder_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoices_order_id_foreign` (`order_id`),
  CONSTRAINT `invoices_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locales`
--

DROP TABLE IF EXISTS `locales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locales` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` enum('ltr','rtl') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ltr',
  `logo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `locales_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locales`
--

LOCK TABLES `locales` WRITE;
/*!40000 ALTER TABLE `locales` DISABLE KEYS */;
INSERT INTO `locales` VALUES (1,'es','Español','ltr','locales/es.png',NULL,'2025-12-28 02:11:37');
/*!40000 ALTER TABLE `locales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_campaigns`
--

DROP TABLE IF EXISTS `marketing_campaigns`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_campaigns` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mail_to` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `spooling` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel_id` int unsigned DEFAULT NULL,
  `customer_group_id` int unsigned DEFAULT NULL,
  `marketing_template_id` int unsigned DEFAULT NULL,
  `marketing_event_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `marketing_campaigns_channel_id_foreign` (`channel_id`),
  KEY `marketing_campaigns_customer_group_id_foreign` (`customer_group_id`),
  KEY `marketing_campaigns_marketing_template_id_foreign` (`marketing_template_id`),
  KEY `marketing_campaigns_marketing_event_id_foreign` (`marketing_event_id`),
  CONSTRAINT `marketing_campaigns_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE SET NULL,
  CONSTRAINT `marketing_campaigns_customer_group_id_foreign` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_groups` (`id`) ON DELETE SET NULL,
  CONSTRAINT `marketing_campaigns_marketing_event_id_foreign` FOREIGN KEY (`marketing_event_id`) REFERENCES `marketing_events` (`id`) ON DELETE SET NULL,
  CONSTRAINT `marketing_campaigns_marketing_template_id_foreign` FOREIGN KEY (`marketing_template_id`) REFERENCES `marketing_templates` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_campaigns`
--

LOCK TABLES `marketing_campaigns` WRITE;
/*!40000 ALTER TABLE `marketing_campaigns` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_campaigns` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_events`
--

DROP TABLE IF EXISTS `marketing_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_events` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_events`
--

LOCK TABLES `marketing_events` WRITE;
/*!40000 ALTER TABLE `marketing_events` DISABLE KEYS */;
INSERT INTO `marketing_events` VALUES (1,'Birthday','Birthday',NULL,NULL,NULL);
/*!40000 ALTER TABLE `marketing_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marketing_templates`
--

DROP TABLE IF EXISTS `marketing_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marketing_templates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marketing_templates`
--

LOCK TABLES `marketing_templates` WRITE;
/*!40000 ALTER TABLE `marketing_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `marketing_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=163 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_admin_password_resets_table',1),(3,'2014_10_12_100000_create_password_resets_table',1),(4,'2018_06_12_111907_create_admins_table',1),(5,'2018_06_13_055341_create_roles_table',1),(6,'2018_07_05_130148_create_attributes_table',1),(7,'2018_07_05_132854_create_attribute_translations_table',1),(8,'2018_07_05_135150_create_attribute_families_table',1),(9,'2018_07_05_135152_create_attribute_groups_table',1),(10,'2018_07_05_140832_create_attribute_options_table',1),(11,'2018_07_05_140856_create_attribute_option_translations_table',1),(12,'2018_07_05_142820_create_categories_table',1),(13,'2018_07_10_055143_create_locales_table',1),(14,'2018_07_20_054426_create_countries_table',1),(15,'2018_07_20_054502_create_currencies_table',1),(16,'2018_07_20_054542_create_currency_exchange_rates_table',1),(17,'2018_07_20_064849_create_channels_table',1),(18,'2018_07_21_142836_create_category_translations_table',1),(19,'2018_07_23_110040_create_inventory_sources_table',1),(20,'2018_07_24_082635_create_customer_groups_table',1),(21,'2018_07_24_082930_create_customers_table',1),(22,'2018_07_27_065727_create_products_table',1),(23,'2018_07_27_070011_create_product_attribute_values_table',1),(24,'2018_07_27_092623_create_product_reviews_table',1),(25,'2018_07_27_113941_create_product_images_table',1),(26,'2018_07_27_113956_create_product_inventories_table',1),(27,'2018_08_30_064755_create_tax_categories_table',1),(28,'2018_08_30_065042_create_tax_rates_table',1),(29,'2018_08_30_065840_create_tax_mappings_table',1),(30,'2018_09_05_150444_create_cart_table',1),(31,'2018_09_05_150915_create_cart_items_table',1),(32,'2018_09_11_064045_customer_password_resets',1),(33,'2018_09_19_093453_create_cart_payment',1),(34,'2018_09_19_093508_create_cart_shipping_rates_table',1),(35,'2018_09_20_060658_create_core_config_table',1),(36,'2018_09_27_113154_create_orders_table',1),(37,'2018_09_27_113207_create_order_items_table',1),(38,'2018_09_27_115022_create_shipments_table',1),(39,'2018_09_27_115029_create_shipment_items_table',1),(40,'2018_09_27_115135_create_invoices_table',1),(41,'2018_09_27_115144_create_invoice_items_table',1),(42,'2018_10_01_095504_create_order_payment_table',1),(43,'2018_10_03_025230_create_wishlist_table',1),(44,'2018_10_12_101803_create_country_translations_table',1),(45,'2018_10_12_101913_create_country_states_table',1),(46,'2018_10_12_101923_create_country_state_translations_table',1),(47,'2018_11_16_173504_create_subscribers_list_table',1),(48,'2018_11_21_144411_create_cart_item_inventories_table',1),(49,'2018_12_06_185202_create_product_flat_table',1),(50,'2018_12_24_123812_create_channel_inventory_sources_table',1),(51,'2018_12_26_165327_create_product_ordered_inventories_table',1),(52,'2019_05_13_024321_create_cart_rules_table',1),(53,'2019_05_13_024322_create_cart_rule_channels_table',1),(54,'2019_05_13_024323_create_cart_rule_customer_groups_table',1),(55,'2019_05_13_024324_create_cart_rule_translations_table',1),(56,'2019_05_13_024325_create_cart_rule_customers_table',1),(57,'2019_05_13_024326_create_cart_rule_coupons_table',1),(58,'2019_05_13_024327_create_cart_rule_coupon_usage_table',1),(59,'2019_06_17_180258_create_product_downloadable_samples_table',1),(60,'2019_06_17_180314_create_product_downloadable_sample_translations_table',1),(61,'2019_06_17_180325_create_product_downloadable_links_table',1),(62,'2019_06_17_180346_create_product_downloadable_link_translations_table',1),(63,'2019_06_21_202249_create_downloadable_link_purchased_table',1),(64,'2019_07_02_180307_create_booking_products_table',1),(65,'2019_07_05_154415_create_booking_product_default_slots_table',1),(66,'2019_07_05_154429_create_booking_product_appointment_slots_table',1),(67,'2019_07_05_154440_create_booking_product_event_tickets_table',1),(68,'2019_07_05_154451_create_booking_product_rental_slots_table',1),(69,'2019_07_05_154502_create_booking_product_table_slots_table',1),(70,'2019_07_30_153530_create_cms_pages_table',1),(71,'2019_07_31_143339_create_category_filterable_attributes_table',1),(72,'2019_08_02_105320_create_product_grouped_products_table',1),(73,'2019_08_20_170510_create_product_bundle_options_table',1),(74,'2019_08_20_170520_create_product_bundle_option_translations_table',1),(75,'2019_08_20_170528_create_product_bundle_option_products_table',1),(76,'2019_09_11_184511_create_refunds_table',1),(77,'2019_09_11_184519_create_refund_items_table',1),(78,'2019_12_03_184613_create_catalog_rules_table',1),(79,'2019_12_03_184651_create_catalog_rule_channels_table',1),(80,'2019_12_03_184732_create_catalog_rule_customer_groups_table',1),(81,'2019_12_06_101110_create_catalog_rule_products_table',1),(82,'2019_12_06_110507_create_catalog_rule_product_prices_table',1),(83,'2019_12_14_000001_create_personal_access_tokens_table',1),(84,'2020_01_14_191854_create_cms_page_translations_table',1),(85,'2020_01_15_130209_create_cms_page_channels_table',1),(86,'2020_02_18_165639_create_bookings_table',1),(87,'2020_02_21_121201_create_booking_product_event_ticket_translations_table',1),(88,'2020_04_16_185147_add_table_addresses',1),(89,'2020_05_06_171638_create_order_comments_table',1),(90,'2020_05_21_171500_create_product_customer_group_prices_table',1),(91,'2020_06_25_162154_create_customer_social_accounts_table',1),(92,'2020_08_07_174804_create_gdpr_data_request_table',1),(93,'2020_11_19_112228_create_product_videos_table',1),(94,'2020_11_26_141455_create_marketing_templates_table',1),(95,'2020_11_26_150534_create_marketing_events_table',1),(96,'2020_11_26_150644_create_marketing_campaigns_table',1),(97,'2020_12_21_000200_create_channel_translations_table',1),(98,'2020_12_27_121950_create_jobs_table',1),(99,'2021_03_11_212124_create_order_transactions_table',1),(100,'2021_04_07_132010_create_product_review_images_table',1),(101,'2021_12_15_104544_notifications',1),(102,'2022_03_15_160510_create_failed_jobs_table',1),(103,'2022_04_01_094622_create_sitemaps_table',1),(104,'2022_10_03_144232_create_product_price_indices_table',1),(105,'2022_10_04_144444_create_job_batches_table',1),(106,'2022_10_08_134150_create_product_inventory_indices_table',1),(107,'2023_05_26_213105_create_wishlist_items_table',1),(108,'2023_05_26_213120_create_compare_items_table',1),(109,'2023_06_27_163529_rename_product_review_images_to_product_review_attachments',1),(110,'2023_07_06_140013_add_logo_path_column_to_locales',1),(111,'2023_07_10_184256_create_theme_customizations_table',1),(112,'2023_07_12_181722_remove_home_page_and_footer_content_column_from_channel_translations_table',1),(113,'2023_07_20_185324_add_column_column_in_attribute_groups_table',1),(114,'2023_07_25_145943_add_regex_column_in_attributes_table',1),(115,'2023_07_25_165945_drop_notes_column_from_customers_table',1),(116,'2023_07_25_171058_create_customer_notes_table',1),(117,'2023_07_31_125232_rename_image_and_category_banner_columns_from_categories_table',1),(118,'2023_09_15_170053_create_theme_customization_translations_table',1),(119,'2023_09_20_102031_add_default_value_column_in_attributes_table',1),(120,'2023_09_20_102635_add_inventories_group_in_attribute_groups_table',1),(121,'2023_09_26_155709_add_columns_to_currencies',1),(122,'2023_10_05_163612_create_visits_table',1),(123,'2023_10_12_090446_add_tax_category_id_column_in_order_items_table',1),(124,'2023_11_08_054614_add_code_column_in_attribute_groups_table',1),(125,'2023_11_08_140116_create_search_terms_table',1),(126,'2023_11_09_162805_create_url_rewrites_table',1),(127,'2023_11_17_150401_create_search_synonyms_table',1),(128,'2023_12_11_054614_add_channel_id_column_in_product_price_indices_table',1),(129,'2024_01_11_154640_create_imports_table',1),(130,'2024_01_11_154741_create_import_batches_table',1),(131,'2024_01_19_170350_add_unique_id_column_in_product_attribute_values_table',1),(132,'2024_01_19_170350_add_unique_id_column_in_product_customer_group_prices_table',1),(133,'2024_01_22_170814_add_unique_index_in_mapping_tables',1),(134,'2024_02_26_153000_add_columns_to_addresses_table',1),(135,'2024_03_07_193421_rename_address1_column_in_addresses_table',1),(136,'2024_04_16_144400_add_cart_id_column_in_cart_shipping_rates_table',1),(137,'2024_04_19_102939_add_incl_tax_columns_in_orders_table',1),(138,'2024_04_19_135405_add_incl_tax_columns_in_cart_items_table',1),(139,'2024_04_19_144641_add_incl_tax_columns_in_order_items_table',1),(140,'2024_04_23_133154_add_incl_tax_columns_in_cart_table',1),(141,'2024_04_23_150945_add_incl_tax_columns_in_cart_shipping_rates_table',1),(142,'2024_04_24_102939_add_incl_tax_columns_in_invoices_table',1),(143,'2024_04_24_102939_add_incl_tax_columns_in_refunds_table',1),(144,'2024_04_24_144641_add_incl_tax_columns_in_invoice_items_table',1),(145,'2024_04_24_144641_add_incl_tax_columns_in_refund_items_table',1),(146,'2024_04_24_144641_add_incl_tax_columns_in_shipment_items_table',1),(147,'2024_05_10_152848_create_saved_filters_table',1),(148,'2024_06_03_174128_create_product_channels_table',1),(149,'2024_06_04_130527_add_channel_id_column_in_customers_table',1),(150,'2024_06_04_134403_add_channel_id_column_in_visits_table',1),(151,'2024_06_13_184426_add_theme_column_into_theme_customizations_table',1),(152,'2024_07_17_172645_add_additional_column_to_sitemaps_table',1),(153,'2024_10_11_135010_create_product_customizable_options_table',1),(154,'2024_10_11_135110_create_product_customizable_option_translations_table',1),(155,'2024_10_11_135228_create_product_customizable_option_prices_table',1),(156,'2025_05_07_121250_update_total_weight_columns_in_shipments_and_weight_shipment_items_tables',1),(157,'2025_09_05_000100_add_indexes_to_channels_tables',1),(158,'2025_09_05_000200_add_indexes_to_product_relation_tables',1),(159,'2025_09_05_000300_add_indexes_to_product_media_and_attributes',1),(160,'2025_09_05_000400_add_indexes_to_attributes_and_product_types',1),(161,'2025_09_05_000500_add_indexes_to_product_grouped_products_and_product_bundle_option_products',1),(162,'2025_09_05_000500_add_indexes_to_url_rewrites_and_visits',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT '0',
  `order_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_order_id_foreign` (`order_id`),
  CONSTRAINT `notifications_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_comments`
--

DROP TABLE IF EXISTS `order_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_comments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int unsigned DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_notified` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_comments_order_id_foreign` (`order_id`),
  CONSTRAINT `order_comments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_comments`
--

LOCK TABLES `order_comments` WRITE;
/*!40000 ALTER TABLE `order_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weight` decimal(12,4) DEFAULT '0.0000',
  `total_weight` decimal(12,4) DEFAULT '0.0000',
  `qty_ordered` int DEFAULT '0',
  `qty_shipped` int DEFAULT '0',
  `qty_invoiced` int DEFAULT '0',
  `qty_canceled` int DEFAULT '0',
  `qty_refunded` int DEFAULT '0',
  `price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `total` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_total` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `total_invoiced` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_total_invoiced` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `amount_refunded` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_amount_refunded` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `discount_percent` decimal(12,4) DEFAULT '0.0000',
  `discount_amount` decimal(12,4) DEFAULT '0.0000',
  `base_discount_amount` decimal(12,4) DEFAULT '0.0000',
  `discount_invoiced` decimal(12,4) DEFAULT '0.0000',
  `base_discount_invoiced` decimal(12,4) DEFAULT '0.0000',
  `discount_refunded` decimal(12,4) DEFAULT '0.0000',
  `base_discount_refunded` decimal(12,4) DEFAULT '0.0000',
  `tax_percent` decimal(12,4) DEFAULT '0.0000',
  `tax_amount` decimal(12,4) DEFAULT '0.0000',
  `base_tax_amount` decimal(12,4) DEFAULT '0.0000',
  `tax_amount_invoiced` decimal(12,4) DEFAULT '0.0000',
  `base_tax_amount_invoiced` decimal(12,4) DEFAULT '0.0000',
  `tax_amount_refunded` decimal(12,4) DEFAULT '0.0000',
  `base_tax_amount_refunded` decimal(12,4) DEFAULT '0.0000',
  `price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `product_id` int unsigned DEFAULT NULL,
  `product_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` int unsigned DEFAULT NULL,
  `tax_category_id` int unsigned DEFAULT NULL,
  `parent_id` int unsigned DEFAULT NULL,
  `additional` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  KEY `order_items_parent_id_foreign` (`parent_id`),
  KEY `order_items_tax_category_id_foreign` (`tax_category_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_tax_category_id_foreign` FOREIGN KEY (`tax_category_id`) REFERENCES `tax_categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_payment`
--

DROP TABLE IF EXISTS `order_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_payment` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int unsigned DEFAULT NULL,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_payment_order_id_foreign` (`order_id`),
  CONSTRAINT `order_payment_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_payment`
--

LOCK TABLES `order_payment` WRITE;
/*!40000 ALTER TABLE `order_payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_transactions`
--

DROP TABLE IF EXISTS `order_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(12,4) DEFAULT '0.0000',
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` json DEFAULT NULL,
  `invoice_id` int unsigned NOT NULL,
  `order_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_transactions_order_id_foreign` (`order_id`),
  CONSTRAINT `order_transactions_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_transactions`
--

LOCK TABLES `order_transactions` WRITE;
/*!40000 ALTER TABLE `order_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `increment_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_guest` tinyint(1) DEFAULT NULL,
  `customer_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_gift` tinyint(1) NOT NULL DEFAULT '0',
  `total_item_count` int DEFAULT NULL,
  `total_qty_ordered` int DEFAULT NULL,
  `base_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `grand_total` decimal(12,4) DEFAULT '0.0000',
  `base_grand_total` decimal(12,4) DEFAULT '0.0000',
  `grand_total_invoiced` decimal(12,4) DEFAULT '0.0000',
  `base_grand_total_invoiced` decimal(12,4) DEFAULT '0.0000',
  `grand_total_refunded` decimal(12,4) DEFAULT '0.0000',
  `base_grand_total_refunded` decimal(12,4) DEFAULT '0.0000',
  `sub_total` decimal(12,4) DEFAULT '0.0000',
  `base_sub_total` decimal(12,4) DEFAULT '0.0000',
  `sub_total_invoiced` decimal(12,4) DEFAULT '0.0000',
  `base_sub_total_invoiced` decimal(12,4) DEFAULT '0.0000',
  `sub_total_refunded` decimal(12,4) DEFAULT '0.0000',
  `base_sub_total_refunded` decimal(12,4) DEFAULT '0.0000',
  `discount_percent` decimal(12,4) DEFAULT '0.0000',
  `discount_amount` decimal(12,4) DEFAULT '0.0000',
  `base_discount_amount` decimal(12,4) DEFAULT '0.0000',
  `discount_invoiced` decimal(12,4) DEFAULT '0.0000',
  `base_discount_invoiced` decimal(12,4) DEFAULT '0.0000',
  `discount_refunded` decimal(12,4) DEFAULT '0.0000',
  `base_discount_refunded` decimal(12,4) DEFAULT '0.0000',
  `tax_amount` decimal(12,4) DEFAULT '0.0000',
  `base_tax_amount` decimal(12,4) DEFAULT '0.0000',
  `tax_amount_invoiced` decimal(12,4) DEFAULT '0.0000',
  `base_tax_amount_invoiced` decimal(12,4) DEFAULT '0.0000',
  `tax_amount_refunded` decimal(12,4) DEFAULT '0.0000',
  `base_tax_amount_refunded` decimal(12,4) DEFAULT '0.0000',
  `shipping_amount` decimal(12,4) DEFAULT '0.0000',
  `base_shipping_amount` decimal(12,4) DEFAULT '0.0000',
  `shipping_invoiced` decimal(12,4) DEFAULT '0.0000',
  `base_shipping_invoiced` decimal(12,4) DEFAULT '0.0000',
  `shipping_refunded` decimal(12,4) DEFAULT '0.0000',
  `base_shipping_refunded` decimal(12,4) DEFAULT '0.0000',
  `shipping_discount_amount` decimal(12,4) DEFAULT '0.0000',
  `base_shipping_discount_amount` decimal(12,4) DEFAULT '0.0000',
  `shipping_tax_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_shipping_tax_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `shipping_tax_refunded` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_shipping_tax_refunded` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `sub_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_sub_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `shipping_amount_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_shipping_amount_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `customer_id` int unsigned DEFAULT NULL,
  `customer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel_id` int unsigned DEFAULT NULL,
  `channel_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cart_id` int DEFAULT NULL,
  `applied_cart_rule_ids` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_increment_id_unique` (`increment_id`),
  KEY `orders_customer_id_foreign` (`customer_id`),
  KEY `orders_channel_id_foreign` (`channel_id`),
  CONSTRAINT `orders_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE SET NULL,
  CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_attribute_values`
--

DROP TABLE IF EXISTS `product_attribute_values`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_attribute_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_value` text COLLATE utf8mb4_unicode_ci,
  `boolean_value` tinyint(1) DEFAULT NULL,
  `integer_value` int DEFAULT NULL,
  `float_value` decimal(12,4) DEFAULT NULL,
  `datetime_value` datetime DEFAULT NULL,
  `date_value` date DEFAULT NULL,
  `json_value` json DEFAULT NULL,
  `product_id` int unsigned NOT NULL,
  `attribute_id` int unsigned NOT NULL,
  `unique_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `chanel_locale_attribute_value_index_unique` (`channel`,`locale`,`attribute_id`,`product_id`),
  UNIQUE KEY `product_attribute_values_unique_id_unique` (`unique_id`),
  KEY `product_attribute_values_attribute_id_foreign` (`attribute_id`),
  KEY `prod_attr_product_id_idx` (`product_id`),
  CONSTRAINT `product_attribute_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_attribute_values_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1463 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_attribute_values`
--

LOCK TABLES `product_attribute_values` WRITE;
/*!40000 ALTER TABLE `product_attribute_values` DISABLE KEYS */;
INSERT INTO `product_attribute_values` VALUES (1,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1,5,'1|5'),(2,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1,6,'1|6'),(3,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1,7,'1|7'),(4,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,1,8,'default|1|8'),(5,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1,26,'1|26'),(6,'es',NULL,'<p>Test</p>',NULL,NULL,NULL,NULL,NULL,NULL,1,9,'es|1|9'),(7,'es',NULL,'<p>Test</p>',NULL,NULL,NULL,NULL,NULL,NULL,1,10,'es|1|10'),(8,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,1,19,'1|19'),(9,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,1,20,'1|20'),(10,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,1,21,'1|21'),(11,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,1,22,'1|22'),(12,NULL,NULL,'001',NULL,NULL,NULL,NULL,NULL,NULL,1,1,'1|1'),(13,'es',NULL,'Prueba',NULL,NULL,NULL,NULL,NULL,NULL,1,2,'es|1|2'),(14,'es',NULL,'prueba',NULL,NULL,NULL,NULL,NULL,NULL,1,3,'es|1|3'),(15,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,1,23,'1|23'),(16,NULL,NULL,NULL,NULL,6,NULL,NULL,NULL,NULL,1,24,'1|24'),(17,NULL,NULL,'Test',NULL,NULL,NULL,NULL,NULL,NULL,1,27,'1|27'),(18,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,1,28,'default|1|28'),(19,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,1,16,'es|1|16'),(20,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,1,17,'es|1|17'),(21,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,1,18,'es|1|18'),(22,NULL,NULL,NULL,NULL,NULL,95.0000,NULL,NULL,NULL,1,11,'1|11'),(23,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,1,12,'1|12'),(24,NULL,NULL,NULL,NULL,NULL,90.0000,NULL,NULL,NULL,1,13,'1|13'),(25,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,14,'default|1|14'),(26,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,15,'default|1|15'),(27,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,2,5,'2|5'),(28,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,2,6,'2|6'),(29,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,2,7,'2|7'),(30,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,2,8,'default|2|8'),(31,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,2,26,'2|26'),(32,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,2,9,'es|2|9'),(33,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,2,10,'es|2|10'),(34,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,2,19,'2|19'),(35,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,2,20,'2|20'),(36,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,2,21,'2|21'),(37,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,2,22,'2|22'),(38,NULL,NULL,'RAM-FOOD-001',NULL,NULL,NULL,NULL,NULL,NULL,2,1,'2|1'),(39,'es',NULL,'Las Hijas de la Tostada',NULL,NULL,NULL,NULL,NULL,NULL,2,2,'es|2|2'),(40,'es',NULL,'las-hijas-de-la-tostada',NULL,NULL,NULL,NULL,NULL,NULL,2,3,'es|2|3'),(41,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL,2,27,'2|27'),(42,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,2,28,'default|2|28'),(43,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,2,16,'es|2|16'),(44,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,2,17,'es|2|17'),(45,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,2,18,'es|2|18'),(46,NULL,NULL,NULL,NULL,NULL,80.0000,NULL,NULL,NULL,2,11,'2|11'),(47,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,12,'2|12'),(48,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,13,'2|13'),(49,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,14,'default|2|14'),(50,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,2,15,'default|2|15'),(51,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,3,5,'3|5'),(52,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,3,6,'3|6'),(53,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,3,7,'3|7'),(54,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,3,8,'default|3|8'),(55,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,3,26,'3|26'),(56,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,3,9,'es|3|9'),(57,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,3,10,'es|3|10'),(58,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,3,19,'3|19'),(59,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,3,20,'3|20'),(60,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,3,21,'3|21'),(61,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,3,22,'3|22'),(62,NULL,NULL,'RAM-FOOD-002',NULL,NULL,NULL,NULL,NULL,NULL,3,1,'3|1'),(63,'es',NULL,'Puerto Madero',NULL,NULL,NULL,NULL,NULL,NULL,3,2,'es|3|2'),(64,'es',NULL,'puerto-madero',NULL,NULL,NULL,NULL,NULL,NULL,3,3,'es|3|3'),(65,NULL,NULL,'2',NULL,NULL,NULL,NULL,NULL,NULL,3,27,'3|27'),(66,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,3,28,'default|3|28'),(67,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,3,16,'es|3|16'),(68,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,3,17,'es|3|17'),(69,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,3,18,'es|3|18'),(70,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,3,11,'3|11'),(71,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,12,'3|12'),(72,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,13,'3|13'),(73,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,14,'default|3|14'),(74,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,15,'default|3|15'),(75,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,4,5,'4|5'),(76,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,4,6,'4|6'),(77,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,4,7,'4|7'),(78,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,4,8,'default|4|8'),(79,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,4,26,'4|26'),(80,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,4,9,'es|4|9'),(81,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,4,10,'es|4|10'),(82,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,4,19,'4|19'),(83,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,4,20,'4|20'),(84,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,4,21,'4|21'),(85,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,4,22,'4|22'),(86,NULL,NULL,'RAM-FOOD-003',NULL,NULL,NULL,NULL,NULL,NULL,4,1,'4|1'),(87,'es',NULL,'La Buena Barra',NULL,NULL,NULL,NULL,NULL,NULL,4,2,'es|4|2'),(88,'es',NULL,'la-buena-barra',NULL,NULL,NULL,NULL,NULL,NULL,4,3,'es|4|3'),(89,NULL,NULL,'3',NULL,NULL,NULL,NULL,NULL,NULL,4,27,'4|27'),(90,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,4,28,'default|4|28'),(91,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,4,16,'es|4|16'),(92,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,4,17,'es|4|17'),(93,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,4,18,'es|4|18'),(94,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,4,11,'4|11'),(95,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,12,'4|12'),(96,NULL,NULL,NULL,NULL,NULL,90.0000,NULL,NULL,NULL,4,13,'4|13'),(97,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,14,'default|4|14'),(98,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,4,15,'default|4|15'),(99,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,5,5,'5|5'),(100,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,5,6,'5|6'),(101,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,5,7,'5|7'),(102,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,5,8,'default|5|8'),(103,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,5,26,'5|26'),(104,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,5,9,'es|5|9'),(105,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,5,10,'es|5|10'),(106,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,5,19,'5|19'),(107,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,5,20,'5|20'),(108,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,5,21,'5|21'),(109,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,5,22,'5|22'),(110,NULL,NULL,'RAM-FOOD-004',NULL,NULL,NULL,NULL,NULL,NULL,5,1,'5|1'),(111,'es',NULL,'Brass',NULL,NULL,NULL,NULL,NULL,NULL,5,2,'es|5|2'),(112,'es',NULL,'brass',NULL,NULL,NULL,NULL,NULL,NULL,5,3,'es|5|3'),(113,NULL,NULL,'4',NULL,NULL,NULL,NULL,NULL,NULL,5,27,'5|27'),(114,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,5,28,'default|5|28'),(115,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,5,16,'es|5|16'),(116,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,5,17,'es|5|17'),(117,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,5,18,'es|5|18'),(118,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,5,11,'5|11'),(119,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,12,'5|12'),(120,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,13,'5|13'),(121,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,14,'default|5|14'),(122,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,5,15,'default|5|15'),(123,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,7,5,'7|5'),(124,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,7,6,'7|6'),(125,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,7,7,'7|7'),(126,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,7,8,'default|7|8'),(127,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,7,26,'7|26'),(128,'es',NULL,'<p>Descuento sugerido 5%</p>',NULL,NULL,NULL,NULL,NULL,NULL,7,9,'es|7|9'),(129,'es',NULL,'<p>Descuento sugerido 5%</p>',NULL,NULL,NULL,NULL,NULL,NULL,7,10,'es|7|10'),(130,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,7,19,'7|19'),(131,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,7,20,'7|20'),(132,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,7,21,'7|21'),(133,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,7,22,'7|22'),(134,NULL,NULL,'RAM-FOOD-005',NULL,NULL,NULL,NULL,NULL,NULL,7,1,'7|1'),(135,'es',NULL,'Pescaditos',NULL,NULL,NULL,NULL,NULL,NULL,7,2,'es|7|2'),(136,'es',NULL,'pescaditos',NULL,NULL,NULL,NULL,NULL,NULL,7,3,'es|7|3'),(137,NULL,NULL,'5',NULL,NULL,NULL,NULL,NULL,NULL,7,27,'7|27'),(138,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,7,28,'default|7|28'),(139,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,7,16,'es|7|16'),(140,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,7,17,'es|7|17'),(141,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,7,18,'es|7|18'),(142,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,7,11,'7|11'),(143,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,12,'7|12'),(144,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,13,'7|13'),(145,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,14,'default|7|14'),(146,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,7,15,'default|7|15'),(147,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,8,5,'8|5'),(148,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,8,6,'8|6'),(149,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,8,7,'8|7'),(150,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,8,8,'default|8|8'),(151,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,8,26,'8|26'),(152,'es',NULL,'<p>Descuento sugerido 7%</p>',NULL,NULL,NULL,NULL,NULL,NULL,8,9,'es|8|9'),(153,'es',NULL,'<p>Descuento sugerido 7%</p>',NULL,NULL,NULL,NULL,NULL,NULL,8,10,'es|8|10'),(154,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,8,19,'8|19'),(155,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,8,20,'8|20'),(156,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,8,21,'8|21'),(157,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,8,22,'8|22'),(158,NULL,NULL,'RAM-FOOD-006',NULL,NULL,NULL,NULL,NULL,NULL,8,1,'8|1'),(159,'es',NULL,'La Parrilla',NULL,NULL,NULL,NULL,NULL,NULL,8,2,'es|8|2'),(160,'es',NULL,'la-parrilla',NULL,NULL,NULL,NULL,NULL,NULL,8,3,'es|8|3'),(161,NULL,NULL,'6',NULL,NULL,NULL,NULL,NULL,NULL,8,27,'8|27'),(162,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,8,28,'default|8|28'),(163,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,8,16,'es|8|16'),(164,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,8,17,'es|8|17'),(165,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,8,18,'es|8|18'),(166,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,8,11,'8|11'),(167,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,12,'8|12'),(168,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,13,'8|13'),(169,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,14,'default|8|14'),(170,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,8,15,'default|8|15'),(171,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,9,5,'9|5'),(172,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,9,6,'9|6'),(173,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,9,7,'9|7'),(174,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,9,8,'default|9|8'),(175,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,9,26,'9|26'),(176,'es',NULL,'<p>Descuento sugerido 7%</p>',NULL,NULL,NULL,NULL,NULL,NULL,9,9,'es|9|9'),(177,'es',NULL,'<p>Descuento sugerido 7%</p>',NULL,NULL,NULL,NULL,NULL,NULL,9,10,'es|9|10'),(178,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,9,19,'9|19'),(179,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,9,20,'9|20'),(180,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,9,21,'9|21'),(181,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,9,22,'9|22'),(182,NULL,NULL,'RAM-FOOD-007',NULL,NULL,NULL,NULL,NULL,NULL,9,1,'9|1'),(183,'es',NULL,'Pollo Feliz',NULL,NULL,NULL,NULL,NULL,NULL,9,2,'es|9|2'),(184,'es',NULL,'pollo-feliz',NULL,NULL,NULL,NULL,NULL,NULL,9,3,'es|9|3'),(185,NULL,NULL,'7',NULL,NULL,NULL,NULL,NULL,NULL,9,27,'9|27'),(186,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,9,28,'default|9|28'),(187,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,9,16,'es|9|16'),(188,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,9,17,'es|9|17'),(189,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,9,18,'es|9|18'),(190,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,9,11,'9|11'),(191,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,9,12,'9|12'),(192,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,9,13,'9|13'),(193,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,9,14,'default|9|14'),(194,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,9,15,'default|9|15'),(195,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,10,5,'10|5'),(196,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,10,6,'10|6'),(197,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,10,7,'10|7'),(198,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,10,8,'default|10|8'),(199,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,10,26,'10|26'),(200,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,10,9,'es|10|9'),(201,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,10,10,'es|10|10'),(202,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,10,19,'10|19'),(203,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,10,20,'10|20'),(204,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,10,21,'10|21'),(205,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,10,22,'10|22'),(206,NULL,NULL,'RAM-FOOD-008',NULL,NULL,NULL,NULL,NULL,NULL,10,1,'10|1'),(207,'es',NULL,'Sensei Sushi Bar',NULL,NULL,NULL,NULL,NULL,NULL,10,2,'es|10|2'),(208,'es',NULL,'sensei-sushi-bar',NULL,NULL,NULL,NULL,NULL,NULL,10,3,'es|10|3'),(209,NULL,NULL,'8',NULL,NULL,NULL,NULL,NULL,NULL,10,27,'10|27'),(210,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,10,28,'default|10|28'),(211,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,10,16,'es|10|16'),(212,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,10,17,'es|10|17'),(213,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,10,18,'es|10|18'),(214,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,10,11,'10|11'),(215,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,12,'10|12'),(216,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,13,'10|13'),(217,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,14,'default|10|14'),(218,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,15,'default|10|15'),(219,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,11,5,'11|5'),(220,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,11,6,'11|6'),(221,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,11,7,'11|7'),(222,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,11,8,'default|11|8'),(223,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,11,26,'11|26'),(224,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,11,9,'es|11|9'),(225,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,11,10,'es|11|10'),(226,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,11,19,'11|19'),(227,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,11,20,'11|20'),(228,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,11,21,'11|21'),(229,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,11,22,'11|22'),(230,NULL,NULL,'RAM-FOOD-011',NULL,NULL,NULL,NULL,NULL,NULL,11,1,'11|1'),(231,'es',NULL,'100%Natural',NULL,NULL,NULL,NULL,NULL,NULL,11,2,'es|11|2'),(232,'es',NULL,'100natural',NULL,NULL,NULL,NULL,NULL,NULL,11,3,'es|11|3'),(233,NULL,NULL,'9',NULL,NULL,NULL,NULL,NULL,NULL,11,27,'11|27'),(234,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,11,28,'default|11|28'),(235,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,11,16,'es|11|16'),(236,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,11,17,'es|11|17'),(237,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,11,18,'es|11|18'),(238,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,11,11,'11|11'),(239,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,11,12,'11|12'),(240,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,11,13,'11|13'),(241,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,11,14,'default|11|14'),(242,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,11,15,'default|11|15'),(243,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,12,5,'12|5'),(244,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,12,6,'12|6'),(245,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,12,7,'12|7'),(246,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,12,8,'default|12|8'),(247,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,12,26,'12|26'),(248,'es',NULL,'<p>10 % - Beneficio o promoción sugerida válida en restaurantes de la cadena Rosa Negra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,12,9,'es|12|9'),(249,'es',NULL,'<p>Beneficio o promoción sugerida válida en restaurantes de la cadena Rosa Negra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,12,10,'es|12|10'),(250,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,12,19,'12|19'),(251,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,12,20,'12|20'),(252,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,12,21,'12|21'),(253,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,12,22,'12|22'),(254,NULL,NULL,'RAM-FOOD-012',NULL,NULL,NULL,NULL,NULL,NULL,12,1,'12|1'),(255,'es',NULL,'Grupo Rosa Negra',NULL,NULL,NULL,NULL,NULL,NULL,12,2,'es|12|2'),(256,'es',NULL,'grupo-rosa-negra',NULL,NULL,NULL,NULL,NULL,NULL,12,3,'es|12|3'),(257,NULL,NULL,'10',NULL,NULL,NULL,NULL,NULL,NULL,12,27,'12|27'),(258,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,12,28,'default|12|28'),(259,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,12,16,'es|12|16'),(260,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,12,17,'es|12|17'),(261,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,12,18,'es|12|18'),(262,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,12,11,'12|11'),(263,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,12,12,'12|12'),(264,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,12,13,'12|13'),(265,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,12,14,'default|12|14'),(266,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,12,15,'default|12|15'),(267,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,13,5,'13|5'),(268,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,13,6,'13|6'),(269,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,13,7,'13|7'),(270,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,13,8,'default|13|8'),(271,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,13,26,'13|26'),(272,'es',NULL,'<p>10 % - Beneficio o promoción sugerida válida en restaurantes de la cadena Anderson´s. </p>',NULL,NULL,NULL,NULL,NULL,NULL,13,9,'es|13|9'),(273,'es',NULL,'<p>Beneficio o promoción sugerida válida en restaurantes de la cadena Anderson´s. </p>',NULL,NULL,NULL,NULL,NULL,NULL,13,10,'es|13|10'),(274,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,13,19,'13|19'),(275,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,13,20,'13|20'),(276,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,13,21,'13|21'),(277,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,13,22,'13|22'),(278,NULL,NULL,'RAM-FOOD-013',NULL,NULL,NULL,NULL,NULL,NULL,13,1,'13|1'),(279,'es',NULL,'Grupo Anderson',NULL,NULL,NULL,NULL,NULL,NULL,13,2,'es|13|2'),(280,'es',NULL,'grupo-anderson',NULL,NULL,NULL,NULL,NULL,NULL,13,3,'es|13|3'),(281,NULL,NULL,'11',NULL,NULL,NULL,NULL,NULL,NULL,13,27,'13|27'),(282,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,13,28,'default|13|28'),(283,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,13,16,'es|13|16'),(284,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,13,17,'es|13|17'),(285,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,13,18,'es|13|18'),(286,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,13,11,'13|11'),(287,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,13,12,'13|12'),(288,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,13,13,'13|13'),(289,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,13,14,'default|13|14'),(290,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,13,15,'default|13|15'),(291,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,14,5,'14|5'),(292,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,14,6,'14|6'),(293,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,14,7,'14|7'),(294,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,14,8,'default|14|8'),(295,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,14,26,'14|26'),(296,'es',NULL,'<p>Descuento sugerido 5%</p>',NULL,NULL,NULL,NULL,NULL,NULL,14,9,'es|14|9'),(297,'es',NULL,'<p>Descuento sugerido 5%</p>',NULL,NULL,NULL,NULL,NULL,NULL,14,10,'es|14|10'),(298,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,14,19,'14|19'),(299,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,14,20,'14|20'),(300,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,14,21,'14|21'),(301,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,14,22,'14|22'),(302,NULL,NULL,'RAM-FOOD-014',NULL,NULL,NULL,NULL,NULL,NULL,14,1,'14|1'),(303,'es',NULL,'El pibito',NULL,NULL,NULL,NULL,NULL,NULL,14,2,'es|14|2'),(304,'es',NULL,'el-pibito',NULL,NULL,NULL,NULL,NULL,NULL,14,3,'es|14|3'),(305,NULL,NULL,'12',NULL,NULL,NULL,NULL,NULL,NULL,14,27,'14|27'),(306,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,14,28,'default|14|28'),(307,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,14,16,'es|14|16'),(308,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,14,17,'es|14|17'),(309,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,14,18,'es|14|18'),(310,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,14,11,'14|11'),(311,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,14,12,'14|12'),(312,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,14,13,'14|13'),(313,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,14,14,'default|14|14'),(314,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,14,15,'default|14|15'),(315,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,16,5,'16|5'),(316,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,16,6,'16|6'),(317,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,16,7,'16|7'),(318,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,16,8,'default|16|8'),(319,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,16,26,'16|26'),(320,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,16,9,'es|16|9'),(321,'es',NULL,'<p>Descuento sugerido 10%</p>',NULL,NULL,NULL,NULL,NULL,NULL,16,10,'es|16|10'),(322,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,16,19,'16|19'),(323,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,16,20,'16|20'),(324,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,16,21,'16|21'),(325,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,16,22,'16|22'),(326,NULL,NULL,'RAM-FOOD-015',NULL,NULL,NULL,NULL,NULL,NULL,16,1,'16|1'),(327,'es',NULL,'Pécano',NULL,NULL,NULL,NULL,NULL,NULL,16,2,'es|16|2'),(328,'es',NULL,'pecano',NULL,NULL,NULL,NULL,NULL,NULL,16,3,'es|16|3'),(329,NULL,NULL,'13',NULL,NULL,NULL,NULL,NULL,NULL,16,27,'16|27'),(330,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,16,28,'default|16|28'),(331,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,16,16,'es|16|16'),(332,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,16,17,'es|16|17'),(333,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,16,18,'es|16|18'),(334,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,16,11,'16|11'),(335,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,16,12,'16|12'),(336,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,16,13,'16|13'),(337,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,16,14,'default|16|14'),(338,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,16,15,'default|16|15'),(339,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,17,5,'17|5'),(340,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,17,6,'17|6'),(341,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,17,7,'17|7'),(342,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,17,8,'default|17|8'),(343,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,17,26,'17|26'),(344,'es',NULL,'<p>Descuento sugerido 5%</p>',NULL,NULL,NULL,NULL,NULL,NULL,17,9,'es|17|9'),(345,'es',NULL,'<p>Descuento sugerido 5%</p>',NULL,NULL,NULL,NULL,NULL,NULL,17,10,'es|17|10'),(346,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,17,19,'17|19'),(347,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,17,20,'17|20'),(348,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,17,21,'17|21'),(349,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,17,22,'17|22'),(350,NULL,NULL,'RAM-FOOD-016',NULL,NULL,NULL,NULL,NULL,NULL,17,1,'17|1'),(351,'es',NULL,'El Chicharrón del Patrón',NULL,NULL,NULL,NULL,NULL,NULL,17,2,'es|17|2'),(352,'es',NULL,'el-chicharron-del-patron',NULL,NULL,NULL,NULL,NULL,NULL,17,3,'es|17|3'),(353,NULL,NULL,'14',NULL,NULL,NULL,NULL,NULL,NULL,17,27,'17|27'),(354,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,17,28,'default|17|28'),(355,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,17,16,'es|17|16'),(356,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,17,17,'es|17|17'),(357,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,17,18,'es|17|18'),(358,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,17,11,'17|11'),(359,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,17,12,'17|12'),(360,NULL,NULL,NULL,NULL,NULL,90.0000,NULL,NULL,NULL,17,13,'17|13'),(361,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,17,14,'default|17|14'),(362,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,17,15,'default|17|15'),(363,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,18,5,'18|5'),(364,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,18,6,'18|6'),(365,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,18,7,'18|7'),(366,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,18,8,'default|18|8'),(367,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,18,26,'18|26'),(368,'es',NULL,'<p>Centro Comercial </p>',NULL,NULL,NULL,NULL,NULL,NULL,18,9,'es|18|9'),(369,'es',NULL,'<p>Centro Comercial </p>',NULL,NULL,NULL,NULL,NULL,NULL,18,10,'es|18|10'),(370,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,18,19,'18|19'),(371,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,18,20,'18|20'),(372,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,18,21,'18|21'),(373,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,18,22,'18|22'),(374,NULL,NULL,'RAM-PLAZA-001',NULL,NULL,NULL,NULL,NULL,NULL,18,1,'18|1'),(375,'es',NULL,'Las Plazas Outlet',NULL,NULL,NULL,NULL,NULL,NULL,18,2,'es|18|2'),(376,'es',NULL,'las-plazas-outlet',NULL,NULL,NULL,NULL,NULL,NULL,18,3,'es|18|3'),(377,NULL,NULL,'15',NULL,NULL,NULL,NULL,NULL,NULL,18,27,'18|27'),(378,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,18,28,'default|18|28'),(379,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,18,16,'es|18|16'),(380,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,18,17,'es|18|17'),(381,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,18,18,'es|18|18'),(382,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,18,11,'18|11'),(383,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,18,12,'18|12'),(384,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,18,13,'18|13'),(385,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,18,14,'default|18|14'),(386,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,18,15,'default|18|15'),(387,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,19,5,'19|5'),(388,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,19,6,'19|6'),(389,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,19,7,'19|7'),(390,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,19,8,'default|19|8'),(391,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,19,26,'19|26'),(392,'es',NULL,'<p>Centro Comercial </p>',NULL,NULL,NULL,NULL,NULL,NULL,19,9,'es|19|9'),(393,'es',NULL,'<p>Centro Comercial </p>',NULL,NULL,NULL,NULL,NULL,NULL,19,10,'es|19|10'),(394,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,19,19,'19|19'),(395,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,19,20,'19|20'),(396,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,19,21,'19|21'),(397,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,19,22,'19|22'),(398,NULL,NULL,'RAM-PLAZA-002',NULL,NULL,NULL,NULL,NULL,NULL,19,1,'19|1'),(399,'es',NULL,'Plaza Las Américas',NULL,NULL,NULL,NULL,NULL,NULL,19,2,'es|19|2'),(400,'es',NULL,'plaza-las-americas',NULL,NULL,NULL,NULL,NULL,NULL,19,3,'es|19|3'),(401,NULL,NULL,'16',NULL,NULL,NULL,NULL,NULL,NULL,19,27,'19|27'),(402,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,19,28,'default|19|28'),(403,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,19,16,'es|19|16'),(404,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,19,17,'es|19|17'),(405,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,19,18,'es|19|18'),(406,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,19,11,'19|11'),(407,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,19,12,'19|12'),(408,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,19,13,'19|13'),(409,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,19,14,'default|19|14'),(410,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,19,15,'default|19|15'),(411,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,20,5,'20|5'),(412,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,20,6,'20|6'),(413,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,20,7,'20|7'),(414,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,20,8,'default|20|8'),(415,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,20,26,'20|26'),(416,'es',NULL,'<p>Centro Comercial </p>',NULL,NULL,NULL,NULL,NULL,NULL,20,9,'es|20|9'),(417,'es',NULL,'<p>Centro Comercial </p>',NULL,NULL,NULL,NULL,NULL,NULL,20,10,'es|20|10'),(418,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,20,19,'20|19'),(419,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,20,20,'20|20'),(420,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,20,21,'20|21'),(421,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,20,22,'20|22'),(422,NULL,NULL,'RAM-PLAZA-003',NULL,NULL,NULL,NULL,NULL,NULL,20,1,'20|1'),(423,'es',NULL,'Plaza Malecón Las Americas',NULL,NULL,NULL,NULL,NULL,NULL,20,2,'es|20|2'),(424,'es',NULL,'plaza-malecon-las-americas',NULL,NULL,NULL,NULL,NULL,NULL,20,3,'es|20|3'),(425,NULL,NULL,'17',NULL,NULL,NULL,NULL,NULL,NULL,20,27,'20|27'),(426,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,20,28,'default|20|28'),(427,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,20,16,'es|20|16'),(428,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,20,17,'es|20|17'),(429,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,20,18,'es|20|18'),(430,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,20,11,'20|11'),(431,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,20,12,'20|12'),(432,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,20,13,'20|13'),(433,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,20,14,'default|20|14'),(434,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,20,15,'default|20|15'),(435,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,21,5,'21|5'),(436,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,21,6,'21|6'),(437,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,21,7,'21|7'),(438,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,21,8,'default|21|8'),(439,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,21,26,'21|26'),(440,'es',NULL,'<p>Centro Comercial </p>',NULL,NULL,NULL,NULL,NULL,NULL,21,9,'es|21|9'),(441,'es',NULL,'<p>Centro Comercial </p>',NULL,NULL,NULL,NULL,NULL,NULL,21,10,'es|21|10'),(442,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,21,19,'21|19'),(443,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,21,20,'21|20'),(444,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,21,21,'21|21'),(445,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,21,22,'21|22'),(446,NULL,NULL,'RAM-PLAZA-004',NULL,NULL,NULL,NULL,NULL,NULL,21,1,'21|1'),(447,'es',NULL,'Plaza La Isla Cancún',NULL,NULL,NULL,NULL,NULL,NULL,21,2,'es|21|2'),(448,'es',NULL,'plaza-la-isla-cancun',NULL,NULL,NULL,NULL,NULL,NULL,21,3,'es|21|3'),(449,NULL,NULL,'18',NULL,NULL,NULL,NULL,NULL,NULL,21,27,'21|27'),(450,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,21,28,'default|21|28'),(451,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,21,16,'es|21|16'),(452,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,21,17,'es|21|17'),(453,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,21,18,'es|21|18'),(454,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,21,11,'21|11'),(455,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,21,12,'21|12'),(456,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,21,13,'21|13'),(457,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,21,14,'default|21|14'),(458,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,21,15,'default|21|15'),(459,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,22,5,'22|5'),(460,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,22,6,'22|6'),(461,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,22,7,'22|7'),(462,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,22,8,'default|22|8'),(463,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,22,26,'22|26'),(464,'es',NULL,'<p>Centro Comercial</p>',NULL,NULL,NULL,NULL,NULL,NULL,22,9,'es|22|9'),(465,'es',NULL,'<p>Centro Comercial</p>',NULL,NULL,NULL,NULL,NULL,NULL,22,10,'es|22|10'),(466,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,22,19,'22|19'),(467,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,22,20,'22|20'),(468,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,22,21,'22|21'),(469,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,22,22,'22|22'),(470,NULL,NULL,'RAM-PLAZA-005',NULL,NULL,NULL,NULL,NULL,NULL,22,1,'22|1'),(471,'es',NULL,'Plaza Cancún Mall',NULL,NULL,NULL,NULL,NULL,NULL,22,2,'es|22|2'),(472,'es',NULL,'plaza-cancun-mall',NULL,NULL,NULL,NULL,NULL,NULL,22,3,'es|22|3'),(473,NULL,NULL,'19',NULL,NULL,NULL,NULL,NULL,NULL,22,27,'22|27'),(474,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,22,28,'default|22|28'),(475,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,22,16,'es|22|16'),(476,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,22,17,'es|22|17'),(477,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,22,18,'es|22|18'),(478,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,22,11,'22|11'),(479,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,22,12,'22|12'),(480,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,22,13,'22|13'),(481,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,22,14,'default|22|14'),(482,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,22,15,'default|22|15'),(483,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,23,5,'23|5'),(484,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,23,6,'23|6'),(485,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,23,7,'23|7'),(486,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,23,8,'default|23|8'),(487,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,23,26,'23|26'),(488,'es',NULL,'<p>10% - Membresía de viaje creada por RAM para que disfrutes de precios de mayorista en hoteles, vuelos y actividades alrededor del mundo. (Promoción sugerida) </p>',NULL,NULL,NULL,NULL,NULL,NULL,23,9,'es|23|9'),(489,'es',NULL,'<p>10% - Membresía de viaje creada por RAM para que disfrutes de precios de mayorista en hoteles, vuelos y actividades alrededor del mundo. (Promoción sugerida) </p>',NULL,NULL,NULL,NULL,NULL,NULL,23,10,'es|23|10'),(490,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,23,19,'23|19'),(491,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,23,20,'23|20'),(492,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,23,21,'23|21'),(493,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,23,22,'23|22'),(494,NULL,NULL,'RAM-SERV-TUR-001',NULL,NULL,NULL,NULL,NULL,NULL,23,1,'23|1'),(495,'es',NULL,'Skyverse',NULL,NULL,NULL,NULL,NULL,NULL,23,2,'es|23|2'),(496,'es',NULL,'skyverse',NULL,NULL,NULL,NULL,NULL,NULL,23,3,'es|23|3'),(497,NULL,NULL,'20',NULL,NULL,NULL,NULL,NULL,NULL,23,27,'23|27'),(498,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,23,28,'default|23|28'),(499,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,23,16,'es|23|16'),(500,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,23,17,'es|23|17'),(501,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,23,18,'es|23|18'),(502,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,23,11,'23|11'),(503,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,23,12,'23|12'),(504,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,23,13,'23|13'),(505,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,23,14,'default|23|14'),(506,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,23,15,'default|23|15'),(507,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,24,5,'24|5'),(508,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,24,6,'24|6'),(509,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,24,7,'24|7'),(510,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,24,8,'default|24|8'),(511,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,24,26,'24|26'),(512,'es',NULL,'<p>60USD - Agencia de tours a Sian Kaan  (Promoción sugerida) </p>',NULL,NULL,NULL,NULL,NULL,NULL,24,9,'es|24|9'),(513,'es',NULL,'<p>60USD - Agencia de tours a Sian Kaan  (Promoción sugerida) </p>',NULL,NULL,NULL,NULL,NULL,NULL,24,10,'es|24|10'),(514,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,24,19,'24|19'),(515,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,24,20,'24|20'),(516,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,24,21,'24|21'),(517,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,24,22,'24|22'),(518,NULL,NULL,'RAM-SERV-TUR-002',NULL,NULL,NULL,NULL,NULL,NULL,24,1,'24|1'),(519,'es',NULL,'Community Tours Sian Kaan',NULL,NULL,NULL,NULL,NULL,NULL,24,2,'es|24|2'),(520,'es',NULL,'community-tours-sian-kaan',NULL,NULL,NULL,NULL,NULL,NULL,24,3,'es|24|3'),(521,NULL,NULL,'21',NULL,NULL,NULL,NULL,NULL,NULL,24,27,'24|27'),(522,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,24,28,'default|24|28'),(523,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,24,16,'es|24|16'),(524,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,24,17,'es|24|17'),(525,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,24,18,'es|24|18'),(526,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,24,11,'24|11'),(527,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,24,12,'24|12'),(528,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,24,13,'24|13'),(529,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,24,14,'default|24|14'),(530,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,24,15,'default|24|15'),(531,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,25,5,'25|5'),(532,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,25,6,'25|6'),(533,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,25,7,'25|7'),(534,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,25,8,'default|25|8'),(535,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,25,26,'25|26'),(536,'es',NULL,'<p>15% - Empresa especializada en la venta y operación de catamaranes en el sector turístico. (Promoción sugerida) </p>',NULL,NULL,NULL,NULL,NULL,NULL,25,9,'es|25|9'),(537,'es',NULL,'<p>15% - Empresa especializada en la venta y operación de catamaranes en el sector turístico. (Promoción sugerida) </p>',NULL,NULL,NULL,NULL,NULL,NULL,25,10,'es|25|10'),(538,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,25,19,'25|19'),(539,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,25,20,'25|20'),(540,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,25,21,'25|21'),(541,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,25,22,'25|22'),(542,NULL,NULL,'RAM-SERV-TUR-003',NULL,NULL,NULL,NULL,NULL,NULL,25,1,'25|1'),(543,'es',NULL,'Oceanix Náuticos',NULL,NULL,NULL,NULL,NULL,NULL,25,2,'es|25|2'),(544,'es',NULL,'oceanix-nauticos',NULL,NULL,NULL,NULL,NULL,NULL,25,3,'es|25|3'),(545,NULL,NULL,'22',NULL,NULL,NULL,NULL,NULL,NULL,25,27,'25|27'),(546,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,25,28,'default|25|28'),(547,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,25,16,'es|25|16'),(548,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,25,17,'es|25|17'),(549,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,25,18,'es|25|18'),(550,NULL,NULL,NULL,NULL,NULL,100.0000,NULL,NULL,NULL,25,11,'25|11'),(551,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25,12,'25|12'),(552,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,25,13,'25|13'),(553,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,25,14,'default|25|14'),(554,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,25,15,'default|25|15'),(555,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,26,5,'26|5'),(556,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,26,6,'26|6'),(557,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,26,7,'26|7'),(558,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,26,8,'default|26|8'),(559,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,26,26,'26|26'),(560,'es',NULL,'<p>75USD - Beneficio o promoción sugerida válida en Capitan Hook</p>',NULL,NULL,NULL,NULL,NULL,NULL,26,9,'es|26|9'),(561,'es',NULL,'<p>75USD - Beneficio o promoción sugerida válida en Capitan Hook</p>',NULL,NULL,NULL,NULL,NULL,NULL,26,10,'es|26|10'),(562,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,26,19,'26|19'),(563,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,26,20,'26|20'),(564,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,26,21,'26|21'),(565,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,26,22,'26|22'),(566,NULL,NULL,'RAM-SERV-PAR-001',NULL,NULL,NULL,NULL,NULL,NULL,26,1,'26|1'),(567,'es',NULL,'Capitan Hook',NULL,NULL,NULL,NULL,NULL,NULL,26,2,'es|26|2'),(568,'es',NULL,'capitan-hook',NULL,NULL,NULL,NULL,NULL,NULL,26,3,'es|26|3'),(569,NULL,NULL,'23',NULL,NULL,NULL,NULL,NULL,NULL,26,27,'26|27'),(570,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,26,28,'default|26|28'),(571,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,26,16,'es|26|16'),(572,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,26,17,'es|26|17'),(573,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,26,18,'es|26|18'),(574,NULL,NULL,NULL,NULL,NULL,1343.0000,NULL,NULL,NULL,26,11,'26|11'),(575,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,26,12,'26|12'),(576,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,26,13,'26|13'),(577,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,26,14,'default|26|14'),(578,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,26,15,'default|26|15'),(579,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,27,5,'27|5'),(580,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,27,6,'27|6'),(581,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,27,7,'27|7'),(582,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,27,8,'default|27|8'),(583,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,27,26,'27|26'),(584,'es',NULL,'<p>80USD - Beneficio o promoción sugerida válida en Garrafón Park</p>',NULL,NULL,NULL,NULL,NULL,NULL,27,9,'es|27|9'),(585,'es',NULL,'<p>80USD - Beneficio o promoción sugerida válida en Garrafón Park</p>',NULL,NULL,NULL,NULL,NULL,NULL,27,10,'es|27|10'),(586,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,27,19,'27|19'),(587,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,27,20,'27|20'),(588,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,27,21,'27|21'),(589,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,27,22,'27|22'),(590,NULL,NULL,'RAM-SERV-PAR-002',NULL,NULL,NULL,NULL,NULL,NULL,27,1,'27|1'),(591,'es',NULL,'Garrafón Park',NULL,NULL,NULL,NULL,NULL,NULL,27,2,'es|27|2'),(592,'es',NULL,'garrafon-park',NULL,NULL,NULL,NULL,NULL,NULL,27,3,'es|27|3'),(593,NULL,NULL,'24',NULL,NULL,NULL,NULL,NULL,NULL,27,27,'27|27'),(594,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,27,28,'default|27|28'),(595,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,27,16,'es|27|16'),(596,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,27,17,'es|27|17'),(597,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,27,18,'es|27|18'),(598,NULL,NULL,NULL,NULL,NULL,1432.0000,NULL,NULL,NULL,27,11,'27|11'),(599,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,27,12,'27|12'),(600,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,27,13,'27|13'),(601,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,27,14,'default|27|14'),(602,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,27,15,'default|27|15'),(603,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,28,5,'28|5'),(604,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,28,6,'28|6'),(605,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,28,7,'28|7'),(606,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,28,8,'default|28|8'),(607,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,28,26,'28|26'),(608,'es',NULL,'<p>120 USD - Beneficio o promoción sugerida válida en Whale Shark México </p>',NULL,NULL,NULL,NULL,NULL,NULL,28,9,'es|28|9'),(609,'es',NULL,'<p>120 USD - Beneficio o promoción sugerida válida en Whale Shark México </p>',NULL,NULL,NULL,NULL,NULL,NULL,28,10,'es|28|10'),(610,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,28,19,'28|19'),(611,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,28,20,'28|20'),(612,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,28,21,'28|21'),(613,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,28,22,'28|22'),(614,NULL,NULL,'RAM-SERV-PAR-003',NULL,NULL,NULL,NULL,NULL,NULL,28,1,'28|1'),(615,'es',NULL,'Whale Shark México',NULL,NULL,NULL,NULL,NULL,NULL,28,2,'es|28|2'),(616,'es',NULL,'whale-shark-mexico',NULL,NULL,NULL,NULL,NULL,NULL,28,3,'es|28|3'),(617,NULL,NULL,'25',NULL,NULL,NULL,NULL,NULL,NULL,28,27,'28|27'),(618,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,28,28,'default|28|28'),(619,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,28,16,'es|28|16'),(620,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,28,17,'es|28|17'),(621,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,28,18,'es|28|18'),(622,NULL,NULL,NULL,NULL,NULL,2149.0000,NULL,NULL,NULL,28,11,'28|11'),(623,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,28,12,'28|12'),(624,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,28,13,'28|13'),(625,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,28,14,'default|28|14'),(626,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,28,15,'default|28|15'),(627,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,29,5,'29|5'),(628,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,29,6,'29|6'),(629,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,29,7,'29|7'),(630,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,29,8,'default|29|8'),(631,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,29,26,'29|26'),(632,'es',NULL,'<p>20 USD - Beneficio o promoción sugerida válida en Aquarium Cancún</p>\n<p> </p>',NULL,NULL,NULL,NULL,NULL,NULL,29,9,'es|29|9'),(633,'es',NULL,'<p>20 USD - Beneficio o promoción sugerida válida en Aquarium Cancún</p>',NULL,NULL,NULL,NULL,NULL,NULL,29,10,'es|29|10'),(634,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,29,19,'29|19'),(635,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,29,20,'29|20'),(636,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,29,21,'29|21'),(637,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,29,22,'29|22'),(638,NULL,NULL,'RAM-SERV-PAR-004',NULL,NULL,NULL,NULL,NULL,NULL,29,1,'29|1'),(639,'es',NULL,'Aquarium Cancún',NULL,NULL,NULL,NULL,NULL,NULL,29,2,'es|29|2'),(640,'es',NULL,'aquarium-cancun',NULL,NULL,NULL,NULL,NULL,NULL,29,3,'es|29|3'),(641,NULL,NULL,'26',NULL,NULL,NULL,NULL,NULL,NULL,29,27,'29|27'),(642,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,29,28,'default|29|28'),(643,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,29,16,'es|29|16'),(644,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,29,17,'es|29|17'),(645,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,29,18,'es|29|18'),(646,NULL,NULL,NULL,NULL,NULL,359.0000,NULL,NULL,NULL,29,11,'29|11'),(647,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,29,12,'29|12'),(648,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,29,13,'29|13'),(649,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,29,14,'default|29|14'),(650,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,29,15,'default|29|15'),(651,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,30,5,'30|5'),(652,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,30,6,'30|6'),(653,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,30,7,'30|7'),(654,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,30,8,'default|30|8'),(655,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,30,26,'30|26'),(656,'es',NULL,'<p>25 USD - Beneficio o promoción sugerida válida en Croco Cun Park</p>',NULL,NULL,NULL,NULL,NULL,NULL,30,9,'es|30|9'),(657,'es',NULL,'<p>25 USD - Beneficio o promoción sugerida válida en Croco Cun Park</p>',NULL,NULL,NULL,NULL,NULL,NULL,30,10,'es|30|10'),(658,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,30,19,'30|19'),(659,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,30,20,'30|20'),(660,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,30,21,'30|21'),(661,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,30,22,'30|22'),(662,NULL,NULL,'RAM-SERV-PAR-005',NULL,NULL,NULL,NULL,NULL,NULL,30,1,'30|1'),(663,'es',NULL,'Croco Cun Park',NULL,NULL,NULL,NULL,NULL,NULL,30,2,'es|30|2'),(664,'es',NULL,'croco-cun-park',NULL,NULL,NULL,NULL,NULL,NULL,30,3,'es|30|3'),(665,NULL,NULL,'27',NULL,NULL,NULL,NULL,NULL,NULL,30,27,'30|27'),(666,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,30,28,'default|30|28'),(667,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,30,16,'es|30|16'),(668,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,30,17,'es|30|17'),(669,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,30,18,'es|30|18'),(670,NULL,NULL,NULL,NULL,NULL,447.0000,NULL,NULL,NULL,30,11,'30|11'),(671,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,30,12,'30|12'),(672,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,30,13,'30|13'),(673,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,30,14,'default|30|14'),(674,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,30,15,'default|30|15'),(675,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,31,5,'31|5'),(676,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,31,6,'31|6'),(677,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,31,7,'31|7'),(678,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,31,8,'default|31|8'),(679,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,31,26,'31|26'),(680,'es',NULL,'<p>45 USD - Beneficio o promoción sugerida válida en Urban Art </p>',NULL,NULL,NULL,NULL,NULL,NULL,31,9,'es|31|9'),(681,'es',NULL,'<p>45 USD - Beneficio o promoción sugerida válida en Urban Art </p>',NULL,NULL,NULL,NULL,NULL,NULL,31,10,'es|31|10'),(682,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,31,19,'31|19'),(683,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,31,20,'31|20'),(684,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,31,21,'31|21'),(685,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,31,22,'31|22'),(686,NULL,NULL,'RAM-SERV-PAR-006',NULL,NULL,NULL,NULL,NULL,NULL,31,1,'31|1'),(687,'es',NULL,'Urban Art',NULL,NULL,NULL,NULL,NULL,NULL,31,2,'es|31|2'),(688,'es',NULL,'urban-art',NULL,NULL,NULL,NULL,NULL,NULL,31,3,'es|31|3'),(689,NULL,NULL,'28',NULL,NULL,NULL,NULL,NULL,NULL,31,27,'31|27'),(690,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,31,28,'default|31|28'),(691,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,31,16,'es|31|16'),(692,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,31,17,'es|31|17'),(693,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,31,18,'es|31|18'),(694,NULL,NULL,NULL,NULL,NULL,805.0000,NULL,NULL,NULL,31,11,'31|11'),(695,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,31,12,'31|12'),(696,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,31,13,'31|13'),(697,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,31,14,'default|31|14'),(698,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,31,15,'default|31|15'),(699,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,32,5,'32|5'),(700,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,32,6,'32|6'),(701,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,32,7,'32|7'),(702,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,32,8,'default|32|8'),(703,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,32,26,'32|26'),(704,'es',NULL,'<p>35 USD - Beneficio o promoción sugerida válida en Grand Prix Go Kart </p>',NULL,NULL,NULL,NULL,NULL,NULL,32,9,'es|32|9'),(705,'es',NULL,'<p>35 USD - Beneficio o promoción sugerida válida en Grand Prix Go Kart </p>',NULL,NULL,NULL,NULL,NULL,NULL,32,10,'es|32|10'),(706,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,32,19,'32|19'),(707,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,32,20,'32|20'),(708,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,32,21,'32|21'),(709,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,32,22,'32|22'),(710,NULL,NULL,'RAM-SERV-PAR-007',NULL,NULL,NULL,NULL,NULL,NULL,32,1,'32|1'),(711,'es',NULL,'Grand Prix Go Kart',NULL,NULL,NULL,NULL,NULL,NULL,32,2,'es|32|2'),(712,'es',NULL,'grand-prix-go-kart',NULL,NULL,NULL,NULL,NULL,NULL,32,3,'es|32|3'),(713,NULL,NULL,'29',NULL,NULL,NULL,NULL,NULL,NULL,32,27,'32|27'),(714,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,32,28,'default|32|28'),(715,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,32,16,'es|32|16'),(716,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,32,17,'es|32|17'),(717,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,32,18,'es|32|18'),(718,NULL,NULL,NULL,NULL,NULL,626.0000,NULL,NULL,NULL,32,11,'32|11'),(719,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,32,12,'32|12'),(720,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,32,13,'32|13'),(721,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,32,14,'default|32|14'),(722,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,32,15,'default|32|15'),(723,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,33,5,'33|5'),(724,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,33,6,'33|6'),(725,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,33,7,'33|7'),(726,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,33,8,'default|33|8'),(727,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,33,26,'33|26'),(728,'es',NULL,'<p>110 USD - Beneficio o promoción sugerida válida en parques del Grupo Xcaret </p>',NULL,NULL,NULL,NULL,NULL,NULL,33,9,'es|33|9'),(729,'es',NULL,'<p>110 USD - Beneficio o promoción sugerida válida en parques del Grupo Xcaret </p>',NULL,NULL,NULL,NULL,NULL,NULL,33,10,'es|33|10'),(730,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,33,19,'33|19'),(731,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,33,20,'33|20'),(732,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,33,21,'33|21'),(733,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,33,22,'33|22'),(734,NULL,NULL,'RAM-SERV-PAR-008',NULL,NULL,NULL,NULL,NULL,NULL,33,1,'33|1'),(735,'es',NULL,'Grupo Xcaret',NULL,NULL,NULL,NULL,NULL,NULL,33,2,'es|33|2'),(736,'es',NULL,'grupo-xcaret',NULL,NULL,NULL,NULL,NULL,NULL,33,3,'es|33|3'),(737,NULL,NULL,'30',NULL,NULL,NULL,NULL,NULL,NULL,33,27,'33|27'),(738,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,33,28,'default|33|28'),(739,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,33,16,'es|33|16'),(740,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,33,17,'es|33|17'),(741,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,33,18,'es|33|18'),(742,NULL,NULL,NULL,NULL,NULL,1970.0000,NULL,NULL,NULL,33,11,'33|11'),(743,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,33,12,'33|12'),(744,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,33,13,'33|13'),(745,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,33,14,'default|33|14'),(746,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,33,15,'default|33|15'),(747,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,34,5,'34|5'),(748,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,34,6,'34|6'),(749,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,34,7,'34|7'),(750,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,34,8,'default|34|8'),(751,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,34,26,'34|26'),(752,'es',NULL,'<p>75 USD - Beneficio o promoción sugerida en antros de la cadena Antromex. </p>',NULL,NULL,NULL,NULL,NULL,NULL,34,9,'es|34|9'),(753,'es',NULL,'<p>75 USD - Beneficio o promoción sugerida en antros de la cadena Antromex. </p>',NULL,NULL,NULL,NULL,NULL,NULL,34,10,'es|34|10'),(754,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,34,19,'34|19'),(755,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,34,20,'34|20'),(756,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,34,21,'34|21'),(757,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,34,22,'34|22'),(758,NULL,NULL,'RAM-SERV-DISC-001',NULL,NULL,NULL,NULL,NULL,NULL,34,1,'34|1'),(759,'es',NULL,'Grupo Antromex',NULL,NULL,NULL,NULL,NULL,NULL,34,2,'es|34|2'),(760,'es',NULL,'grupo-antromex',NULL,NULL,NULL,NULL,NULL,NULL,34,3,'es|34|3'),(761,NULL,NULL,'31',NULL,NULL,NULL,NULL,NULL,NULL,34,27,'34|27'),(762,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,34,28,'default|34|28'),(763,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,34,16,'es|34|16'),(764,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,34,17,'es|34|17'),(765,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,34,18,'es|34|18'),(766,NULL,NULL,NULL,NULL,NULL,1343.0000,NULL,NULL,NULL,34,11,'34|11'),(767,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,34,12,'34|12'),(768,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,34,13,'34|13'),(769,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,34,14,'default|34|14'),(770,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,34,15,'default|34|15'),(771,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,35,5,'35|5'),(772,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,35,6,'35|6'),(773,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,35,7,'35|7'),(774,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,35,8,'default|35|8'),(775,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,35,26,'35|26'),(776,'es',NULL,'<p>75 USD - Beneficio o promoción sugerida en antros de la cadena Coco Bongo. </p>',NULL,NULL,NULL,NULL,NULL,NULL,35,9,'es|35|9'),(777,'es',NULL,'<p>75 USD - Beneficio o promoción sugerida en antros de la cadena Coco Bongo. </p>',NULL,NULL,NULL,NULL,NULL,NULL,35,10,'es|35|10'),(778,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,35,19,'35|19'),(779,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,35,20,'35|20'),(780,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,35,21,'35|21'),(781,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,35,22,'35|22'),(782,NULL,NULL,'RAM-SERV-DISC-002',NULL,NULL,NULL,NULL,NULL,NULL,35,1,'35|1'),(783,'es',NULL,'Coco Bongo',NULL,NULL,NULL,NULL,NULL,NULL,35,2,'es|35|2'),(784,'es',NULL,'coco-bongo',NULL,NULL,NULL,NULL,NULL,NULL,35,3,'es|35|3'),(785,NULL,NULL,'32',NULL,NULL,NULL,NULL,NULL,NULL,35,27,'35|27'),(786,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,35,28,'default|35|28'),(787,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,35,16,'es|35|16'),(788,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,35,17,'es|35|17'),(789,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,35,18,'es|35|18'),(790,NULL,NULL,NULL,NULL,NULL,1343.0000,NULL,NULL,NULL,35,11,'35|11'),(791,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,35,12,'35|12'),(792,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,35,13,'35|13'),(793,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,35,14,'default|35|14'),(794,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,35,15,'default|35|15'),(795,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,36,5,'36|5'),(796,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,36,6,'36|6'),(797,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,36,7,'36|7'),(798,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,36,8,'default|36|8'),(799,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,36,26,'36|26'),(800,'es',NULL,'<p>20 USD - Beneficio o promoción sugerida en eventos San Mike. </p>',NULL,NULL,NULL,NULL,NULL,NULL,36,9,'es|36|9'),(801,'es',NULL,'<p>20 USD - Beneficio o promoción sugerida en eventos San Mike. </p>',NULL,NULL,NULL,NULL,NULL,NULL,36,10,'es|36|10'),(802,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,36,19,'36|19'),(803,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,36,20,'36|20'),(804,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,36,21,'36|21'),(805,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,36,22,'36|22'),(806,NULL,NULL,'RAM-SERV-DISC-003',NULL,NULL,NULL,NULL,NULL,NULL,36,1,'36|1'),(807,'es',NULL,'San Mike',NULL,NULL,NULL,NULL,NULL,NULL,36,2,'es|36|2'),(808,'es',NULL,'san-mike',NULL,NULL,NULL,NULL,NULL,NULL,36,3,'es|36|3'),(809,NULL,NULL,'33',NULL,NULL,NULL,NULL,NULL,NULL,36,27,'36|27'),(810,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,36,28,'default|36|28'),(811,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,36,16,'es|36|16'),(812,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,36,17,'es|36|17'),(813,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,36,18,'es|36|18'),(814,NULL,NULL,NULL,NULL,NULL,358.0000,NULL,NULL,NULL,36,11,'36|11'),(815,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,36,12,'36|12'),(816,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,36,13,'36|13'),(817,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,36,14,'default|36|14'),(818,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,36,15,'default|36|15'),(819,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,37,5,'37|5'),(820,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,37,6,'37|6'),(821,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,37,7,'37|7'),(822,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,37,8,'default|37|8'),(823,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,37,26,'37|26'),(824,'es',NULL,'<p>9% - Promoción sugerida para la inscripción. </p>',NULL,NULL,NULL,NULL,NULL,NULL,37,9,'es|37|9'),(825,'es',NULL,'<p>9% - Promoción sugerida para la inscripción. </p>',NULL,NULL,NULL,NULL,NULL,NULL,37,10,'es|37|10'),(826,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,37,19,'37|19'),(827,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,37,20,'37|20'),(828,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,37,21,'37|21'),(829,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,37,22,'37|22'),(830,NULL,NULL,'RAM-SERV-DEP-001',NULL,NULL,NULL,NULL,NULL,NULL,37,1,'37|1'),(831,'es',NULL,'Híptica salazar',NULL,NULL,NULL,NULL,NULL,NULL,37,2,'es|37|2'),(832,'es',NULL,'hiptica-salazar',NULL,NULL,NULL,NULL,NULL,NULL,37,3,'es|37|3'),(833,NULL,NULL,'34',NULL,NULL,NULL,NULL,NULL,NULL,37,27,'37|27'),(834,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,37,28,'default|37|28'),(835,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,37,16,'es|37|16'),(836,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,37,17,'es|37|17'),(837,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,37,18,'es|37|18'),(838,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,37,11,'37|11'),(839,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,37,12,'37|12'),(840,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,37,13,'37|13'),(841,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,37,14,'default|37|14'),(842,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,37,15,'default|37|15'),(843,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,38,5,'38|5'),(844,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,38,6,'38|6'),(845,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,38,7,'38|7'),(846,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,38,8,'default|38|8'),(847,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,38,26,'38|26'),(848,'es',NULL,'<p>9% - Promoción sugerida para la inscripción. </p>',NULL,NULL,NULL,NULL,NULL,NULL,38,9,'es|38|9'),(849,'es',NULL,'<p>9% - Promoción sugerida para la inscripción. </p>',NULL,NULL,NULL,NULL,NULL,NULL,38,10,'es|38|10'),(850,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,38,19,'38|19'),(851,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,38,20,'38|20'),(852,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,38,21,'38|21'),(853,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,38,22,'38|22'),(854,NULL,NULL,'RAM-SERV-DEP-002',NULL,NULL,NULL,NULL,NULL,NULL,38,1,'38|1'),(855,'es',NULL,'360 Deportes',NULL,NULL,NULL,NULL,NULL,NULL,38,2,'es|38|2'),(856,'es',NULL,'360-deportes',NULL,NULL,NULL,NULL,NULL,NULL,38,3,'es|38|3'),(857,NULL,NULL,'35',NULL,NULL,NULL,NULL,NULL,NULL,38,27,'38|27'),(858,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,38,28,'default|38|28'),(859,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,38,16,'es|38|16'),(860,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,38,17,'es|38|17'),(861,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,38,18,'es|38|18'),(862,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,38,11,'38|11'),(863,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,38,12,'38|12'),(864,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,38,13,'38|13'),(865,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,38,14,'default|38|14'),(866,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,38,15,'default|38|15'),(867,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,39,5,'39|5'),(868,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,39,6,'39|6'),(869,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,39,7,'39|7'),(870,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,39,8,'default|39|8'),(871,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,39,26,'39|26'),(872,'es',NULL,'<p>9% - Promoción sugerida para la inscripción. </p>',NULL,NULL,NULL,NULL,NULL,NULL,39,9,'es|39|9'),(873,'es',NULL,'<p>9% - Promoción sugerida para la inscripción. </p>',NULL,NULL,NULL,NULL,NULL,NULL,39,10,'es|39|10'),(874,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,39,19,'39|19'),(875,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,39,20,'39|20'),(876,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,39,21,'39|21'),(877,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,39,22,'39|22'),(878,NULL,NULL,'RAM-SERV-DEP-003',NULL,NULL,NULL,NULL,NULL,NULL,39,1,'39|1'),(879,'es',NULL,'Lefafcase Cancún',NULL,NULL,NULL,NULL,NULL,NULL,39,2,'es|39|2'),(880,'es',NULL,'lefafcase-cancun',NULL,NULL,NULL,NULL,NULL,NULL,39,3,'es|39|3'),(881,NULL,NULL,'99',NULL,NULL,NULL,NULL,NULL,NULL,39,27,'39|27'),(882,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,39,28,'default|39|28'),(883,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,39,16,'es|39|16'),(884,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,39,17,'es|39|17'),(885,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,39,18,'es|39|18'),(886,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,39,11,'39|11'),(887,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,39,12,'39|12'),(888,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,39,13,'39|13'),(889,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,39,14,'default|39|14'),(890,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,39,15,'default|39|15'),(891,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,40,5,'40|5'),(892,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,40,6,'40|6'),(893,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,40,7,'40|7'),(894,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,40,8,'default|40|8'),(895,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,40,26,'40|26'),(896,'es',NULL,'<p>9% - Confederación Autónoma deTrabajadores y Empleados de México (Social Network). Promoción sugerida para la inscripción. </p>',NULL,NULL,NULL,NULL,NULL,NULL,40,9,'es|40|9'),(897,'es',NULL,'<p>9% - Confederación Autónoma deTrabajadores y Empleados de México (Social Network). Promoción sugerida para la inscripción. </p>',NULL,NULL,NULL,NULL,NULL,NULL,40,10,'es|40|10'),(898,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,40,19,'40|19'),(899,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,40,20,'40|20'),(900,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,40,21,'40|21'),(901,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,40,22,'40|22'),(902,NULL,NULL,'RAM-SERV-EDU-001',NULL,NULL,NULL,NULL,NULL,NULL,40,1,'40|1'),(903,'es',NULL,'Catem',NULL,NULL,NULL,NULL,NULL,NULL,40,2,'es|40|2'),(904,'es',NULL,'catem',NULL,NULL,NULL,NULL,NULL,NULL,40,3,'es|40|3'),(905,NULL,NULL,'36',NULL,NULL,NULL,NULL,NULL,NULL,40,27,'40|27'),(906,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,40,28,'default|40|28'),(907,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,40,16,'es|40|16'),(908,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,40,17,'es|40|17'),(909,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,40,18,'es|40|18'),(910,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,40,11,'40|11'),(911,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,40,12,'40|12'),(912,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,40,13,'40|13'),(913,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,40,14,'default|40|14'),(914,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,40,15,'default|40|15'),(915,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,41,5,'41|5'),(916,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,41,6,'41|6'),(917,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,41,7,'41|7'),(918,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,41,8,'default|41|8'),(919,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,41,26,'41|26'),(920,'es',NULL,'<p>9% - Academia de coaches. Promoción sugerida para la inscripción. </p>',NULL,NULL,NULL,NULL,NULL,NULL,41,9,'es|41|9'),(921,'es',NULL,'<p>9% - Academia de coaches. Promoción sugerida para la inscripción. </p>',NULL,NULL,NULL,NULL,NULL,NULL,41,10,'es|41|10'),(922,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,41,19,'41|19'),(923,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,41,20,'41|20'),(924,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,41,21,'41|21'),(925,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,41,22,'41|22'),(926,NULL,NULL,'RAM-SERV-EDU-002',NULL,NULL,NULL,NULL,NULL,NULL,41,1,'41|1'),(927,'es',NULL,'La Academia del Coach',NULL,NULL,NULL,NULL,NULL,NULL,41,2,'es|41|2'),(928,'es',NULL,'la-academia-del-coach',NULL,NULL,NULL,NULL,NULL,NULL,41,3,'es|41|3'),(929,NULL,NULL,'37',NULL,NULL,NULL,NULL,NULL,NULL,41,27,'41|27'),(930,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,41,28,'default|41|28'),(931,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,41,16,'es|41|16'),(932,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,41,17,'es|41|17'),(933,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,41,18,'es|41|18'),(934,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,41,11,'41|11'),(935,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,41,12,'41|12'),(936,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,41,13,'41|13'),(937,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,41,14,'default|41|14'),(938,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,41,15,'default|41|15'),(939,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,42,5,'42|5'),(940,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,42,6,'42|6'),(941,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,42,7,'42|7'),(942,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,42,8,'default|42|8'),(943,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,42,26,'42|26'),(944,'es',NULL,'<p>10% - Promoción sugerida para su primera visita. </p>',NULL,NULL,NULL,NULL,NULL,NULL,42,9,'es|42|9'),(945,'es',NULL,'<p>10% - Promoción sugerida para su primera visita. </p>',NULL,NULL,NULL,NULL,NULL,NULL,42,10,'es|42|10'),(946,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,42,19,'42|19'),(947,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,42,20,'42|20'),(948,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,42,21,'42|21'),(949,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,42,22,'42|22'),(950,NULL,NULL,'RAM-SERV-MED-001',NULL,NULL,NULL,NULL,NULL,NULL,42,1,'42|1'),(951,'es',NULL,'Medical network',NULL,NULL,NULL,NULL,NULL,NULL,42,2,'es|42|2'),(952,'es',NULL,'medical-network',NULL,NULL,NULL,NULL,NULL,NULL,42,3,'es|42|3'),(953,NULL,NULL,'38',NULL,NULL,NULL,NULL,NULL,NULL,42,27,'42|27'),(954,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,42,28,'default|42|28'),(955,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,42,16,'es|42|16'),(956,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,42,17,'es|42|17'),(957,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,42,18,'es|42|18'),(958,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,42,11,'42|11'),(959,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,42,12,'42|12'),(960,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,42,13,'42|13'),(961,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,42,14,'default|42|14'),(962,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,42,15,'default|42|15'),(963,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,43,5,'43|5'),(964,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,43,6,'43|6'),(965,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,43,7,'43|7'),(966,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,43,8,'default|43|8'),(967,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,43,26,'43|26'),(968,'es',NULL,'<p>10% - Promoción sugerida para su primera visita. </p>',NULL,NULL,NULL,NULL,NULL,NULL,43,9,'es|43|9'),(969,'es',NULL,'<p>10% - Promoción sugerida para su primera visita. </p>',NULL,NULL,NULL,NULL,NULL,NULL,43,10,'es|43|10'),(970,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,43,19,'43|19'),(971,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,43,20,'43|20'),(972,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,43,21,'43|21'),(973,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,43,22,'43|22'),(974,NULL,NULL,'RAM-SERV-MED-002',NULL,NULL,NULL,NULL,NULL,NULL,43,1,'43|1'),(975,'es',NULL,'Cosmodent',NULL,NULL,NULL,NULL,NULL,NULL,43,2,'es|43|2'),(976,'es',NULL,'cosmodent',NULL,NULL,NULL,NULL,NULL,NULL,43,3,'es|43|3'),(977,NULL,NULL,'39',NULL,NULL,NULL,NULL,NULL,NULL,43,27,'43|27'),(978,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,43,28,'default|43|28'),(979,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,43,16,'es|43|16'),(980,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,43,17,'es|43|17'),(981,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,43,18,'es|43|18'),(982,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,43,11,'43|11'),(983,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,43,12,'43|12'),(984,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,43,13,'43|13'),(985,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,43,14,'default|43|14'),(986,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,43,15,'default|43|15'),(987,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,44,5,'44|5'),(988,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,44,6,'44|6'),(989,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,44,7,'44|7'),(990,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,44,8,'default|44|8'),(991,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,44,26,'44|26'),(992,'es',NULL,'<p>10% - Promoción sugerida para su primer servicio. </p>',NULL,NULL,NULL,NULL,NULL,NULL,44,9,'es|44|9'),(993,'es',NULL,'<p>10% - Promoción sugerida para su primer servicio. </p>',NULL,NULL,NULL,NULL,NULL,NULL,44,10,'es|44|10'),(994,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,44,19,'44|19'),(995,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,44,20,'44|20'),(996,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,44,21,'44|21'),(997,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,44,22,'44|22'),(998,NULL,NULL,'RAM-SERV-AUT-001',NULL,NULL,NULL,NULL,NULL,NULL,44,1,'44|1'),(999,'es',NULL,'Automotriz Báez',NULL,NULL,NULL,NULL,NULL,NULL,44,2,'es|44|2'),(1000,'es',NULL,'automotriz-baez',NULL,NULL,NULL,NULL,NULL,NULL,44,3,'es|44|3'),(1001,NULL,NULL,'40',NULL,NULL,NULL,NULL,NULL,NULL,44,27,'44|27'),(1002,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,44,28,'default|44|28'),(1003,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,44,16,'es|44|16'),(1004,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,44,17,'es|44|17'),(1005,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,44,18,'es|44|18'),(1006,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,44,11,'44|11'),(1007,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,44,12,'44|12'),(1008,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,44,13,'44|13'),(1009,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,44,14,'default|44|14'),(1010,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,44,15,'default|44|15'),(1011,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,45,5,'45|5'),(1012,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,45,6,'45|6'),(1013,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,45,7,'45|7'),(1014,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,45,8,'default|45|8'),(1015,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,45,26,'45|26'),(1016,'es',NULL,'<p>10% - Promoción sugerida para su primer concierto privado . </p>',NULL,NULL,NULL,NULL,NULL,NULL,45,9,'es|45|9'),(1017,'es',NULL,'<p>10% - Promoción sugerida para su primer concierto privado . </p>',NULL,NULL,NULL,NULL,NULL,NULL,45,10,'es|45|10'),(1018,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,45,19,'45|19'),(1019,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,45,20,'45|20'),(1020,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,45,21,'45|21'),(1021,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,45,22,'45|22'),(1022,NULL,NULL,'RAM-MUS-001',NULL,NULL,NULL,NULL,NULL,NULL,45,1,'45|1'),(1023,'es',NULL,'Mariachi Santana',NULL,NULL,NULL,NULL,NULL,NULL,45,2,'es|45|2'),(1024,'es',NULL,'mariachi-santana',NULL,NULL,NULL,NULL,NULL,NULL,45,3,'es|45|3'),(1025,NULL,NULL,'41',NULL,NULL,NULL,NULL,NULL,NULL,45,27,'45|27'),(1026,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,45,28,'default|45|28'),(1027,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,45,16,'es|45|16'),(1028,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,45,17,'es|45|17'),(1029,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,45,18,'es|45|18'),(1030,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,45,11,'45|11'),(1031,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,45,12,'45|12'),(1032,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,45,13,'45|13'),(1033,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,45,14,'default|45|14'),(1034,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,45,15,'default|45|15'),(1035,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,46,5,'46|5'),(1036,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,46,6,'46|6'),(1037,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,46,7,'46|7'),(1038,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,46,8,'default|46|8'),(1039,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,46,26,'46|26'),(1040,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas 7-Eleven.</p>',NULL,NULL,NULL,NULL,NULL,NULL,46,9,'es|46|9'),(1041,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas 7-Eleven.</p>',NULL,NULL,NULL,NULL,NULL,NULL,46,10,'es|46|10'),(1042,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,46,19,'46|19'),(1043,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,46,20,'46|20'),(1044,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,46,21,'46|21'),(1045,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,46,22,'46|22'),(1046,NULL,NULL,'RAM-COM-001',NULL,NULL,NULL,NULL,NULL,NULL,46,1,'46|1'),(1047,'es',NULL,'7ELEVEN',NULL,NULL,NULL,NULL,NULL,NULL,46,2,'es|46|2'),(1048,'es',NULL,'7eleven',NULL,NULL,NULL,NULL,NULL,NULL,46,3,'es|46|3'),(1049,NULL,NULL,'42',NULL,NULL,NULL,NULL,NULL,NULL,46,27,'46|27'),(1050,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,46,28,'default|46|28'),(1051,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,46,16,'es|46|16'),(1052,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,46,17,'es|46|17'),(1053,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,46,18,'es|46|18'),(1054,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,46,11,'46|11'),(1055,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,46,12,'46|12'),(1056,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,46,13,'46|13'),(1057,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,46,14,'default|46|14'),(1058,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,46,15,'default|46|15'),(1059,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,47,5,'47|5'),(1060,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,47,6,'47|6'),(1061,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,47,7,'47|7'),(1062,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,47,8,'default|47|8'),(1063,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,47,26,'47|26'),(1064,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas Oxxo.</p>',NULL,NULL,NULL,NULL,NULL,NULL,47,9,'es|47|9'),(1065,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas Oxxo.</p>',NULL,NULL,NULL,NULL,NULL,NULL,47,10,'es|47|10'),(1066,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,47,19,'47|19'),(1067,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,47,20,'47|20'),(1068,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,47,21,'47|21'),(1069,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,47,22,'47|22'),(1070,NULL,NULL,'RAM-COM-002',NULL,NULL,NULL,NULL,NULL,NULL,47,1,'47|1'),(1071,'es',NULL,'OXXO',NULL,NULL,NULL,NULL,NULL,NULL,47,2,'es|47|2'),(1072,'es',NULL,'oxxo',NULL,NULL,NULL,NULL,NULL,NULL,47,3,'es|47|3'),(1073,NULL,NULL,'43',NULL,NULL,NULL,NULL,NULL,NULL,47,27,'47|27'),(1074,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,47,28,'default|47|28'),(1075,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,47,16,'es|47|16'),(1076,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,47,17,'es|47|17'),(1077,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,47,18,'es|47|18'),(1078,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,47,11,'47|11'),(1079,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,47,12,'47|12'),(1080,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,47,13,'47|13'),(1081,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,47,14,'default|47|14'),(1082,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,47,15,'default|47|15'),(1083,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,48,5,'48|5'),(1084,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,48,6,'48|6'),(1085,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,48,7,'48|7'),(1086,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,48,8,'default|48|8'),(1087,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,48,26,'48|26'),(1088,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas GoMart.</p>',NULL,NULL,NULL,NULL,NULL,NULL,48,9,'es|48|9'),(1089,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas GoMart.</p>',NULL,NULL,NULL,NULL,NULL,NULL,48,10,'es|48|10'),(1090,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,48,19,'48|19'),(1091,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,48,20,'48|20'),(1092,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,48,21,'48|21'),(1093,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,48,22,'48|22'),(1094,NULL,NULL,'RAM-COM-003',NULL,NULL,NULL,NULL,NULL,NULL,48,1,'48|1'),(1095,'es',NULL,'GOMART',NULL,NULL,NULL,NULL,NULL,NULL,48,2,'es|48|2'),(1096,'es',NULL,'gomart',NULL,NULL,NULL,NULL,NULL,NULL,48,3,'es|48|3'),(1097,NULL,NULL,'44',NULL,NULL,NULL,NULL,NULL,NULL,48,27,'48|27'),(1098,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,48,28,'default|48|28'),(1099,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,48,16,'es|48|16'),(1100,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,48,17,'es|48|17'),(1101,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,48,18,'es|48|18'),(1102,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,48,11,'48|11'),(1103,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,48,12,'48|12'),(1104,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,48,13,'48|13'),(1105,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,48,14,'default|48|14'),(1106,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,48,15,'default|48|15'),(1107,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,49,5,'49|5'),(1108,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,49,6,'49|6'),(1109,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,49,7,'49|7'),(1110,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,49,8,'default|49|8'),(1111,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,49,26,'49|26'),(1112,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas Sanborns.</p>',NULL,NULL,NULL,NULL,NULL,NULL,49,9,'es|49|9'),(1113,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas Sanborns.</p>',NULL,NULL,NULL,NULL,NULL,NULL,49,10,'es|49|10'),(1114,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,49,19,'49|19'),(1115,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,49,20,'49|20'),(1116,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,49,21,'49|21'),(1117,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,49,22,'49|22'),(1118,NULL,NULL,'RAM-COM-004',NULL,NULL,NULL,NULL,NULL,NULL,49,1,'49|1'),(1119,'es',NULL,'Sanborns',NULL,NULL,NULL,NULL,NULL,NULL,49,2,'es|49|2'),(1120,'es',NULL,'sanborns',NULL,NULL,NULL,NULL,NULL,NULL,49,3,'es|49|3'),(1121,NULL,NULL,'45',NULL,NULL,NULL,NULL,NULL,NULL,49,27,'49|27'),(1122,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,49,28,'default|49|28'),(1123,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,49,16,'es|49|16'),(1124,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,49,17,'es|49|17'),(1125,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,49,18,'es|49|18'),(1126,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,49,11,'49|11'),(1127,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,49,12,'49|12'),(1128,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,49,13,'49|13'),(1129,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,49,14,'default|49|14'),(1130,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,49,15,'default|49|15'),(1131,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,50,5,'50|5'),(1132,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,50,6,'50|6'),(1133,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,50,7,'50|7'),(1134,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,50,8,'default|50|8'),(1135,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,50,26,'50|26'),(1136,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas Sears.</p>',NULL,NULL,NULL,NULL,NULL,NULL,50,9,'es|50|9'),(1137,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas Sears.</p>',NULL,NULL,NULL,NULL,NULL,NULL,50,10,'es|50|10'),(1138,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,50,19,'50|19'),(1139,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,50,20,'50|20'),(1140,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,50,21,'50|21'),(1141,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,50,22,'50|22'),(1142,NULL,NULL,'RAM-COM-005',NULL,NULL,NULL,NULL,NULL,NULL,50,1,'50|1'),(1143,'es',NULL,'Sears',NULL,NULL,NULL,NULL,NULL,NULL,50,2,'es|50|2'),(1144,'es',NULL,'sears',NULL,NULL,NULL,NULL,NULL,NULL,50,3,'es|50|3'),(1145,NULL,NULL,'46',NULL,NULL,NULL,NULL,NULL,NULL,50,27,'50|27'),(1146,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,50,28,'default|50|28'),(1147,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,50,16,'es|50|16'),(1148,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,50,17,'es|50|17'),(1149,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,50,18,'es|50|18'),(1150,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50,11,'50|11'),(1151,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50,12,'50|12'),(1152,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,50,13,'50|13'),(1153,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,50,14,'default|50|14'),(1154,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,50,15,'default|50|15'),(1155,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,51,5,'51|5'),(1156,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,51,6,'51|6'),(1157,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,51,7,'51|7'),(1158,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,51,8,'default|51|8'),(1159,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,51,26,'51|26'),(1160,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas Liverpool.</p>',NULL,NULL,NULL,NULL,NULL,NULL,51,9,'es|51|9'),(1161,'es',NULL,'<p>10% - Beneficio o promoción válida en tiendas Liverpool.</p>',NULL,NULL,NULL,NULL,NULL,NULL,51,10,'es|51|10'),(1162,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,51,19,'51|19'),(1163,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,51,20,'51|20'),(1164,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,51,21,'51|21'),(1165,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,51,22,'51|22'),(1166,NULL,NULL,'RAM-COM-006',NULL,NULL,NULL,NULL,NULL,NULL,51,1,'51|1'),(1167,'es',NULL,'Liverpool',NULL,NULL,NULL,NULL,NULL,NULL,51,2,'es|51|2'),(1168,'es',NULL,'liverpool',NULL,NULL,NULL,NULL,NULL,NULL,51,3,'es|51|3'),(1169,NULL,NULL,'47',NULL,NULL,NULL,NULL,NULL,NULL,51,27,'51|27'),(1170,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,51,28,'default|51|28'),(1171,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,51,16,'es|51|16'),(1172,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,51,17,'es|51|17'),(1173,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,51,18,'es|51|18'),(1174,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,51,11,'51|11'),(1175,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,51,12,'51|12'),(1176,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,51,13,'51|13'),(1177,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,51,14,'default|51|14'),(1178,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,51,15,'default|51|15'),(1179,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,52,5,'52|5'),(1180,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,52,6,'52|6'),(1181,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,52,7,'52|7'),(1182,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,52,8,'default|52|8'),(1183,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,52,26,'52|26'),(1184,'es',NULL,'<p>10% - Plan AT&amp;T prepago con datos móviles y llamadas ilimitadas en México.</p>',NULL,NULL,NULL,NULL,NULL,NULL,52,9,'es|52|9'),(1185,'es',NULL,'<p>10% - Plan AT&amp;T prepago con datos móviles y llamadas ilimitadas en México.</p>',NULL,NULL,NULL,NULL,NULL,NULL,52,10,'es|52|10'),(1186,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,52,19,'52|19'),(1187,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,52,20,'52|20'),(1188,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,52,21,'52|21'),(1189,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,52,22,'52|22'),(1190,NULL,NULL,'RAM-SERV-TEL-001',NULL,NULL,NULL,NULL,NULL,NULL,52,1,'52|1'),(1191,'es',NULL,'AT&T',NULL,NULL,NULL,NULL,NULL,NULL,52,2,'es|52|2'),(1192,'es',NULL,'att',NULL,NULL,NULL,NULL,NULL,NULL,52,3,'es|52|3'),(1193,NULL,NULL,'48',NULL,NULL,NULL,NULL,NULL,NULL,52,27,'52|27'),(1194,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,52,28,'default|52|28'),(1195,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,52,16,'es|52|16'),(1196,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,52,17,'es|52|17'),(1197,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,52,18,'es|52|18'),(1198,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,52,11,'52|11'),(1199,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,52,12,'52|12'),(1200,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,52,13,'52|13'),(1201,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,52,14,'default|52|14'),(1202,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,52,15,'default|52|15'),(1203,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,53,5,'53|5'),(1204,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,53,6,'53|6'),(1205,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,53,7,'53|7'),(1206,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,53,8,'default|53|8'),(1207,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,53,26,'53|26'),(1208,'es',NULL,'<p>10% - Servicio de internet residencial ofrecido por Telmex.</p>',NULL,NULL,NULL,NULL,NULL,NULL,53,9,'es|53|9'),(1209,'es',NULL,'<p>10% - Servicio de internet residencial ofrecido por Telmex.</p>',NULL,NULL,NULL,NULL,NULL,NULL,53,10,'es|53|10'),(1210,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,53,19,'53|19'),(1211,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,53,20,'53|20'),(1212,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,53,21,'53|21'),(1213,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,53,22,'53|22'),(1214,NULL,NULL,'RAM-SERV-TEL-002',NULL,NULL,NULL,NULL,NULL,NULL,53,1,'53|1'),(1215,'es',NULL,'TELMEX',NULL,NULL,NULL,NULL,NULL,NULL,53,2,'es|53|2'),(1216,'es',NULL,'telmex',NULL,NULL,NULL,NULL,NULL,NULL,53,3,'es|53|3'),(1217,NULL,NULL,'49',NULL,NULL,NULL,NULL,NULL,NULL,53,27,'53|27'),(1218,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,53,28,'default|53|28'),(1219,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,53,16,'es|53|16'),(1220,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,53,17,'es|53|17'),(1221,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,53,18,'es|53|18'),(1222,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,53,11,'53|11'),(1223,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,53,12,'53|12'),(1224,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,53,13,'53|13'),(1225,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,53,14,'default|53|14'),(1226,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,53,15,'default|53|15'),(1227,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,54,5,'54|5'),(1228,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,54,6,'54|6'),(1229,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,54,7,'54|7'),(1230,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,54,8,'default|54|8'),(1231,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,54,26,'54|26'),(1232,'es',NULL,'<p>10% - Servicio de internet residencial ofrecido por Telmex.</p>',NULL,NULL,NULL,NULL,NULL,NULL,54,9,'es|54|9'),(1233,'es',NULL,'<p>10% - Servicio de internet residencial ofrecido por Telmex.</p>',NULL,NULL,NULL,NULL,NULL,NULL,54,10,'es|54|10'),(1234,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,54,19,'54|19'),(1235,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,54,20,'54|20'),(1236,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,54,21,'54|21'),(1237,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,54,22,'54|22'),(1238,NULL,NULL,'RAM-SERV-TEL-003',NULL,NULL,NULL,NULL,NULL,NULL,54,1,'54|1'),(1239,'es',NULL,'TELCEL',NULL,NULL,NULL,NULL,NULL,NULL,54,2,'es|54|2'),(1240,'es',NULL,'telcel',NULL,NULL,NULL,NULL,NULL,NULL,54,3,'es|54|3'),(1241,NULL,NULL,'50',NULL,NULL,NULL,NULL,NULL,NULL,54,27,'54|27'),(1242,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,54,28,'default|54|28'),(1243,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,54,16,'es|54|16'),(1244,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,54,17,'es|54|17'),(1245,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,54,18,'es|54|18'),(1246,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,54,11,'54|11'),(1247,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,54,12,'54|12'),(1248,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,54,13,'54|13'),(1249,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,54,14,'default|54|14'),(1250,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,54,15,'default|54|15'),(1251,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,55,5,'55|5'),(1252,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,55,6,'55|6'),(1253,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,55,7,'55|7'),(1254,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,55,8,'default|55|8'),(1255,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,55,26,'55|26'),(1256,'es',NULL,'<p>10% - Teléfono inteligente compatible con red AT&amp;T para uso personal y profesional.</p>',NULL,NULL,NULL,NULL,NULL,NULL,55,9,'es|55|9'),(1257,'es',NULL,'<p>10% - Teléfono inteligente compatible con red AT&amp;T para uso personal y profesional.</p>',NULL,NULL,NULL,NULL,NULL,NULL,55,10,'es|55|10'),(1258,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,55,19,'55|19'),(1259,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,55,20,'55|20'),(1260,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,55,21,'55|21'),(1261,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,55,22,'55|22'),(1262,NULL,NULL,'RAM-PROD-TEL-001',NULL,NULL,NULL,NULL,NULL,NULL,55,1,'55|1'),(1263,'es',NULL,'AT&T',NULL,NULL,NULL,NULL,NULL,NULL,55,2,'es|55|2'),(1264,'es',NULL,'atta',NULL,NULL,NULL,NULL,NULL,NULL,55,3,'es|55|3'),(1265,NULL,NULL,'51',NULL,NULL,NULL,NULL,NULL,NULL,55,27,'55|27'),(1266,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,55,28,'default|55|28'),(1267,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,55,16,'es|55|16'),(1268,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,55,17,'es|55|17'),(1269,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,55,18,'es|55|18'),(1270,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,55,11,'55|11'),(1271,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,55,12,'55|12'),(1272,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,55,13,'55|13'),(1273,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,55,14,'default|55|14'),(1274,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,55,15,'default|55|15'),(1275,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,56,5,'56|5'),(1276,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,56,6,'56|6'),(1277,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,56,7,'56|7'),(1278,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,56,8,'default|56|8'),(1279,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,56,26,'56|26'),(1280,'es',NULL,'<p>10% - Teléfono inteligente compatible con red TELCEL para uso personal y profesional.</p>',NULL,NULL,NULL,NULL,NULL,NULL,56,9,'es|56|9'),(1281,'es',NULL,'<p>10% - Teléfono inteligente compatible con red TELCEL para uso personal y profesional.</p>',NULL,NULL,NULL,NULL,NULL,NULL,56,10,'es|56|10'),(1282,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,56,19,'56|19'),(1283,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,56,20,'56|20'),(1284,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,56,21,'56|21'),(1285,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,56,22,'56|22'),(1286,NULL,NULL,'RAM-PROD-TEL-002',NULL,NULL,NULL,NULL,NULL,NULL,56,1,'56|1'),(1287,'es',NULL,'Telcel',NULL,NULL,NULL,NULL,NULL,NULL,56,2,'es|56|2'),(1288,'es',NULL,'telcel1',NULL,NULL,NULL,NULL,NULL,NULL,56,3,'es|56|3'),(1289,NULL,NULL,'52',NULL,NULL,NULL,NULL,NULL,NULL,56,27,'56|27'),(1290,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,56,28,'default|56|28'),(1291,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,56,16,'es|56|16'),(1292,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,56,17,'es|56|17'),(1293,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,56,18,'es|56|18'),(1294,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,56,11,'56|11'),(1295,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,56,12,'56|12'),(1296,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,56,13,'56|13'),(1297,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,56,14,'default|56|14'),(1298,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,56,15,'default|56|15'),(1299,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,57,5,'57|5'),(1300,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,57,6,'57|6'),(1301,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,57,7,'57|7'),(1302,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,57,8,'default|57|8'),(1303,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,57,26,'57|26'),(1304,'es',NULL,'<p>10% - Teléfono inteligente compatible con red TELMEX para uso personal y profesional.</p>',NULL,NULL,NULL,NULL,NULL,NULL,57,9,'es|57|9'),(1305,'es',NULL,'<p>10% - Teléfono inteligente compatible con red TELMEX para uso personal y profesional.</p>',NULL,NULL,NULL,NULL,NULL,NULL,57,10,'es|57|10'),(1306,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,57,19,'57|19'),(1307,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,57,20,'57|20'),(1308,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,57,21,'57|21'),(1309,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,57,22,'57|22'),(1310,NULL,NULL,'RAM-PROD-TEL-003',NULL,NULL,NULL,NULL,NULL,NULL,57,1,'57|1'),(1311,'es',NULL,'TELMEX',NULL,NULL,NULL,NULL,NULL,NULL,57,2,'es|57|2'),(1312,'es',NULL,'telmex1',NULL,NULL,NULL,NULL,NULL,NULL,57,3,'es|57|3'),(1313,NULL,NULL,'53',NULL,NULL,NULL,NULL,NULL,NULL,57,27,'57|27'),(1314,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,57,28,'default|57|28'),(1315,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,57,16,'es|57|16'),(1316,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,57,17,'es|57|17'),(1317,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,57,18,'es|57|18'),(1318,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,57,11,'57|11'),(1319,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,57,12,'57|12'),(1320,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,57,13,'57|13'),(1321,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,57,14,'default|57|14'),(1322,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,57,15,'default|57|15'),(1323,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,58,5,'58|5'),(1324,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,58,6,'58|6'),(1325,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,58,7,'58|7'),(1326,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,58,8,'default|58|8'),(1327,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,58,26,'58|26'),(1328,'es',NULL,'<p>1 USD - Promoción sugerida para su primera compra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,58,9,'es|58|9'),(1329,'es',NULL,'<p>1 USD - Promoción sugerida para su primera compra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,58,10,'es|58|10'),(1330,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,58,19,'58|19'),(1331,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,58,20,'58|20'),(1332,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,58,21,'58|21'),(1333,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,58,22,'58|22'),(1334,NULL,NULL,'RAM-PROD-001',NULL,NULL,NULL,NULL,NULL,NULL,58,1,'58|1'),(1335,'es',NULL,'RAM-PROD-001',NULL,NULL,NULL,NULL,NULL,NULL,58,2,'es|58|2'),(1336,'es',NULL,'ram-prod-001',NULL,NULL,NULL,NULL,NULL,NULL,58,3,'es|58|3'),(1337,NULL,NULL,'54',NULL,NULL,NULL,NULL,NULL,NULL,58,27,'58|27'),(1338,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,58,28,'default|58|28'),(1339,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,58,16,'es|58|16'),(1340,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,58,17,'es|58|17'),(1341,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,58,18,'es|58|18'),(1342,NULL,NULL,NULL,NULL,NULL,18.0000,NULL,NULL,NULL,58,11,'58|11'),(1343,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,58,12,'58|12'),(1344,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,58,13,'58|13'),(1345,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,58,14,'default|58|14'),(1346,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,58,15,'default|58|15'),(1347,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,59,5,'59|5'),(1348,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,59,6,'59|6'),(1349,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,59,7,'59|7'),(1350,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,59,8,'default|59|8'),(1351,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,59,26,'59|26'),(1352,'es',NULL,'<p>1USD - Revista. Promoción sugerida para su primera compra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,59,9,'es|59|9'),(1353,'es',NULL,'<p>1USD - Revista. Promoción sugerida para su primera compra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,59,10,'es|59|10'),(1354,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,59,19,'59|19'),(1355,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,59,20,'59|20'),(1356,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,59,21,'59|21'),(1357,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,59,22,'59|22'),(1358,NULL,NULL,'RAM-PROD-002',NULL,NULL,NULL,NULL,NULL,NULL,59,1,'59|1'),(1359,'es',NULL,'Integra Magazine',NULL,NULL,NULL,NULL,NULL,NULL,59,2,'es|59|2'),(1360,'es',NULL,'integra-magazine',NULL,NULL,NULL,NULL,NULL,NULL,59,3,'es|59|3'),(1361,NULL,NULL,'55',NULL,NULL,NULL,NULL,NULL,NULL,59,27,'59|27'),(1362,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,59,28,'default|59|28'),(1363,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,59,16,'es|59|16'),(1364,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,59,17,'es|59|17'),(1365,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,59,18,'es|59|18'),(1366,NULL,NULL,NULL,NULL,NULL,18.0000,NULL,NULL,NULL,59,11,'59|11'),(1367,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,59,12,'59|12'),(1368,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,59,13,'59|13'),(1369,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,59,14,'default|59|14'),(1370,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,59,15,'default|59|15'),(1371,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,60,5,'60|5'),(1372,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,60,6,'60|6'),(1373,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,60,7,'60|7'),(1374,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,60,8,'default|60|8'),(1375,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,60,26,'60|26'),(1376,'es',NULL,'<p>9% - Promoción sugerida para su primera compra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,60,9,'es|60|9'),(1377,'es',NULL,'<p>9% - Promoción sugerida para su primera compra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,60,10,'es|60|10'),(1378,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,60,19,'60|19'),(1379,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,60,20,'60|20'),(1380,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,60,21,'60|21'),(1381,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,60,22,'60|22'),(1382,NULL,NULL,'RAM-PROD-003',NULL,NULL,NULL,NULL,NULL,NULL,60,1,'60|1'),(1383,'es',NULL,'Ros Block',NULL,NULL,NULL,NULL,NULL,NULL,60,2,'es|60|2'),(1384,'es',NULL,'ros-block',NULL,NULL,NULL,NULL,NULL,NULL,60,3,'es|60|3'),(1385,NULL,NULL,'56',NULL,NULL,NULL,NULL,NULL,NULL,60,27,'60|27'),(1386,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,60,28,'default|60|28'),(1387,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,60,16,'es|60|16'),(1388,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,60,17,'es|60|17'),(1389,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,60,18,'es|60|18'),(1390,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,60,11,'60|11'),(1391,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,60,12,'60|12'),(1392,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,60,13,'60|13'),(1393,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,60,14,'default|60|14'),(1394,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,60,15,'default|60|15'),(1395,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,61,5,'61|5'),(1396,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,61,6,'61|6'),(1397,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,61,7,'61|7'),(1398,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,61,8,'default|61|8'),(1399,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,61,26,'61|26'),(1400,'es',NULL,'<p>1USD - Agua Alcalina Premium. Promoción sugerida para su primera compra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,61,9,'es|61|9'),(1401,'es',NULL,'<p>1USD - Agua Alcalina Premium. Promoción sugerida para su primera compra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,61,10,'es|61|10'),(1402,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,61,19,'61|19'),(1403,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,61,20,'61|20'),(1404,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,61,21,'61|21'),(1405,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,61,22,'61|22'),(1406,NULL,NULL,'RAM-PROD-004',NULL,NULL,NULL,NULL,NULL,NULL,61,1,'61|1'),(1407,'es',NULL,'Ondinas',NULL,NULL,NULL,NULL,NULL,NULL,61,2,'es|61|2'),(1408,'es',NULL,'ondinas',NULL,NULL,NULL,NULL,NULL,NULL,61,3,'es|61|3'),(1409,NULL,NULL,'57',NULL,NULL,NULL,NULL,NULL,NULL,61,27,'61|27'),(1410,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,61,28,'default|61|28'),(1411,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,61,16,'es|61|16'),(1412,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,61,17,'es|61|17'),(1413,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,61,18,'es|61|18'),(1414,NULL,NULL,NULL,NULL,NULL,18.0000,NULL,NULL,NULL,61,11,'61|11'),(1415,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,61,12,'61|12'),(1416,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,61,13,'61|13'),(1417,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,61,14,'default|61|14'),(1418,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,61,15,'default|61|15'),(1419,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,62,5,'62|5'),(1420,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,62,6,'62|6'),(1421,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,62,7,'62|7'),(1422,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,62,8,'default|62|8'),(1423,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,62,26,'62|26'),(1424,'es',NULL,'<p>10% - Promoción sugerida para su primera compra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,62,9,'es|62|9'),(1425,'es',NULL,'<p>10% - Promoción sugerida para su primera compra. </p>',NULL,NULL,NULL,NULL,NULL,NULL,62,10,'es|62|10'),(1426,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,62,19,'62|19'),(1427,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,62,20,'62|20'),(1428,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,62,21,'62|21'),(1429,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,62,22,'62|22'),(1430,NULL,NULL,'RAM-ROP-001',NULL,NULL,NULL,NULL,NULL,NULL,62,1,'62|1'),(1431,'es',NULL,'Cuidado Con El Perro',NULL,NULL,NULL,NULL,NULL,NULL,62,2,'es|62|2'),(1432,'es',NULL,'cuidado-con-el-perro',NULL,NULL,NULL,NULL,NULL,NULL,62,3,'es|62|3'),(1433,NULL,NULL,'58',NULL,NULL,NULL,NULL,NULL,NULL,62,27,'62|27'),(1434,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,62,28,'default|62|28'),(1435,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,62,16,'es|62|16'),(1436,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,62,17,'es|62|17'),(1437,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,62,18,'es|62|18'),(1438,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,62,11,'62|11'),(1439,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,62,12,'62|12'),(1440,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,62,13,'62|13'),(1441,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,62,14,'default|62|14'),(1442,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,62,15,'default|62|15'),(1443,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,64,5,'64|5'),(1444,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,64,6,'64|6'),(1445,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,64,7,'64|7'),(1446,NULL,'default',NULL,1,NULL,NULL,NULL,NULL,NULL,64,8,'default|64|8'),(1447,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,64,26,'64|26'),(1448,'es',NULL,'<p>Descuento sugerido </p>',NULL,NULL,NULL,NULL,NULL,NULL,64,9,'es|64|9'),(1449,'es',NULL,'<p>Descuento sugerido </p>',NULL,NULL,NULL,NULL,NULL,NULL,64,10,'es|64|10'),(1450,NULL,NULL,'Test',NULL,NULL,NULL,NULL,NULL,NULL,64,1,'64|1'),(1451,'es',NULL,'Las Hijas de la Tostada1',NULL,NULL,NULL,NULL,NULL,NULL,64,2,'es|64|2'),(1452,'es',NULL,'las-hijas-de-la-tostada1',NULL,NULL,NULL,NULL,NULL,NULL,64,3,'es|64|3'),(1453,NULL,NULL,'98',NULL,NULL,NULL,NULL,NULL,NULL,64,27,'64|27'),(1454,NULL,'default',NULL,0,NULL,NULL,NULL,NULL,NULL,64,28,'default|64|28'),(1455,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,64,16,'es|64|16'),(1456,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,64,17,'es|64|17'),(1457,'es',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,64,18,'es|64|18'),(1458,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,64,11,'64|11'),(1459,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,64,12,'64|12'),(1460,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,64,13,'64|13'),(1461,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,64,14,'default|64|14'),(1462,NULL,'default',NULL,NULL,NULL,NULL,NULL,NULL,NULL,64,15,'default|64|15');
/*!40000 ALTER TABLE `product_attribute_values` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_bundle_option_products`
--

DROP TABLE IF EXISTS `product_bundle_option_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_bundle_option_products` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL,
  `product_bundle_option_id` int unsigned NOT NULL,
  `qty` int NOT NULL DEFAULT '0',
  `is_user_defined` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `bundle_option_products_product_id_bundle_option_id_unique` (`product_id`,`product_bundle_option_id`),
  KEY `pbop_option_id_idx` (`product_bundle_option_id`),
  CONSTRAINT `product_bundle_option_id_foreign` FOREIGN KEY (`product_bundle_option_id`) REFERENCES `product_bundle_options` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_bundle_option_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_bundle_option_products`
--

LOCK TABLES `product_bundle_option_products` WRITE;
/*!40000 ALTER TABLE `product_bundle_option_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_bundle_option_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_bundle_option_translations`
--

DROP TABLE IF EXISTS `product_bundle_option_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_bundle_option_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_bundle_option_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_bundle_option_translations_option_id_locale_unique` (`product_bundle_option_id`,`locale`),
  UNIQUE KEY `bundle_option_translations_locale_label_bundle_option_id_unique` (`locale`,`label`,`product_bundle_option_id`),
  CONSTRAINT `product_bundle_option_translations_option_id_foreign` FOREIGN KEY (`product_bundle_option_id`) REFERENCES `product_bundle_options` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_bundle_option_translations`
--

LOCK TABLES `product_bundle_option_translations` WRITE;
/*!40000 ALTER TABLE `product_bundle_option_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_bundle_option_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_bundle_options`
--

DROP TABLE IF EXISTS `product_bundle_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_bundle_options` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `product_bundle_options_product_id_foreign` (`product_id`),
  CONSTRAINT `product_bundle_options_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_bundle_options`
--

LOCK TABLES `product_bundle_options` WRITE;
/*!40000 ALTER TABLE `product_bundle_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_bundle_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_categories` (
  `product_id` int unsigned NOT NULL,
  `category_id` int unsigned NOT NULL,
  UNIQUE KEY `product_categories_product_id_category_id_unique` (`product_id`,`category_id`),
  KEY `product_categories_category_id_foreign` (`category_id`),
  CONSTRAINT `product_categories_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_categories_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_categories`
--

LOCK TABLES `product_categories` WRITE;
/*!40000 ALTER TABLE `product_categories` DISABLE KEYS */;
INSERT INTO `product_categories` VALUES (1,1);
/*!40000 ALTER TABLE `product_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_channels`
--

DROP TABLE IF EXISTS `product_channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_channels` (
  `product_id` int unsigned NOT NULL,
  `channel_id` int unsigned NOT NULL,
  UNIQUE KEY `product_channels_product_id_channel_id_unique` (`product_id`,`channel_id`),
  KEY `product_channels_channel_id_foreign` (`channel_id`),
  KEY `pc_product_id_channel_id_idx` (`product_id`,`channel_id`),
  CONSTRAINT `product_channels_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_channels_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_channels`
--

LOCK TABLES `product_channels` WRITE;
/*!40000 ALTER TABLE `product_channels` DISABLE KEYS */;
INSERT INTO `product_channels` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1),(42,1),(43,1),(44,1),(45,1),(46,1),(47,1),(48,1),(49,1),(50,1),(51,1),(52,1),(53,1),(54,1),(55,1),(56,1),(57,1),(58,1),(59,1),(60,1),(61,1),(62,1),(64,1);
/*!40000 ALTER TABLE `product_channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_cross_sells`
--

DROP TABLE IF EXISTS `product_cross_sells`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_cross_sells` (
  `parent_id` int unsigned NOT NULL,
  `child_id` int unsigned NOT NULL,
  UNIQUE KEY `product_cross_sells_parent_id_child_id_unique` (`parent_id`,`child_id`),
  KEY `product_cross_sells_child_id_foreign` (`child_id`),
  CONSTRAINT `product_cross_sells_child_id_foreign` FOREIGN KEY (`child_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_cross_sells_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_cross_sells`
--

LOCK TABLES `product_cross_sells` WRITE;
/*!40000 ALTER TABLE `product_cross_sells` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_cross_sells` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_customer_group_prices`
--

DROP TABLE IF EXISTS `product_customer_group_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_customer_group_prices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `qty` int NOT NULL DEFAULT '0',
  `value_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `product_id` int unsigned NOT NULL,
  `customer_group_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `unique_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_customer_group_prices_unique_id_unique` (`unique_id`),
  KEY `product_customer_group_prices_product_id_foreign` (`product_id`),
  KEY `product_customer_group_prices_customer_group_id_foreign` (`customer_group_id`),
  CONSTRAINT `product_customer_group_prices_customer_group_id_foreign` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_customer_group_prices_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_customer_group_prices`
--

LOCK TABLES `product_customer_group_prices` WRITE;
/*!40000 ALTER TABLE `product_customer_group_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_customer_group_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_customizable_option_prices`
--

DROP TABLE IF EXISTS `product_customizable_option_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_customizable_option_prices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `label` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `product_customizable_option_id` int unsigned NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pcop_product_customizable_option_id_foreign` (`product_customizable_option_id`),
  CONSTRAINT `pcop_product_customizable_option_id_foreign` FOREIGN KEY (`product_customizable_option_id`) REFERENCES `product_customizable_options` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_customizable_option_prices`
--

LOCK TABLES `product_customizable_option_prices` WRITE;
/*!40000 ALTER TABLE `product_customizable_option_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_customizable_option_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_customizable_option_translations`
--

DROP TABLE IF EXISTS `product_customizable_option_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_customizable_option_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` text COLLATE utf8mb4_unicode_ci,
  `product_customizable_option_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_customizable_option_id_locale_unique` (`product_customizable_option_id`,`locale`),
  CONSTRAINT `pcot_product_customizable_option_id_foreign` FOREIGN KEY (`product_customizable_option_id`) REFERENCES `product_customizable_options` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_customizable_option_translations`
--

LOCK TABLES `product_customizable_option_translations` WRITE;
/*!40000 ALTER TABLE `product_customizable_option_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_customizable_option_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_customizable_options`
--

DROP TABLE IF EXISTS `product_customizable_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_customizable_options` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT '1',
  `max_characters` text COLLATE utf8mb4_unicode_ci,
  `supported_file_extensions` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `product_customizable_options_product_id_foreign` (`product_id`),
  CONSTRAINT `product_customizable_options_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_customizable_options`
--

LOCK TABLES `product_customizable_options` WRITE;
/*!40000 ALTER TABLE `product_customizable_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_customizable_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_downloadable_link_translations`
--

DROP TABLE IF EXISTS `product_downloadable_link_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_downloadable_link_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_downloadable_link_id` int unsigned NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `link_translations_link_id_foreign` (`product_downloadable_link_id`),
  CONSTRAINT `link_translations_link_id_foreign` FOREIGN KEY (`product_downloadable_link_id`) REFERENCES `product_downloadable_links` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_downloadable_link_translations`
--

LOCK TABLES `product_downloadable_link_translations` WRITE;
/*!40000 ALTER TABLE `product_downloadable_link_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_downloadable_link_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_downloadable_links`
--

DROP TABLE IF EXISTS `product_downloadable_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_downloadable_links` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `sample_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sample_file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sample_file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sample_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `downloads` int NOT NULL DEFAULT '0',
  `sort_order` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_downloadable_links_product_id_foreign` (`product_id`),
  CONSTRAINT `product_downloadable_links_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_downloadable_links`
--

LOCK TABLES `product_downloadable_links` WRITE;
/*!40000 ALTER TABLE `product_downloadable_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_downloadable_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_downloadable_sample_translations`
--

DROP TABLE IF EXISTS `product_downloadable_sample_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_downloadable_sample_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_downloadable_sample_id` int unsigned NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `sample_translations_sample_id_foreign` (`product_downloadable_sample_id`),
  CONSTRAINT `sample_translations_sample_id_foreign` FOREIGN KEY (`product_downloadable_sample_id`) REFERENCES `product_downloadable_samples` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_downloadable_sample_translations`
--

LOCK TABLES `product_downloadable_sample_translations` WRITE;
/*!40000 ALTER TABLE `product_downloadable_sample_translations` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_downloadable_sample_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_downloadable_samples`
--

DROP TABLE IF EXISTS `product_downloadable_samples`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_downloadable_samples` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_downloadable_samples_product_id_foreign` (`product_id`),
  CONSTRAINT `product_downloadable_samples_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_downloadable_samples`
--

LOCK TABLES `product_downloadable_samples` WRITE;
/*!40000 ALTER TABLE `product_downloadable_samples` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_downloadable_samples` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_flat`
--

DROP TABLE IF EXISTS `product_flat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_flat` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `url_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new` tinyint(1) DEFAULT NULL,
  `featured` tinyint(1) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `meta_title` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(12,4) DEFAULT NULL,
  `special_price` decimal(12,4) DEFAULT NULL,
  `special_price_from` date DEFAULT NULL,
  `special_price_to` date DEFAULT NULL,
  `weight` decimal(12,4) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute_family_id` int unsigned DEFAULT NULL,
  `product_id` int unsigned NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `parent_id` int unsigned DEFAULT NULL,
  `visible_individually` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_flat_unique_index` (`product_id`,`channel`,`locale`),
  KEY `product_flat_attribute_family_id_foreign` (`attribute_family_id`),
  KEY `product_flat_parent_id_foreign` (`parent_id`),
  CONSTRAINT `product_flat_attribute_family_id_foreign` FOREIGN KEY (`attribute_family_id`) REFERENCES `attribute_families` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `product_flat_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `product_flat` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_flat_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_flat`
--

LOCK TABLES `product_flat` WRITE;
/*!40000 ALTER TABLE `product_flat` DISABLE KEYS */;
INSERT INTO `product_flat` VALUES (1,'001','simple','Test','Prueba','<p>Test</p>','<p>Test</p>','prueba',1,1,1,'','','',95.0000,90.0000,NULL,NULL,0.0000,'2025-12-11 21:26:09','es','default',1,1,'2025-12-13 02:41:41',NULL,1),(2,'RAM-FOOD-001','simple','1','Las Hijas de la Tostada','<p>Descuento sugerido 10%</p>','<p>Descuento sugerido 10%</p>','las-hijas-de-la-tostada',1,1,1,'','','',80.0000,NULL,NULL,NULL,0.0000,'2025-12-26 09:13:17','es','default',1,2,'2025-12-27 13:15:16',NULL,1),(3,'RAM-FOOD-002','simple','2','Puerto Madero','<p>Descuento sugerido 10%</p>','<p>Descuento sugerido 10%</p>','puerto-madero',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 10:17:31','es','default',1,3,'2025-12-27 13:17:14',NULL,1),(4,'RAM-FOOD-003','simple','3','La Buena Barra','<p>Descuento sugerido 10%</p>','<p>Descuento sugerido 10%</p>','la-buena-barra',1,1,1,'','','',100.0000,90.0000,NULL,NULL,0.0000,'2025-12-26 10:46:57','es','default',1,4,'2025-12-27 13:19:01',NULL,1),(5,'RAM-FOOD-004','simple','4','Brass','<p>Descuento sugerido 10%</p>','<p>Descuento sugerido 10%</p>','brass',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 11:15:39','es','default',1,5,'2025-12-27 13:19:43',NULL,1),(7,'RAM-FOOD-005','simple','5','Pescaditos','<p>Descuento sugerido 5%</p>','<p>Descuento sugerido 5%</p>','pescaditos',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 11:29:47','es','default',1,7,'2025-12-27 13:20:18',NULL,1),(8,'RAM-FOOD-006','simple','6','La Parrilla','<p>Descuento sugerido 7%</p>','<p>Descuento sugerido 7%</p>','la-parrilla',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 11:40:48','es','default',1,8,'2025-12-27 13:20:55',NULL,1),(9,'RAM-FOOD-007','simple','7','Pollo Feliz','<p>Descuento sugerido 7%</p>','<p>Descuento sugerido 7%</p>','pollo-feliz',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 11:54:12','es','default',1,9,'2025-12-27 15:47:02',NULL,1),(10,'RAM-FOOD-008','simple','8','Sensei Sushi Bar','<p>Descuento sugerido 10%</p>','<p>Descuento sugerido 10%</p>','sensei-sushi-bar',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 12:06:03','es','default',1,10,'2025-12-27 13:22:44',NULL,1),(11,'RAM-FOOD-011','simple','9','100%Natural','<p>Descuento sugerido 10%</p>','<p>Descuento sugerido 10%</p>','100natural',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 12:18:16','es','default',1,11,'2025-12-27 13:24:03',NULL,1),(12,'RAM-FOOD-012','simple','10','Grupo Rosa Negra','<p>10 % - Beneficio o promoción sugerida válida en restaurantes de la cadena Rosa Negra. </p>','<p>Beneficio o promoción sugerida válida en restaurantes de la cadena Rosa Negra. </p>','grupo-rosa-negra',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 12:22:47','es','default',1,12,'2025-12-27 13:25:08',NULL,1),(13,'RAM-FOOD-013','simple','11','Grupo Anderson','<p>10 % - Beneficio o promoción sugerida válida en restaurantes de la cadena Anderson´s. </p>','<p>Beneficio o promoción sugerida válida en restaurantes de la cadena Anderson´s. </p>','grupo-anderson',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 12:28:23','es','default',1,13,'2025-12-27 13:25:39',NULL,1),(14,'RAM-FOOD-014','simple','12','El pibito','<p>Descuento sugerido 5%</p>','<p>Descuento sugerido 5%</p>','el-pibito',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 12:39:08','es','default',1,14,'2025-12-27 13:26:10',NULL,1),(16,'RAM-FOOD-015','simple','13','Pécano','<p>Descuento sugerido 10%</p>','<p>Descuento sugerido 10%</p>','pecano',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 16:55:44','es','default',1,16,'2025-12-27 13:26:44',NULL,1),(17,'RAM-FOOD-016','simple','14','El Chicharrón del Patrón','<p>Descuento sugerido 5%</p>','<p>Descuento sugerido 5%</p>','el-chicharron-del-patron',1,1,1,'','','',100.0000,90.0000,NULL,NULL,0.0000,'2025-12-26 17:03:54','es','default',1,17,'2025-12-26 17:19:48',NULL,1),(18,'RAM-PLAZA-001','simple','15','Las Plazas Outlet','<p>Centro Comercial </p>','<p>Centro Comercial </p>','las-plazas-outlet',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 17:09:25','es','default',1,18,'2025-12-27 13:28:40',NULL,1),(19,'RAM-PLAZA-002','simple','16','Plaza Las Américas','<p>Centro Comercial </p>','<p>Centro Comercial </p>','plaza-las-americas',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 17:15:48','es','default',1,19,'2025-12-27 15:42:55',NULL,1),(20,'RAM-PLAZA-003','simple','17','Plaza Malecón Las Americas','<p>Centro Comercial </p>','<p>Centro Comercial </p>','plaza-malecon-las-americas',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 17:21:54','es','default',1,20,'2025-12-27 13:30:28',NULL,1),(21,'RAM-PLAZA-004','simple','18','Plaza La Isla Cancún','<p>Centro Comercial </p>','<p>Centro Comercial </p>','plaza-la-isla-cancun',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 17:24:23','es','default',1,21,'2025-12-27 13:32:22',NULL,1),(22,'RAM-PLAZA-005','simple','19','Plaza Cancún Mall','<p>Centro Comercial</p>','<p>Centro Comercial</p>','plaza-cancun-mall',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-26 17:29:32','es','default',1,22,'2025-12-27 13:32:47',NULL,1),(23,'RAM-SERV-TUR-001','simple','20','Skyverse','<p>10% - Membresía de viaje creada por RAM para que disfrutes de precios de mayorista en hoteles, vuelos y actividades alrededor del mundo. (Promoción sugerida) </p>','<p>10% - Membresía de viaje creada por RAM para que disfrutes de precios de mayorista en hoteles, vuelos y actividades alrededor del mundo. (Promoción sugerida) </p>','skyverse',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-27 09:35:36','es','default',1,23,'2025-12-27 09:42:18',NULL,1),(24,'RAM-SERV-TUR-002','simple','21','Community Tours Sian Kaan','<p>60USD - Agencia de tours a Sian Kaan  (Promoción sugerida) </p>','<p>60USD - Agencia de tours a Sian Kaan  (Promoción sugerida) </p>','community-tours-sian-kaan',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-27 09:42:51','es','default',1,24,'2025-12-27 15:33:12',NULL,1),(25,'RAM-SERV-TUR-003','simple','22','Oceanix Náuticos','<p>15% - Empresa especializada en la venta y operación de catamaranes en el sector turístico. (Promoción sugerida) </p>','<p>15% - Empresa especializada en la venta y operación de catamaranes en el sector turístico. (Promoción sugerida) </p>','oceanix-nauticos',1,1,1,'','','',100.0000,NULL,NULL,NULL,0.0000,'2025-12-27 09:45:33','es','default',1,25,'2025-12-27 09:47:15',NULL,1),(26,'RAM-SERV-PAR-001','simple','23','Capitan Hook','<p>75USD - Beneficio o promoción sugerida válida en Capitan Hook</p>','<p>75USD - Beneficio o promoción sugerida válida en Capitan Hook</p>','capitan-hook',1,1,1,'','','',1343.0000,NULL,NULL,NULL,0.0000,'2025-12-27 09:48:55','es','default',1,26,'2025-12-27 15:49:34',NULL,1),(27,'RAM-SERV-PAR-002','simple','24','Garrafón Park','<p>80USD - Beneficio o promoción sugerida válida en Garrafón Park</p>','<p>80USD - Beneficio o promoción sugerida válida en Garrafón Park</p>','garrafon-park',1,1,1,'','','',1432.0000,NULL,NULL,NULL,0.0000,'2025-12-27 09:55:55','es','default',1,27,'2025-12-27 13:37:44',NULL,1),(28,'RAM-SERV-PAR-003','simple','25','Whale Shark México','<p>120 USD - Beneficio o promoción sugerida válida en Whale Shark México </p>','<p>120 USD - Beneficio o promoción sugerida válida en Whale Shark México </p>','whale-shark-mexico',1,1,1,'','','',2149.0000,NULL,NULL,NULL,0.0000,'2025-12-27 10:07:05','es','default',1,28,'2025-12-27 13:38:19',NULL,1),(29,'RAM-SERV-PAR-004','simple','26','Aquarium Cancún','<p>20 USD - Beneficio o promoción sugerida válida en Aquarium Cancún</p>\n<p> </p>','<p>20 USD - Beneficio o promoción sugerida válida en Aquarium Cancún</p>','aquarium-cancun',1,1,1,'','','',359.0000,NULL,NULL,NULL,0.0000,'2025-12-27 10:12:43','es','default',1,29,'2025-12-27 15:28:24',NULL,1),(30,'RAM-SERV-PAR-005','simple','27','Croco Cun Park','<p>25 USD - Beneficio o promoción sugerida válida en Croco Cun Park</p>','<p>25 USD - Beneficio o promoción sugerida válida en Croco Cun Park</p>','croco-cun-park',1,1,1,'','','',447.0000,NULL,NULL,NULL,0.0000,'2025-12-27 10:18:58','es','default',1,30,'2025-12-27 13:39:58',NULL,1),(31,'RAM-SERV-PAR-006','simple','28','Urban Art','<p>45 USD - Beneficio o promoción sugerida válida en Urban Art </p>','<p>45 USD - Beneficio o promoción sugerida válida en Urban Art </p>','urban-art',1,1,1,'','','',805.0000,NULL,NULL,NULL,0.0000,'2025-12-27 10:22:40','es','default',1,31,'2025-12-27 10:25:15',NULL,1),(32,'RAM-SERV-PAR-007','simple','29','Grand Prix Go Kart','<p>35 USD - Beneficio o promoción sugerida válida en Grand Prix Go Kart </p>','<p>35 USD - Beneficio o promoción sugerida válida en Grand Prix Go Kart </p>','grand-prix-go-kart',1,1,1,'','','',626.0000,NULL,NULL,NULL,0.0000,'2025-12-27 10:25:43','es','default',1,32,'2025-12-27 10:30:35',NULL,1),(33,'RAM-SERV-PAR-008','simple','30','Grupo Xcaret','<p>110 USD - Beneficio o promoción sugerida válida en parques del Grupo Xcaret </p>','<p>110 USD - Beneficio o promoción sugerida válida en parques del Grupo Xcaret </p>','grupo-xcaret',1,1,1,'','','',1970.0000,NULL,NULL,NULL,0.0000,'2025-12-27 10:32:35','es','default',1,33,'2025-12-27 13:43:43',NULL,1),(34,'RAM-SERV-DISC-001','simple','31','Grupo Antromex','<p>75 USD - Beneficio o promoción sugerida en antros de la cadena Antromex. </p>','<p>75 USD - Beneficio o promoción sugerida en antros de la cadena Antromex. </p>','grupo-antromex',1,1,1,'','','',1343.0000,NULL,NULL,NULL,0.0000,'2025-12-27 10:35:30','es','default',1,34,'2025-12-27 13:44:27',NULL,1),(35,'RAM-SERV-DISC-002','simple','32','Coco Bongo','<p>75 USD - Beneficio o promoción sugerida en antros de la cadena Coco Bongo. </p>','<p>75 USD - Beneficio o promoción sugerida en antros de la cadena Coco Bongo. </p>','coco-bongo',1,1,1,'','','',1343.0000,NULL,NULL,NULL,0.0000,'2025-12-27 10:38:29','es','default',1,35,'2025-12-27 10:40:54',NULL,1),(36,'RAM-SERV-DISC-003','simple','33','San Mike','<p>20 USD - Beneficio o promoción sugerida en eventos San Mike. </p>','<p>20 USD - Beneficio o promoción sugerida en eventos San Mike. </p>','san-mike',1,1,1,'','','',358.0000,NULL,NULL,NULL,0.0000,'2025-12-27 10:43:21','es','default',1,36,'2025-12-27 10:45:18',NULL,1),(37,'RAM-SERV-DEP-001','simple','34','Híptica salazar','<p>9% - Promoción sugerida para la inscripción. </p>','<p>9% - Promoción sugerida para la inscripción. </p>','hiptica-salazar',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 10:45:42','es','default',1,37,'2025-12-27 10:47:34',NULL,1),(38,'RAM-SERV-DEP-002','simple','35','360 Deportes','<p>9% - Promoción sugerida para la inscripción. </p>','<p>9% - Promoción sugerida para la inscripción. </p>','360-deportes',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 10:48:02','es','default',1,38,'2025-12-27 10:50:45',NULL,1),(39,'RAM-SERV-DEP-003','simple','99','Lefafcase Cancún','<p>9% - Promoción sugerida para la inscripción. </p>','<p>9% - Promoción sugerida para la inscripción. </p>','lefafcase-cancun',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 10:52:11','es','default',1,39,'2025-12-27 13:45:24',NULL,1),(40,'RAM-SERV-EDU-001','simple','36','Catem','<p>9% - Confederación Autónoma deTrabajadores y Empleados de México (Social Network). Promoción sugerida para la inscripción. </p>','<p>9% - Confederación Autónoma deTrabajadores y Empleados de México (Social Network). Promoción sugerida para la inscripción. </p>','catem',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 10:58:50','es','default',1,40,'2025-12-27 11:00:21',NULL,1),(41,'RAM-SERV-EDU-002','simple','37','La Academia del Coach','<p>9% - Academia de coaches. Promoción sugerida para la inscripción. </p>','<p>9% - Academia de coaches. Promoción sugerida para la inscripción. </p>','la-academia-del-coach',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:00:43','es','default',1,41,'2025-12-27 11:01:52',NULL,1),(42,'RAM-SERV-MED-001','simple','38','Medical network','<p>10% - Promoción sugerida para su primera visita. </p>','<p>10% - Promoción sugerida para su primera visita. </p>','medical-network',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:02:14','es','default',1,42,'2025-12-27 11:04:25',NULL,1),(43,'RAM-SERV-MED-002','simple','39','Cosmodent','<p>10% - Promoción sugerida para su primera visita. </p>','<p>10% - Promoción sugerida para su primera visita. </p>','cosmodent',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:04:45','es','default',1,43,'2025-12-27 11:06:20',NULL,1),(44,'RAM-SERV-AUT-001','simple','40','Automotriz Báez','<p>10% - Promoción sugerida para su primer servicio. </p>','<p>10% - Promoción sugerida para su primer servicio. </p>','automotriz-baez',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:06:46','es','default',1,44,'2025-12-27 15:38:23',NULL,1),(45,'RAM-MUS-001','simple','41','Mariachi Santana','<p>10% - Promoción sugerida para su primer concierto privado . </p>','<p>10% - Promoción sugerida para su primer concierto privado . </p>','mariachi-santana',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:08:27','es','default',1,45,'2025-12-27 11:09:38',NULL,1),(46,'RAM-COM-001','simple','42','7ELEVEN','<p>10% - Beneficio o promoción válida en tiendas 7-Eleven.</p>','<p>10% - Beneficio o promoción válida en tiendas 7-Eleven.</p>','7eleven',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:10:06','es','default',1,46,'2025-12-27 11:12:48',NULL,1),(47,'RAM-COM-002','simple','43','OXXO','<p>10% - Beneficio o promoción válida en tiendas Oxxo.</p>','<p>10% - Beneficio o promoción válida en tiendas Oxxo.</p>','oxxo',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:14:18','es','default',1,47,'2025-12-27 13:48:48',NULL,1),(48,'RAM-COM-003','simple','44','GOMART','<p>10% - Beneficio o promoción válida en tiendas GoMart.</p>','<p>10% - Beneficio o promoción válida en tiendas GoMart.</p>','gomart',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:16:23','es','default',1,48,'2025-12-27 15:40:40',NULL,1),(49,'RAM-COM-004','simple','45','Sanborns','<p>10% - Beneficio o promoción válida en tiendas Sanborns.</p>','<p>10% - Beneficio o promoción válida en tiendas Sanborns.</p>','sanborns',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:17:55','es','default',1,49,'2025-12-27 13:50:13',NULL,1),(50,'RAM-COM-005','simple','46','Sears','<p>10% - Beneficio o promoción válida en tiendas Sears.</p>','<p>10% - Beneficio o promoción válida en tiendas Sears.</p>','sears',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:20:07','es','default',1,50,'2025-12-27 15:48:02',NULL,1),(51,'RAM-COM-006','simple','47','Liverpool','<p>10% - Beneficio o promoción válida en tiendas Liverpool.</p>','<p>10% - Beneficio o promoción válida en tiendas Liverpool.</p>','liverpool',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:22:46','es','default',1,51,'2025-12-27 13:51:44',NULL,1),(52,'RAM-SERV-TEL-001','simple','48','AT&T','<p>10% - Plan AT&amp;T prepago con datos móviles y llamadas ilimitadas en México.</p>','<p>10% - Plan AT&amp;T prepago con datos móviles y llamadas ilimitadas en México.</p>','att',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:24:31','es','default',1,52,'2025-12-27 11:26:51',NULL,1),(53,'RAM-SERV-TEL-002','simple','49','TELMEX','<p>10% - Servicio de internet residencial ofrecido por Telmex.</p>','<p>10% - Servicio de internet residencial ofrecido por Telmex.</p>','telmex',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:27:25','es','default',1,53,'2025-12-27 11:28:27',NULL,1),(54,'RAM-SERV-TEL-003','simple','50','TELCEL','<p>10% - Servicio de internet residencial ofrecido por Telmex.</p>','<p>10% - Servicio de internet residencial ofrecido por Telmex.</p>','telcel',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:30:12','es','default',1,54,'2025-12-27 15:27:18',NULL,1),(55,'RAM-PROD-TEL-001','simple','51','AT&T','<p>10% - Teléfono inteligente compatible con red AT&amp;T para uso personal y profesional.</p>','<p>10% - Teléfono inteligente compatible con red AT&amp;T para uso personal y profesional.</p>','atta',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:32:36','es','default',1,55,'2025-12-27 11:33:54',NULL,1),(56,'RAM-PROD-TEL-002','simple','52','Telcel','<p>10% - Teléfono inteligente compatible con red TELCEL para uso personal y profesional.</p>','<p>10% - Teléfono inteligente compatible con red TELCEL para uso personal y profesional.</p>','telcel1',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:34:14','es','default',1,56,'2025-12-27 15:26:59',NULL,1),(57,'RAM-PROD-TEL-003','simple','53','TELMEX','<p>10% - Teléfono inteligente compatible con red TELMEX para uso personal y profesional.</p>','<p>10% - Teléfono inteligente compatible con red TELMEX para uso personal y profesional.</p>','telmex1',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:35:23','es','default',1,57,'2025-12-27 11:36:14',NULL,1),(58,'RAM-PROD-001','simple','54','RAM-PROD-001','<p>1 USD - Promoción sugerida para su primera compra. </p>','<p>1 USD - Promoción sugerida para su primera compra. </p>','ram-prod-001',1,1,1,'','','',18.0000,NULL,NULL,NULL,0.0000,'2025-12-27 11:36:53','es','default',1,58,'2025-12-27 11:38:48',NULL,1),(59,'RAM-PROD-002','simple','55','Integra Magazine','<p>1USD - Revista. Promoción sugerida para su primera compra. </p>','<p>1USD - Revista. Promoción sugerida para su primera compra. </p>','integra-magazine',1,1,1,'','','',18.0000,NULL,NULL,NULL,0.0000,'2025-12-27 11:39:13','es','default',1,59,'2025-12-27 13:53:28',NULL,1),(60,'RAM-PROD-003','simple','56','Ros Block','<p>9% - Promoción sugerida para su primera compra. </p>','<p>9% - Promoción sugerida para su primera compra. </p>','ros-block',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:44:08','es','default',1,60,'2025-12-27 11:45:52',NULL,1),(61,'RAM-PROD-004','simple','57','Ondinas','<p>1USD - Agua Alcalina Premium. Promoción sugerida para su primera compra. </p>','<p>1USD - Agua Alcalina Premium. Promoción sugerida para su primera compra. </p>','ondinas',1,1,1,'','','',18.0000,NULL,NULL,NULL,0.0000,'2025-12-27 11:46:06','es','default',1,61,'2025-12-27 11:49:33',NULL,1),(62,'RAM-ROP-001','simple','58','Cuidado Con El Perro','<p>10% - Promoción sugerida para su primera compra. </p>','<p>10% - Promoción sugerida para su primera compra. </p>','cuidado-con-el-perro',1,1,1,'','','',NULL,NULL,NULL,NULL,0.0000,'2025-12-27 11:49:51','es','default',1,62,'2025-12-27 13:54:08',NULL,1),(64,'Test','virtual','98','Las Hijas de la Tostada1','<p>Descuento sugerido </p>','<p>Descuento sugerido </p>','las-hijas-de-la-tostada1',1,1,1,'','','',NULL,NULL,NULL,NULL,NULL,'2025-12-27 16:25:26','es','default',1,64,'2025-12-27 16:29:04',NULL,1);
/*!40000 ALTER TABLE `product_flat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_grouped_products`
--

DROP TABLE IF EXISTS `product_grouped_products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_grouped_products` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL,
  `associated_product_id` int unsigned NOT NULL,
  `qty` int NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `grouped_products_product_id_associated_product_id_unique` (`product_id`,`associated_product_id`),
  KEY `product_grouped_products_associated_product_id_foreign` (`associated_product_id`),
  KEY `pgp_product_id_idx` (`product_id`),
  CONSTRAINT `product_grouped_products_associated_product_id_foreign` FOREIGN KEY (`associated_product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_grouped_products_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_grouped_products`
--

LOCK TABLES `product_grouped_products` WRITE;
/*!40000 ALTER TABLE `product_grouped_products` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_grouped_products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_images` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int unsigned NOT NULL,
  `position` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `prod_img_product_id_idx` (`product_id`),
  CONSTRAINT `product_images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_images`
--

LOCK TABLES `product_images` WRITE;
/*!40000 ALTER TABLE `product_images` DISABLE KEYS */;
INSERT INTO `product_images` VALUES (1,'images','product/1/ZV3oldwF4pLILgvRgMsASjGgzKevshdVBCX2kS4T.webp',1,1),(16,'images','product/17/BxZg63B6zZKyuozAktT1Bb1eFFF6X6N4jMRtWa4R.webp',17,1),(22,'images','product/23/AMzTLnpcXLJmc8IbT4zaIYW1ObIMD1c3Rl42wIXk.webp',23,1),(24,'images','product/25/hDQA9Resjt0C368iEuou0H9iHux4Lpu0hcHhc57d.webp',25,1),(30,'images','product/31/o59mWTAURiQxNMe1L2ahkcdSTN67JdIRNuUUBxDH.webp',31,1),(31,'images','product/32/6qGALvUlaMNE3op8y05N08IOOavMxBd5UMegRm2i.webp',32,1),(35,'images','product/35/7FBU4qLkzfc55qCqWY0HMuZZogaoJmIZp2pGQWd4.webp',35,1),(36,'images','product/36/VY7KZL039tHFRH4OpOJlRqnjX0oFJN4WJa13x1TY.webp',36,1),(37,'images','product/37/iYQYjjjTOSbbHIa9Z3KzPmAHvxzugpf72LAjOKBg.webp',37,1),(38,'images','product/38/BaUATULtaqdb6Nz91eXRfI3Xs9B6QxnBwtXjdK21.webp',38,1),(40,'images','product/40/8MKvQWm7qQILKS25PVZikUPJRMOIjdG7RVvy7ZLx.webp',40,1),(41,'images','product/41/WVOPHG3bLhtT7Z54qzj27NHuewE5PjOM53VZe0sx.webp',41,1),(42,'images','product/42/8rZAHhooV3Jlyxx5ZnILSKWum94dCmnKQRsh5sRN.webp',42,1),(43,'images','product/43/UyKFZf5XLDTZd1Nj00xI1gPVr0E1ujhZ3xEiedxl.webp',43,1),(45,'images','product/45/6nFhcAW2I4acpx2ewk3bQZ12fQadwKNedfKaVRHm.webp',45,1),(46,'images','product/46/zmOBEikMGnkfKPVD97Q1oPCvrUYbPf32KyESgP5r.webp',46,1),(52,'images','product/52/RBjU9TBacL400Gnryzw9UG2rq3mOuhuHQpb2ADUs.webp',52,1),(53,'images','product/53/mCvc4dxtEMp5rmBauGuMXjzPC6Rlw4uGkHghAxv0.webp',53,1),(55,'images','product/55/Zi1gl31dlr84ZTz6odKDYshvX5W2zrPBtdVM7hNU.webp',55,1),(57,'images','product/57/JNkWtSCKpJppJOd0lP1qIQeTWBxtyMh5XYg9ABGV.webp',57,1),(58,'images','product/58/TAplg81Q7MXIii30O6tJt3hGZoBWATu6nsI6nTmo.webp',58,1),(60,'images','product/60/eLlBgTjm6OEoPnmQsn5s02pCzrYZD7OvwrGbmFUC.webp',60,1),(61,'images','product/61/82b9b3CJolg2NOznMJtRAX7L8Z60aOauxCQb8yOY.webp',61,1),(63,'images','product/2/lLoBb0JGpwsfY6jWX4jUBC2lb5tXfaZs4HrM2S0X.webp',2,1),(64,'images','product/3/CvNCDHagsnv2zFJC5adPyPZ2xyxlEnKaCsf99cio.webp',3,1),(65,'images','product/4/hguAQ6NuIuPAIrAPvwkoUq3sXM2hiV4xUHRnvNWi.webp',4,1),(66,'images','product/5/0DCb42dWTha9AJFCqpmD3HDdip1XTkQoLnjLRwGj.webp',5,1),(67,'images','product/7/0ipSf9XRdkLMMVEtS84IZ9RgCB5zMhdPO8v4RRlB.webp',7,1),(68,'images','product/8/E9ufv5iWZYG6xJCKhGBtO64y2akRdpME0aSCFycY.webp',8,1),(70,'images','product/10/vLShrMLhkxOBIqnZbepiLtgSV7b4yexQNJ4tBb3z.webp',10,1),(71,'images','product/11/r5lzGK7z1zi5v6IJ4vaxq9B5fswhjlUbvRx0Iccq.webp',11,1),(72,'images','product/12/dDzE0LCRfukbUxr4UmWgBupsNPoXj9gg8v7WNee5.webp',12,1),(73,'images','product/13/LsL5i0GiPfguzpu9wLJBceZsRkE6zxAXDMnH9YFD.webp',13,1),(74,'images','product/14/QujuiZqpWHsPhbTPqzNftuXoHcmOYM4eyAKUgj2K.webp',14,1),(75,'images','product/16/FRQNnXpDkdL7ErCQFOUdEmP6dblsEA60gOLjs68q.webp',16,1),(76,'images','product/18/TWWT3X0Iz1dNWlBYs0SnA7hdf3LGgm3Dsr3nFbKA.webp',18,1),(78,'images','product/20/Zdjy5LxWI86IZDl1QhXoSntqLeWa0MeqFszKZ0Sn.webp',20,1),(79,'images','product/21/xLi05uSt8rtBcvmJfDLTpiOwwF2I3WgGa4VzvN05.webp',21,1),(80,'images','product/22/AogH6YHEesyOskXJfbKYq4dGK9yHye3nSN2zQ2hC.webp',22,1),(81,'images','product/27/A6zgQf7rDsVi1BqWo4as8XIcD5OIHZguGqWsBznF.webp',27,1),(82,'images','product/28/DZZUlkT3l6BZst86bMrLxWJzw41ZXeqwk1vjQc5B.webp',28,1),(84,'images','product/30/IYFyKRQ6OqFsjuquWkuEWQ0VNV8BNlTi0M4mB0S8.webp',30,1),(85,'images','product/33/xFhCZ9ZpTOlmcNew5RAMF7GErioCX97K6UYzzWn8.webp',33,1),(86,'images','product/34/AuZx3KMfULDRnzqNHaIvDjxz44L4hoN8Id7eHnvx.webp',34,1),(87,'images','product/39/H6sLIx5GjyAEsEyph6B71tcSG7azd1nNxulbDKyz.webp',39,1),(89,'images','product/47/tBw9M8NT4XCTxXOnQUzIQsOqwKi8Oa9yBoDizzOv.webp',47,1),(91,'images','product/49/im2ZtMyK83nDpzTYzqFFCBvaUFaxdE3xPNOFZqPi.webp',49,1),(93,'images','product/51/DOgbj1OFZU9W98zQMNnHpa17oqJNLQV43Qtc40CI.webp',51,1),(96,'images','product/59/nGQqHMbE6psq47Pf8YiaGJuDyaaJV0QrgHvypxBp.webp',59,1),(97,'images','product/62/mqjkMZzwnTkcdFNhaUEiS5T7GiIkJxaQAB4sxDZL.webp',62,1),(98,'images','product/56/Y339RV0MSTflzbrkA7GKQQVc9U7zrMsOwBdGIVtz.webp',56,1),(99,'images','product/54/8v70XE4ZvB6mvmiHg3BQpgIuzhrz2hgG1wxmEoc5.webp',54,1),(100,'images','product/29/RoeJN7ufUsud417XC03pISsFVQyTP2Be6knS833R.webp',29,1),(103,'images','product/24/Z4awtn2oT7d5FWHV1iHdmXZgrNRqC1jRoTW53103.webp',24,1),(106,'images','product/44/EZHoJu3tGUxcQAL0IGZ33OeS0LWsBeGG7hzPX8AL.webp',44,1),(107,'images','product/48/jZNeMcFqAtjilvcYFkIqd5JhAVk5ObmQNaLfQ7B1.webp',48,1),(108,'images','product/19/6Z1XpcsglycPkl8YqGfmUUEiQVKHLwZGsoobqnX5.webp',19,1),(110,'images','product/9/20pzsBTdnEVgPxq6Zv4Jj3kVvSqJ4ggbTKYVYdk3.webp',9,1),(111,'images','product/50/phFWtyUdTjSlgJhMwZLzhIeo2lOvRj9ckKllLu6c.webp',50,1),(113,'images','product/26/j2SahTWA6kCGX2W7ONwClo1yRdjTt3fsC8zkaCRY.webp',26,1);
/*!40000 ALTER TABLE `product_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_inventories`
--

DROP TABLE IF EXISTS `product_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_inventories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `qty` int NOT NULL DEFAULT '0',
  `product_id` int unsigned NOT NULL,
  `vendor_id` int NOT NULL DEFAULT '0',
  `inventory_source_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_source_vendor_index_unique` (`product_id`,`inventory_source_id`,`vendor_id`),
  KEY `product_inventories_inventory_source_id_foreign` (`inventory_source_id`),
  CONSTRAINT `product_inventories_inventory_source_id_foreign` FOREIGN KEY (`inventory_source_id`) REFERENCES `inventory_sources` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_inventories_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_inventories`
--

LOCK TABLES `product_inventories` WRITE;
/*!40000 ALTER TABLE `product_inventories` DISABLE KEYS */;
INSERT INTO `product_inventories` VALUES (1,10,1,0,1),(2,20,2,0,1),(3,20,3,0,1),(4,20,4,0,1),(5,20,5,0,1),(6,20,7,0,1),(7,20,8,0,1),(8,20,9,0,1),(9,20,10,0,1),(10,20,11,0,1),(11,20,12,0,1),(12,20,13,0,1),(13,20,14,0,1),(14,20,16,0,1),(15,20,17,0,1),(16,20,18,0,1),(17,20,19,0,1),(18,20,20,0,1),(19,20,21,0,1),(20,20,22,0,1),(21,20,23,0,1),(22,20,24,0,1),(23,20,25,0,1),(24,20,26,0,1),(25,20,27,0,1),(26,20,28,0,1),(27,20,29,0,1),(28,20,30,0,1),(29,20,31,0,1),(30,20,32,0,1),(31,20,33,0,1),(32,20,34,0,1),(33,20,35,0,1),(34,20,36,0,1),(35,20,37,0,1),(36,20,38,0,1),(37,20,39,0,1),(38,20,40,0,1),(39,20,41,0,1),(40,20,42,0,1),(41,20,43,0,1),(42,20,44,0,1),(43,20,45,0,1),(44,20,46,0,1),(45,20,47,0,1),(46,20,48,0,1),(47,20,49,0,1),(48,20,50,0,1),(49,20,51,0,1),(50,20,52,0,1),(51,20,53,0,1),(52,20,54,0,1),(53,20,55,0,1),(54,20,56,0,1),(55,20,57,0,1),(56,20,58,0,1),(57,20,59,0,1),(58,20,60,0,1),(59,20,61,0,1),(60,20,62,0,1),(61,0,64,0,1);
/*!40000 ALTER TABLE `product_inventories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_inventory_indices`
--

DROP TABLE IF EXISTS `product_inventory_indices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_inventory_indices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `qty` int NOT NULL DEFAULT '0',
  `product_id` int unsigned NOT NULL,
  `channel_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_inventory_indices_product_id_channel_id_unique` (`product_id`,`channel_id`),
  KEY `product_inventory_indices_channel_id_foreign` (`channel_id`),
  KEY `prod_inv_product_id_idx` (`product_id`),
  CONSTRAINT `product_inventory_indices_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_inventory_indices_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_inventory_indices`
--

LOCK TABLES `product_inventory_indices` WRITE;
/*!40000 ALTER TABLE `product_inventory_indices` DISABLE KEYS */;
INSERT INTO `product_inventory_indices` VALUES (1,10,1,1,NULL,'2025-12-11 21:28:46'),(2,20,2,1,NULL,'2025-12-26 09:39:27'),(3,20,3,1,NULL,'2025-12-26 10:41:00'),(4,20,4,1,NULL,NULL),(5,20,5,1,NULL,NULL),(6,20,7,1,NULL,NULL),(7,20,8,1,NULL,'2025-12-26 11:50:53'),(8,20,9,1,NULL,NULL),(9,20,10,1,NULL,NULL),(10,20,11,1,NULL,NULL),(11,20,12,1,NULL,NULL),(12,20,13,1,NULL,'2025-12-26 12:38:40'),(13,20,14,1,NULL,NULL),(14,20,16,1,NULL,NULL),(15,20,17,1,NULL,NULL),(16,20,18,1,NULL,NULL),(17,20,19,1,NULL,NULL),(18,20,20,1,NULL,'2025-12-26 17:23:42'),(19,20,21,1,NULL,'2025-12-26 17:26:08'),(20,20,22,1,NULL,NULL),(21,20,23,1,NULL,NULL),(22,20,24,1,NULL,NULL),(23,20,25,1,NULL,NULL),(24,20,26,1,NULL,NULL),(25,20,27,1,NULL,NULL),(26,20,28,1,NULL,NULL),(27,20,29,1,NULL,NULL),(28,20,30,1,NULL,'2025-12-27 10:22:04'),(29,20,31,1,NULL,NULL),(30,20,32,1,NULL,NULL),(31,20,33,1,NULL,NULL),(32,20,34,1,NULL,NULL),(33,20,35,1,NULL,NULL),(34,20,36,1,NULL,NULL),(35,20,37,1,NULL,NULL),(36,20,38,1,NULL,NULL),(37,20,39,1,NULL,NULL),(38,20,40,1,NULL,NULL),(39,20,41,1,NULL,NULL),(40,20,42,1,NULL,NULL),(41,20,43,1,NULL,NULL),(42,20,44,1,NULL,NULL),(43,20,45,1,NULL,NULL),(44,20,46,1,NULL,NULL),(45,20,47,1,NULL,NULL),(46,20,48,1,NULL,NULL),(47,20,49,1,NULL,NULL),(48,20,50,1,NULL,NULL),(49,20,51,1,NULL,NULL),(50,20,52,1,NULL,NULL),(51,20,53,1,NULL,NULL),(52,20,54,1,NULL,NULL),(53,20,55,1,NULL,NULL),(54,20,56,1,NULL,NULL),(55,20,57,1,NULL,NULL),(56,20,58,1,NULL,NULL),(57,20,59,1,NULL,NULL),(58,20,60,1,NULL,NULL),(59,20,61,1,NULL,NULL),(60,20,62,1,NULL,NULL),(61,0,64,1,NULL,NULL);
/*!40000 ALTER TABLE `product_inventory_indices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_ordered_inventories`
--

DROP TABLE IF EXISTS `product_ordered_inventories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_ordered_inventories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `qty` int NOT NULL DEFAULT '0',
  `product_id` int unsigned NOT NULL,
  `channel_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_ordered_inventories_product_id_channel_id_unique` (`product_id`,`channel_id`),
  KEY `product_ordered_inventories_channel_id_foreign` (`channel_id`),
  CONSTRAINT `product_ordered_inventories_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_ordered_inventories_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_ordered_inventories`
--

LOCK TABLES `product_ordered_inventories` WRITE;
/*!40000 ALTER TABLE `product_ordered_inventories` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_ordered_inventories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_price_indices`
--

DROP TABLE IF EXISTS `product_price_indices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_price_indices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL,
  `customer_group_id` int unsigned DEFAULT NULL,
  `channel_id` int unsigned NOT NULL DEFAULT '1',
  `min_price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `regular_min_price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `max_price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `regular_max_price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `price_indices_product_id_customer_group_id_channel_id_unique` (`product_id`,`customer_group_id`,`channel_id`),
  KEY `product_price_indices_customer_group_id_foreign` (`customer_group_id`),
  KEY `product_price_indices_channel_id_foreign` (`channel_id`),
  KEY `ppi_product_id_customer_group_id_idx` (`product_id`,`customer_group_id`),
  CONSTRAINT `product_price_indices_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_price_indices_customer_group_id_foreign` FOREIGN KEY (`customer_group_id`) REFERENCES `customer_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_price_indices_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=184 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_price_indices`
--

LOCK TABLES `product_price_indices` WRITE;
/*!40000 ALTER TABLE `product_price_indices` DISABLE KEYS */;
INSERT INTO `product_price_indices` VALUES (1,1,1,1,90.0000,95.0000,90.0000,95.0000,NULL,NULL),(2,1,2,1,90.0000,95.0000,90.0000,95.0000,NULL,NULL),(3,1,3,1,90.0000,95.0000,90.0000,95.0000,NULL,NULL),(4,2,1,1,80.0000,80.0000,80.0000,80.0000,NULL,'2025-12-27 12:59:46'),(5,2,2,1,80.0000,80.0000,80.0000,80.0000,NULL,'2025-12-27 12:59:46'),(6,2,3,1,80.0000,80.0000,80.0000,80.0000,NULL,'2025-12-27 12:59:46'),(7,3,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:17:16'),(8,3,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:17:16'),(9,3,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:17:16'),(10,4,1,1,90.0000,100.0000,90.0000,100.0000,NULL,NULL),(11,4,2,1,90.0000,100.0000,90.0000,100.0000,NULL,NULL),(12,4,3,1,90.0000,100.0000,90.0000,100.0000,NULL,NULL),(13,5,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:19:44'),(14,5,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:19:44'),(15,5,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:19:44'),(16,7,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:20:20'),(17,7,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:20:21'),(18,7,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:20:21'),(19,8,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:20:57'),(20,8,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:20:57'),(21,8,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:20:57'),(22,9,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:21:40'),(23,9,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:21:40'),(24,9,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:21:40'),(25,10,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:22:47'),(26,10,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:22:47'),(27,10,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:22:47'),(28,11,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:24:05'),(29,11,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:24:05'),(30,11,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:24:05'),(31,12,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:25:09'),(32,12,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:25:09'),(33,12,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:25:09'),(34,13,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:25:40'),(35,13,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:25:40'),(36,13,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:25:40'),(37,14,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:26:10'),(38,14,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:26:10'),(39,14,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:26:10'),(40,16,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:26:47'),(41,16,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:26:47'),(42,16,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:26:47'),(43,17,1,1,90.0000,100.0000,90.0000,100.0000,NULL,NULL),(44,17,2,1,90.0000,100.0000,90.0000,100.0000,NULL,NULL),(45,17,3,1,90.0000,100.0000,90.0000,100.0000,NULL,NULL),(46,18,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:28:42'),(47,18,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:28:42'),(48,18,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-27 13:28:42'),(49,19,1,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-26 17:21:28'),(50,19,2,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-26 17:21:28'),(51,19,3,1,100.0000,100.0000,100.0000,100.0000,NULL,'2025-12-26 17:21:28'),(52,20,1,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(53,20,2,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(54,20,3,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(55,21,1,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(56,21,2,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(57,21,3,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(58,22,1,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(59,22,2,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(60,22,3,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(61,23,1,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(62,23,2,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(63,23,3,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(64,24,1,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(65,24,2,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(66,24,3,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(67,25,1,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(68,25,2,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(69,25,3,1,100.0000,100.0000,100.0000,100.0000,NULL,NULL),(70,26,1,1,1343.0000,1343.0000,1343.0000,1343.0000,NULL,'2025-12-27 09:54:31'),(71,26,2,1,1343.0000,1343.0000,1343.0000,1343.0000,NULL,'2025-12-27 09:54:31'),(72,26,3,1,1343.0000,1343.0000,1343.0000,1343.0000,NULL,'2025-12-27 09:54:31'),(73,27,1,1,1432.0000,1432.0000,1432.0000,1432.0000,NULL,NULL),(74,27,2,1,1432.0000,1432.0000,1432.0000,1432.0000,NULL,NULL),(75,27,3,1,1432.0000,1432.0000,1432.0000,1432.0000,NULL,NULL),(76,28,1,1,2149.0000,2149.0000,2149.0000,2149.0000,NULL,NULL),(77,28,2,1,2149.0000,2149.0000,2149.0000,2149.0000,NULL,NULL),(78,28,3,1,2149.0000,2149.0000,2149.0000,2149.0000,NULL,NULL),(79,29,1,1,359.0000,359.0000,359.0000,359.0000,NULL,NULL),(80,29,2,1,359.0000,359.0000,359.0000,359.0000,NULL,NULL),(81,29,3,1,359.0000,359.0000,359.0000,359.0000,NULL,NULL),(82,30,1,1,447.0000,447.0000,447.0000,447.0000,NULL,NULL),(83,30,2,1,447.0000,447.0000,447.0000,447.0000,NULL,NULL),(84,30,3,1,447.0000,447.0000,447.0000,447.0000,NULL,NULL),(85,31,1,1,805.0000,805.0000,805.0000,805.0000,NULL,NULL),(86,31,2,1,805.0000,805.0000,805.0000,805.0000,NULL,NULL),(87,31,3,1,805.0000,805.0000,805.0000,805.0000,NULL,NULL),(88,32,1,1,626.0000,626.0000,626.0000,626.0000,NULL,NULL),(89,32,2,1,626.0000,626.0000,626.0000,626.0000,NULL,NULL),(90,32,3,1,626.0000,626.0000,626.0000,626.0000,NULL,NULL),(91,33,1,1,1970.0000,1970.0000,1970.0000,1970.0000,NULL,NULL),(92,33,2,1,1970.0000,1970.0000,1970.0000,1970.0000,NULL,NULL),(93,33,3,1,1970.0000,1970.0000,1970.0000,1970.0000,NULL,NULL),(94,34,1,1,1343.0000,1343.0000,1343.0000,1343.0000,NULL,NULL),(95,34,2,1,1343.0000,1343.0000,1343.0000,1343.0000,NULL,NULL),(96,34,3,1,1343.0000,1343.0000,1343.0000,1343.0000,NULL,NULL),(97,35,1,1,1343.0000,1343.0000,1343.0000,1343.0000,NULL,NULL),(98,35,2,1,1343.0000,1343.0000,1343.0000,1343.0000,NULL,NULL),(99,35,3,1,1343.0000,1343.0000,1343.0000,1343.0000,NULL,NULL),(100,36,1,1,358.0000,358.0000,358.0000,358.0000,NULL,NULL),(101,36,2,1,358.0000,358.0000,358.0000,358.0000,NULL,NULL),(102,36,3,1,358.0000,358.0000,358.0000,358.0000,NULL,NULL),(103,37,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(104,37,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(105,37,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(106,38,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(107,38,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(108,38,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(109,39,1,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:45:24'),(110,39,2,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:45:24'),(111,39,3,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:45:24'),(112,40,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(113,40,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(114,40,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(115,41,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(116,41,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(117,41,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(118,42,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(119,42,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(120,42,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(121,43,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(122,43,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(123,43,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(124,44,1,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:38:25'),(125,44,2,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:38:25'),(126,44,3,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:38:25'),(127,45,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(128,45,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(129,45,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(130,46,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(131,46,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(132,46,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(133,47,1,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:48:50'),(134,47,2,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:48:50'),(135,47,3,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:48:50'),(136,48,1,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:40:42'),(137,48,2,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:40:42'),(138,48,3,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:40:42'),(139,49,1,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:50:16'),(140,49,2,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:50:16'),(141,49,3,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:50:16'),(142,50,1,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:48:05'),(143,50,2,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:48:05'),(144,50,3,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:48:05'),(145,51,1,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:51:47'),(146,51,2,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:51:47'),(147,51,3,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:51:47'),(148,52,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(149,52,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(150,52,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(151,53,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(152,53,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(153,53,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(154,54,1,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:27:19'),(155,54,2,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:27:19'),(156,54,3,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:27:19'),(157,55,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(158,55,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(159,55,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(160,56,1,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:27:01'),(161,56,2,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:27:01'),(162,56,3,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 15:27:01'),(163,57,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(164,57,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(165,57,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(166,58,1,1,18.0000,18.0000,18.0000,18.0000,NULL,NULL),(167,58,2,1,18.0000,18.0000,18.0000,18.0000,NULL,NULL),(168,58,3,1,18.0000,18.0000,18.0000,18.0000,NULL,NULL),(169,59,1,1,18.0000,18.0000,18.0000,18.0000,NULL,NULL),(170,59,2,1,18.0000,18.0000,18.0000,18.0000,NULL,NULL),(171,59,3,1,18.0000,18.0000,18.0000,18.0000,NULL,NULL),(172,60,1,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(173,60,2,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(174,60,3,1,0.0000,0.0000,0.0000,0.0000,NULL,NULL),(175,61,1,1,18.0000,18.0000,18.0000,18.0000,NULL,NULL),(176,61,2,1,18.0000,18.0000,18.0000,18.0000,NULL,NULL),(177,61,3,1,18.0000,18.0000,18.0000,18.0000,NULL,NULL),(178,62,1,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:54:10'),(179,62,2,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:54:10'),(180,62,3,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 13:54:10'),(181,64,1,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 16:29:46'),(182,64,2,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 16:29:46'),(183,64,3,1,0.0000,0.0000,0.0000,0.0000,NULL,'2025-12-27 16:29:46');
/*!40000 ALTER TABLE `product_price_indices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_relations`
--

DROP TABLE IF EXISTS `product_relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_relations` (
  `parent_id` int unsigned NOT NULL,
  `child_id` int unsigned NOT NULL,
  UNIQUE KEY `product_relations_parent_id_child_id_unique` (`parent_id`,`child_id`),
  KEY `product_relations_child_id_foreign` (`child_id`),
  CONSTRAINT `product_relations_child_id_foreign` FOREIGN KEY (`child_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_relations_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_relations`
--

LOCK TABLES `product_relations` WRITE;
/*!40000 ALTER TABLE `product_relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_review_attachments`
--

DROP TABLE IF EXISTS `product_review_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_review_attachments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `review_id` int unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'image',
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_review_images_review_id_foreign` (`review_id`),
  CONSTRAINT `product_review_images_review_id_foreign` FOREIGN KEY (`review_id`) REFERENCES `product_reviews` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_review_attachments`
--

LOCK TABLES `product_review_attachments` WRITE;
/*!40000 ALTER TABLE `product_review_attachments` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_review_attachments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_reviews`
--

DROP TABLE IF EXISTS `product_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_reviews` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` int NOT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int unsigned NOT NULL,
  `customer_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prod_rev_product_id_idx` (`product_id`),
  CONSTRAINT `product_reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_reviews`
--

LOCK TABLES `product_reviews` WRITE;
/*!40000 ALTER TABLE `product_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_super_attributes`
--

DROP TABLE IF EXISTS `product_super_attributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_super_attributes` (
  `product_id` int unsigned NOT NULL,
  `attribute_id` int unsigned NOT NULL,
  UNIQUE KEY `product_super_attributes_product_id_attribute_id_unique` (`product_id`,`attribute_id`),
  KEY `product_super_attributes_attribute_id_foreign` (`attribute_id`),
  CONSTRAINT `product_super_attributes_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `product_super_attributes_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_super_attributes`
--

LOCK TABLES `product_super_attributes` WRITE;
/*!40000 ALTER TABLE `product_super_attributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_super_attributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_up_sells`
--

DROP TABLE IF EXISTS `product_up_sells`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_up_sells` (
  `parent_id` int unsigned NOT NULL,
  `child_id` int unsigned NOT NULL,
  UNIQUE KEY `product_up_sells_parent_id_child_id_unique` (`parent_id`,`child_id`),
  KEY `product_up_sells_child_id_foreign` (`child_id`),
  CONSTRAINT `product_up_sells_child_id_foreign` FOREIGN KEY (`child_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_up_sells_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_up_sells`
--

LOCK TABLES `product_up_sells` WRITE;
/*!40000 ALTER TABLE `product_up_sells` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_up_sells` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_videos`
--

DROP TABLE IF EXISTS `product_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_videos` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `prod_vid_product_id_idx` (`product_id`),
  CONSTRAINT `product_videos_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_videos`
--

LOCK TABLES `product_videos` WRITE;
/*!40000 ALTER TABLE `product_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int unsigned DEFAULT NULL,
  `attribute_family_id` int unsigned DEFAULT NULL,
  `additional` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_sku_unique` (`sku`),
  KEY `products_attribute_family_id_foreign` (`attribute_family_id`),
  KEY `products_parent_id_foreign` (`parent_id`),
  CONSTRAINT `products_attribute_family_id_foreign` FOREIGN KEY (`attribute_family_id`) REFERENCES `attribute_families` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `products_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'001','simple',NULL,1,NULL,'2025-12-11 21:26:08','2025-12-11 21:26:08'),(2,'RAM-FOOD-001','simple',NULL,1,NULL,'2025-12-26 09:13:16','2025-12-26 09:13:16'),(3,'RAM-FOOD-002','simple',NULL,1,NULL,'2025-12-26 10:17:31','2025-12-26 10:17:31'),(4,'RAM-FOOD-003','simple',NULL,1,NULL,'2025-12-26 10:46:56','2025-12-26 10:46:56'),(5,'RAM-FOOD-004','simple',NULL,1,NULL,'2025-12-26 11:15:39','2025-12-26 11:15:39'),(7,'RAM-FOOD-005','simple',NULL,1,NULL,'2025-12-26 11:29:47','2025-12-26 11:29:47'),(8,'RAM-FOOD-006','simple',NULL,1,NULL,'2025-12-26 11:40:48','2025-12-26 11:43:15'),(9,'RAM-FOOD-007','simple',NULL,1,NULL,'2025-12-26 11:54:12','2025-12-26 11:54:12'),(10,'RAM-FOOD-008','simple',NULL,1,NULL,'2025-12-26 12:06:03','2025-12-26 12:06:03'),(11,'RAM-FOOD-011','simple',NULL,1,NULL,'2025-12-26 12:18:15','2025-12-26 12:22:12'),(12,'RAM-FOOD-012','simple',NULL,1,NULL,'2025-12-26 12:22:47','2025-12-26 12:22:47'),(13,'RAM-FOOD-013','simple',NULL,1,NULL,'2025-12-26 12:28:23','2025-12-26 12:28:23'),(14,'RAM-FOOD-014','simple',NULL,1,NULL,'2025-12-26 12:39:08','2025-12-26 12:39:08'),(16,'RAM-FOOD-015','simple',NULL,1,NULL,'2025-12-26 16:55:44','2025-12-26 16:55:44'),(17,'RAM-FOOD-016','simple',NULL,1,NULL,'2025-12-26 17:03:54','2025-12-26 17:03:54'),(18,'RAM-PLAZA-001','simple',NULL,1,NULL,'2025-12-26 17:09:25','2025-12-26 17:09:25'),(19,'RAM-PLAZA-002','simple',NULL,1,NULL,'2025-12-26 17:15:48','2025-12-26 17:15:48'),(20,'RAM-PLAZA-003','simple',NULL,1,NULL,'2025-12-26 17:21:53','2025-12-26 17:21:53'),(21,'RAM-PLAZA-004','simple',NULL,1,NULL,'2025-12-26 17:24:23','2025-12-26 17:24:23'),(22,'RAM-PLAZA-005','simple',NULL,1,NULL,'2025-12-26 17:29:31','2025-12-26 17:29:31'),(23,'RAM-SERV-TUR-001','simple',NULL,1,NULL,'2025-12-27 09:35:36','2025-12-27 09:35:36'),(24,'RAM-SERV-TUR-002','simple',NULL,1,NULL,'2025-12-27 09:42:51','2025-12-27 09:42:51'),(25,'RAM-SERV-TUR-003','simple',NULL,1,NULL,'2025-12-27 09:45:33','2025-12-27 09:45:33'),(26,'RAM-SERV-PAR-001','simple',NULL,1,NULL,'2025-12-27 09:48:55','2025-12-27 09:48:55'),(27,'RAM-SERV-PAR-002','simple',NULL,1,NULL,'2025-12-27 09:55:55','2025-12-27 09:55:55'),(28,'RAM-SERV-PAR-003','simple',NULL,1,NULL,'2025-12-27 10:07:05','2025-12-27 10:07:05'),(29,'RAM-SERV-PAR-004','simple',NULL,1,NULL,'2025-12-27 10:12:42','2025-12-27 10:12:42'),(30,'RAM-SERV-PAR-005','simple',NULL,1,NULL,'2025-12-27 10:18:58','2025-12-27 10:18:58'),(31,'RAM-SERV-PAR-006','simple',NULL,1,NULL,'2025-12-27 10:22:40','2025-12-27 10:22:40'),(32,'RAM-SERV-PAR-007','simple',NULL,1,NULL,'2025-12-27 10:25:43','2025-12-27 10:25:43'),(33,'RAM-SERV-PAR-008','simple',NULL,1,NULL,'2025-12-27 10:32:35','2025-12-27 10:32:35'),(34,'RAM-SERV-DISC-001','simple',NULL,1,NULL,'2025-12-27 10:35:30','2025-12-27 10:35:30'),(35,'RAM-SERV-DISC-002','simple',NULL,1,NULL,'2025-12-27 10:38:29','2025-12-27 10:38:29'),(36,'RAM-SERV-DISC-003','simple',NULL,1,NULL,'2025-12-27 10:43:21','2025-12-27 10:43:21'),(37,'RAM-SERV-DEP-001','simple',NULL,1,NULL,'2025-12-27 10:45:41','2025-12-27 10:45:41'),(38,'RAM-SERV-DEP-002','simple',NULL,1,NULL,'2025-12-27 10:48:02','2025-12-27 10:48:02'),(39,'RAM-SERV-DEP-003','simple',NULL,1,NULL,'2025-12-27 10:52:11','2025-12-27 10:52:11'),(40,'RAM-SERV-EDU-001','simple',NULL,1,NULL,'2025-12-27 10:58:50','2025-12-27 10:58:50'),(41,'RAM-SERV-EDU-002','simple',NULL,1,NULL,'2025-12-27 11:00:43','2025-12-27 11:00:43'),(42,'RAM-SERV-MED-001','simple',NULL,1,NULL,'2025-12-27 11:02:14','2025-12-27 11:02:14'),(43,'RAM-SERV-MED-002','simple',NULL,1,NULL,'2025-12-27 11:04:44','2025-12-27 11:04:44'),(44,'RAM-SERV-AUT-001','simple',NULL,1,NULL,'2025-12-27 11:06:46','2025-12-27 11:06:46'),(45,'RAM-MUS-001','simple',NULL,1,NULL,'2025-12-27 11:08:27','2025-12-27 11:08:27'),(46,'RAM-COM-001','simple',NULL,1,NULL,'2025-12-27 11:10:06','2025-12-27 11:10:06'),(47,'RAM-COM-002','simple',NULL,1,NULL,'2025-12-27 11:14:18','2025-12-27 11:14:18'),(48,'RAM-COM-003','simple',NULL,1,NULL,'2025-12-27 11:16:23','2025-12-27 11:16:23'),(49,'RAM-COM-004','simple',NULL,1,NULL,'2025-12-27 11:17:55','2025-12-27 11:17:55'),(50,'RAM-COM-005','simple',NULL,1,NULL,'2025-12-27 11:20:07','2025-12-27 11:20:07'),(51,'RAM-COM-006','simple',NULL,1,NULL,'2025-12-27 11:22:46','2025-12-27 11:22:46'),(52,'RAM-SERV-TEL-001','simple',NULL,1,NULL,'2025-12-27 11:24:30','2025-12-27 11:24:30'),(53,'RAM-SERV-TEL-002','simple',NULL,1,NULL,'2025-12-27 11:27:24','2025-12-27 11:27:24'),(54,'RAM-SERV-TEL-003','simple',NULL,1,NULL,'2025-12-27 11:30:12','2025-12-27 11:30:12'),(55,'RAM-PROD-TEL-001','simple',NULL,1,NULL,'2025-12-27 11:32:36','2025-12-27 11:32:36'),(56,'RAM-PROD-TEL-002','simple',NULL,1,NULL,'2025-12-27 11:34:14','2025-12-27 11:34:14'),(57,'RAM-PROD-TEL-003','simple',NULL,1,NULL,'2025-12-27 11:35:23','2025-12-27 11:35:23'),(58,'RAM-PROD-001','simple',NULL,1,NULL,'2025-12-27 11:36:52','2025-12-27 11:36:52'),(59,'RAM-PROD-002','simple',NULL,1,NULL,'2025-12-27 11:39:12','2025-12-27 11:39:12'),(60,'RAM-PROD-003','simple',NULL,1,NULL,'2025-12-27 11:44:08','2025-12-27 11:44:08'),(61,'RAM-PROD-004','simple',NULL,1,NULL,'2025-12-27 11:46:05','2025-12-27 11:46:05'),(62,'RAM-ROP-001','simple',NULL,1,NULL,'2025-12-27 11:49:51','2025-12-27 11:49:51'),(64,'Test','virtual',NULL,1,NULL,'2025-12-27 16:25:26','2025-12-27 16:25:26');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refund_items`
--

DROP TABLE IF EXISTS `refund_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refund_items` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_price` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `total` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_total` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `tax_amount` decimal(12,4) DEFAULT '0.0000',
  `base_tax_amount` decimal(12,4) DEFAULT '0.0000',
  `discount_percent` decimal(12,4) DEFAULT '0.0000',
  `discount_amount` decimal(12,4) DEFAULT '0.0000',
  `base_discount_amount` decimal(12,4) DEFAULT '0.0000',
  `price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `product_id` int unsigned DEFAULT NULL,
  `product_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_item_id` int unsigned DEFAULT NULL,
  `refund_id` int unsigned DEFAULT NULL,
  `additional` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `refund_items_parent_id_foreign` (`parent_id`),
  KEY `refund_items_order_item_id_foreign` (`order_item_id`),
  KEY `refund_items_refund_id_foreign` (`refund_id`),
  CONSTRAINT `refund_items_order_item_id_foreign` FOREIGN KEY (`order_item_id`) REFERENCES `order_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `refund_items_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `refund_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `refund_items_refund_id_foreign` FOREIGN KEY (`refund_id`) REFERENCES `refunds` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refund_items`
--

LOCK TABLES `refund_items` WRITE;
/*!40000 ALTER TABLE `refund_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `refund_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refunds`
--

DROP TABLE IF EXISTS `refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refunds` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `increment_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_sent` tinyint(1) NOT NULL DEFAULT '0',
  `total_qty` int DEFAULT NULL,
  `base_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `channel_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_currency_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adjustment_refund` decimal(12,4) DEFAULT '0.0000',
  `base_adjustment_refund` decimal(12,4) DEFAULT '0.0000',
  `adjustment_fee` decimal(12,4) DEFAULT '0.0000',
  `base_adjustment_fee` decimal(12,4) DEFAULT '0.0000',
  `sub_total` decimal(12,4) DEFAULT '0.0000',
  `base_sub_total` decimal(12,4) DEFAULT '0.0000',
  `grand_total` decimal(12,4) DEFAULT '0.0000',
  `base_grand_total` decimal(12,4) DEFAULT '0.0000',
  `shipping_amount` decimal(12,4) DEFAULT '0.0000',
  `base_shipping_amount` decimal(12,4) DEFAULT '0.0000',
  `tax_amount` decimal(12,4) DEFAULT '0.0000',
  `base_tax_amount` decimal(12,4) DEFAULT '0.0000',
  `discount_percent` decimal(12,4) DEFAULT '0.0000',
  `discount_amount` decimal(12,4) DEFAULT '0.0000',
  `base_discount_amount` decimal(12,4) DEFAULT '0.0000',
  `shipping_tax_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_shipping_tax_amount` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `sub_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_sub_total_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `shipping_amount_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_shipping_amount_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `order_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `refunds_order_id_foreign` (`order_id`),
  CONSTRAINT `refunds_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refunds`
--

LOCK TABLES `refunds` WRITE;
/*!40000 ALTER TABLE `refunds` DISABLE KEYS */;
/*!40000 ALTER TABLE `refunds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permission_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin DevOps','Los usuarios con este rol tendrán acceso a todo. Para fines de Desarrollo y Operaciones.','all','[]',NULL,'2025-12-12 12:54:06'),(2,'Administrador Operativo','Usuarios administradores que operan la plataforma','custom','[\"dashboard\", \"sales\", \"sales.orders\", \"sales.orders.create\", \"sales.orders.view\", \"sales.orders.cancel\", \"sales.invoices\", \"sales.invoices.view\", \"sales.invoices.create\", \"sales.shipments\", \"sales.shipments.view\", \"sales.shipments.create\", \"sales.refunds\", \"sales.refunds.view\", \"sales.refunds.create\", \"sales.transactions\", \"sales.transactions.view\", \"catalog\", \"catalog.products\", \"catalog.products.create\", \"catalog.products.copy\", \"catalog.products.edit\", \"catalog.products.delete\", \"catalog.categories\", \"catalog.categories.create\", \"catalog.categories.edit\", \"catalog.categories.delete\", \"catalog.attributes\", \"catalog.attributes.create\", \"catalog.attributes.edit\", \"catalog.attributes.delete\", \"catalog.families\", \"catalog.families.create\", \"catalog.families.edit\", \"catalog.families.delete\", \"customers\", \"customers.customers\", \"customers.customers.create\", \"customers.customers.edit\", \"customers.customers.delete\", \"customers.addresses\", \"customers.addresses.create\", \"customers.addresses.edit\", \"customers.addresses.delete\", \"customers.note\", \"customers.groups\", \"customers.groups.create\", \"customers.groups.edit\", \"customers.groups.delete\", \"customers.reviews\", \"customers.reviews.edit\", \"customers.reviews.delete\", \"customers.gdpr_requests\", \"customers.gdpr_requests.edit\", \"customers.gdpr_requests.delete\", \"marketing\", \"marketing.promotions\", \"marketing.promotions.cart_rules\", \"marketing.promotions.cart_rules.create\", \"marketing.promotions.cart_rules.copy\", \"marketing.promotions.cart_rules.edit\", \"marketing.promotions.cart_rules.delete\", \"marketing.promotions.catalog_rules\", \"marketing.promotions.catalog_rules.create\", \"marketing.promotions.catalog_rules.edit\", \"marketing.promotions.catalog_rules.delete\", \"marketing.communications\", \"marketing.communications.email_templates\", \"marketing.communications.email_templates.create\", \"marketing.communications.email_templates.edit\", \"marketing.communications.email_templates.delete\", \"marketing.communications.events\", \"marketing.communications.events.create\", \"marketing.communications.events.edit\", \"marketing.communications.events.delete\", \"marketing.communications.campaigns\", \"marketing.communications.campaigns.create\", \"marketing.communications.campaigns.edit\", \"marketing.communications.campaigns.delete\", \"marketing.communications.subscribers\", \"marketing.communications.subscribers.edit\", \"marketing.communications.subscribers.delete\", \"marketing.search_seo\", \"marketing.search_seo.url_rewrites\", \"marketing.search_seo.url_rewrites.create\", \"marketing.search_seo.url_rewrites.edit\", \"marketing.search_seo.url_rewrites.delete\", \"marketing.search_seo.search_terms\", \"marketing.search_seo.search_terms.create\", \"marketing.search_seo.search_terms.edit\", \"marketing.search_seo.search_terms.delete\", \"marketing.search_seo.search_synonyms\", \"marketing.search_seo.search_synonyms.create\", \"marketing.search_seo.search_synonyms.edit\", \"marketing.search_seo.search_synonyms.delete\", \"marketing.search_seo.sitemaps\", \"marketing.search_seo.sitemaps.create\", \"marketing.search_seo.sitemaps.edit\", \"marketing.search_seo.sitemaps.delete\", \"reporting\", \"reporting.sales\", \"reporting.customers\", \"reporting.products\", \"cms\", \"cms.create\", \"cms.edit\", \"cms.delete\", \"settings\", \"settings.currencies\", \"settings.currencies.create\", \"settings.currencies.edit\", \"settings.currencies.delete\", \"settings.exchange_rates\", \"settings.exchange_rates.create\", \"settings.exchange_rates.edit\", \"settings.exchange_rates.delete\", \"settings.inventory_sources\", \"settings.inventory_sources.create\", \"settings.inventory_sources.edit\", \"settings.inventory_sources.delete\", \"settings.channels\", \"settings.channels.create\", \"settings.channels.edit\", \"settings.channels.delete\", \"settings.users\", \"settings.users.users\", \"settings.users.users.create\", \"settings.users.users.edit\", \"settings.users.users.delete\", \"settings.themes\", \"settings.themes.create\", \"settings.themes.edit\", \"settings.themes.delete\", \"settings.taxes\", \"settings.taxes.tax_categories\", \"settings.taxes.tax_categories.create\", \"settings.taxes.tax_categories.edit\", \"settings.taxes.tax_categories.delete\", \"settings.taxes.tax_rates\", \"settings.taxes.tax_rates.create\", \"settings.taxes.tax_rates.edit\"]','2025-12-12 12:52:56','2025-12-12 12:52:56'),(3,'Cliente RAM','Clientes de RAM (Empresas u Organizaciones). Acceso limitado.','custom','[\"sales\", \"catalog\", \"catalog.products\", \"catalog.products.create\", \"catalog.products.copy\", \"catalog.products.edit\", \"catalog.products.delete\", \"customers\", \"customers.reviews\", \"customers.reviews.edit\", \"customers.reviews.delete\"]','2025-12-12 12:56:25','2025-12-12 12:56:25');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_synonyms`
--

DROP TABLE IF EXISTS `search_synonyms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_synonyms` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `terms` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_synonyms`
--

LOCK TABLES `search_synonyms` WRITE;
/*!40000 ALTER TABLE `search_synonyms` DISABLE KEYS */;
/*!40000 ALTER TABLE `search_synonyms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `search_terms`
--

DROP TABLE IF EXISTS `search_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `search_terms` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `term` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `results` int NOT NULL DEFAULT '0',
  `uses` int NOT NULL DEFAULT '0',
  `redirect_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_in_suggested_terms` tinyint(1) NOT NULL DEFAULT '0',
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `channel_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `search_terms_channel_id_foreign` (`channel_id`),
  CONSTRAINT `search_terms_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `search_terms`
--

LOCK TABLES `search_terms` WRITE;
/*!40000 ALTER TABLE `search_terms` DISABLE KEYS */;
INSERT INTO `search_terms` VALUES (1,'prueba',1,2,NULL,0,'es',1,'2025-12-11 21:31:20','2025-12-11 21:45:44'),(2,'Parques',0,1,NULL,0,'es',1,'2025-12-28 06:27:30','2025-12-28 06:27:30'),(3,'Telcel',2,1,NULL,0,'es',1,'2025-12-28 06:27:42','2025-12-28 06:27:42'),(4,'internet',0,1,NULL,0,'es',1,'2025-12-29 13:34:06','2025-12-29 13:34:06');
/*!40000 ALTER TABLE `search_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_items`
--

DROP TABLE IF EXISTS `shipment_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipment_items` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `qty` int DEFAULT NULL,
  `weight` decimal(12,4) DEFAULT NULL,
  `price` decimal(12,4) DEFAULT '0.0000',
  `base_price` decimal(12,4) DEFAULT '0.0000',
  `total` decimal(12,4) DEFAULT '0.0000',
  `base_total` decimal(12,4) DEFAULT '0.0000',
  `price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `base_price_incl_tax` decimal(12,4) NOT NULL DEFAULT '0.0000',
  `product_id` int unsigned DEFAULT NULL,
  `product_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_item_id` int unsigned DEFAULT NULL,
  `shipment_id` int unsigned NOT NULL,
  `additional` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shipment_items_shipment_id_foreign` (`shipment_id`),
  CONSTRAINT `shipment_items_shipment_id_foreign` FOREIGN KEY (`shipment_id`) REFERENCES `shipments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_items`
--

LOCK TABLES `shipment_items` WRITE;
/*!40000 ALTER TABLE `shipment_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipments`
--

DROP TABLE IF EXISTS `shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shipments` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_qty` int DEFAULT NULL,
  `total_weight` decimal(12,4) DEFAULT NULL,
  `carrier_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `carrier_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `track_number` text COLLATE utf8mb4_unicode_ci,
  `email_sent` tinyint(1) NOT NULL DEFAULT '0',
  `customer_id` int unsigned DEFAULT NULL,
  `customer_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `order_id` int unsigned NOT NULL,
  `order_address_id` int unsigned DEFAULT NULL,
  `inventory_source_id` int unsigned DEFAULT NULL,
  `inventory_source_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `shipments_order_id_foreign` (`order_id`),
  KEY `shipments_inventory_source_id_foreign` (`inventory_source_id`),
  CONSTRAINT `shipments_inventory_source_id_foreign` FOREIGN KEY (`inventory_source_id`) REFERENCES `inventory_sources` (`id`) ON DELETE SET NULL,
  CONSTRAINT `shipments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipments`
--

LOCK TABLES `shipments` WRITE;
/*!40000 ALTER TABLE `shipments` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitemaps`
--

DROP TABLE IF EXISTS `sitemaps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitemaps` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `additional` json DEFAULT NULL,
  `generated_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitemaps`
--

LOCK TABLES `sitemaps` WRITE;
/*!40000 ALTER TABLE `sitemaps` DISABLE KEYS */;
/*!40000 ALTER TABLE `sitemaps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subscribers_list`
--

DROP TABLE IF EXISTS `subscribers_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subscribers_list` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_subscribed` tinyint(1) NOT NULL DEFAULT '0',
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_id` int unsigned DEFAULT NULL,
  `channel_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `subscribers_list_customer_id_foreign` (`customer_id`),
  KEY `subscribers_list_channel_id_foreign` (`channel_id`),
  CONSTRAINT `subscribers_list_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `subscribers_list_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subscribers_list`
--

LOCK TABLES `subscribers_list` WRITE;
/*!40000 ALTER TABLE `subscribers_list` DISABLE KEYS */;
INSERT INTO `subscribers_list` VALUES (1,'eduardorosales720@gmail.com',1,'693d025352c22',1,1,'2025-12-13 00:06:11','2025-12-13 00:06:11'),(2,'jorgemontanomgi@gmail.com',1,'695120ceef398',NULL,1,'2025-12-28 06:21:34','2025-12-28 06:21:34');
/*!40000 ALTER TABLE `subscribers_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_categories`
--

DROP TABLE IF EXISTS `tax_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tax_categories_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_categories`
--

LOCK TABLES `tax_categories` WRITE;
/*!40000 ALTER TABLE `tax_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `tax_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_categories_tax_rates`
--

DROP TABLE IF EXISTS `tax_categories_tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_categories_tax_rates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `tax_category_id` int unsigned NOT NULL,
  `tax_rate_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tax_map_index_unique` (`tax_category_id`,`tax_rate_id`),
  KEY `tax_categories_tax_rates_tax_rate_id_foreign` (`tax_rate_id`),
  CONSTRAINT `tax_categories_tax_rates_tax_category_id_foreign` FOREIGN KEY (`tax_category_id`) REFERENCES `tax_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tax_categories_tax_rates_tax_rate_id_foreign` FOREIGN KEY (`tax_rate_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_categories_tax_rates`
--

LOCK TABLES `tax_categories_tax_rates` WRITE;
/*!40000 ALTER TABLE `tax_categories_tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tax_categories_tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tax_rates`
--

DROP TABLE IF EXISTS `tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tax_rates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_zip` tinyint(1) NOT NULL DEFAULT '0',
  `zip_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_from` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tax_rate` decimal(12,4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tax_rates_identifier_unique` (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tax_rates`
--

LOCK TABLES `tax_rates` WRITE;
/*!40000 ALTER TABLE `tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tax_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theme_customization_translations`
--

DROP TABLE IF EXISTS `theme_customization_translations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `theme_customization_translations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `theme_customization_id` int unsigned NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` json NOT NULL,
  PRIMARY KEY (`id`),
  KEY `theme_customization_id_foreign` (`theme_customization_id`),
  CONSTRAINT `theme_customization_id_foreign` FOREIGN KEY (`theme_customization_id`) REFERENCES `theme_customizations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme_customization_translations`
--

LOCK TABLES `theme_customization_translations` WRITE;
/*!40000 ALTER TABLE `theme_customization_translations` DISABLE KEYS */;
INSERT INTO `theme_customization_translations` VALUES (1,1,'es','{\"images\": [{\"link\": \"\", \"image\": \"storage/theme/1/L4QDhKZyf1rpp1EgKQU4EOu8HWwpNyxm7eWOUAy1.webp\", \"title\": \"Banner 3.2\"}, {\"link\": \"\", \"image\": \"storage/theme/1/hX7krOTygEazpz10DJNWV1TyHVEvX6uzH6DENnHX.webp\", \"title\": \"Banner 1.1\"}]}'),(2,2,'es','{\"css\": \"body .skip-to-main-content-link ~ #app .ram-offer {\\r\\n    padding: 14px 0;\\r\\n    background: radial-gradient(60% 120% at 10% 50%, rgba(255, 62, 154, .22), transparent 55%), radial-gradient(60% 120% at 90% 50%, rgba(139, 92, 246, .18), transparent 55%), rgba(10, 10, 10, .55);\\r\\n    border-top: 1px solid rgba(255, 255, 255, .12);\\r\\n    border-bottom: 1px solid rgba(255, 255, 255, .12);\\r\\n    backdrop-filter: blur(12px);\\r\\n    -webkit-backdrop-filter: blur(12px);\\r\\n}\\r\\nbody .skip-to-main-content-link ~ #app .ram-offer__inner {\\r\\n    max-width: 1200px;\\r\\n    margin: 0 auto;\\r\\n    padding: 0 20px;\\r\\n    display: flex;\\r\\n    align-items: center;\\r\\n    justify-content: center;\\r\\n    gap: 14px;\\r\\n    flex-wrap: wrap;\\r\\n    text-align: center;\\r\\n}\\r\\nbody .skip-to-main-content-link ~ #app .ram-offer__badge {\\r\\n    display: inline-flex;\\r\\n    align-items: center;\\r\\n    gap: 8px;\\r\\n    padding: 6px 12px;\\r\\n    margin-top: 25px;\\r\\n    border-radius: 999px;\\r\\n    font-size: 12px;\\r\\n    letter-spacing: .08em;\\r\\n    text-transform: uppercase;\\r\\n    background: rgba(255, 255, 255, .06);\\r\\n    border: 1px solid rgba(255, 255, 255, .14);\\r\\n    color: rgba(255, 255, 255, .85);\\r\\n}\\r\\nbody .skip-to-main-content-link ~ #app .ram-offer__title {\\r\\n    margin: 0;\\r\\n    font-weight: 600;\\r\\n    line-height: 1.2;\\r\\n    font-size: 20px;\\r\\n    color: #fff;\\r\\n    text-shadow: 0 0 22px rgba(255, 62, 154, .18), 0 0 22px rgba(139, 92, 246, .16), 0 0 16px rgba(0, 0, 0, .45);\\r\\n}\\r\\nbody .skip-to-main-content-link ~ #app .ram-offer__title strong {\\r\\n    background: linear-gradient(135deg, #ff3e9a, #8b5cf6);\\r\\n    -webkit-background-clip: text;\\r\\n    background-clip: text;\\r\\n    color: transparent;\\r\\n}\\r\\nbody .skip-to-main-content-link ~ #app .ram-offer__sub {\\r\\n    margin: 0;\\r\\n    font-size: 14px;\\r\\n    color: rgba(255, 255, 255, .72);\\r\\n}\\r\\nbody .skip-to-main-content-link ~ #app .ram-offer__cta {\\r\\n    display: inline-flex;\\r\\n    align-items: center;\\r\\n    justify-content: center;\\r\\n    padding: 10px 16px;\\r\\n    border-radius: 12px;\\r\\n    font-weight: 600;\\r\\n    color: #fff !important;\\r\\n    background: linear-gradient(135deg, #ff3e9a, #8b5cf6);\\r\\n    box-shadow: 0 0 20px rgba(255, 62, 154, .35);\\r\\n    border: 1px solid rgba(255, 255, 255, .10);\\r\\n    transition: 0.3s ease;\\r\\n}\\r\\nbody .skip-to-main-content-link ~ #app .ram-offer__cta:hover {\\r\\n    transform: translateY(-2px);\\r\\n    box-shadow: 0 0 30px rgba(255, 62, 154, .55);\\r\\n}\\r\\n/* Responsive */\\r\\n @media (max-width: 768px) {\\r\\n    body .skip-to-main-content-link ~ #app .ram-offer__title {\\r\\n        font-size: 16px;\\r\\n    }\\r\\n    body .skip-to-main-content-link ~ #app .ram-offer__sub {\\r\\n        font-size: 13px;\\r\\n    }\\r\\n}\\r\\n@media (max-width: 525px) {\\r\\n    body .skip-to-main-content-link ~ #app .ram-offer__title {\\r\\n        font-size: 14px;\\r\\n    }\\r\\n    body .skip-to-main-content-link ~ #app .ram-offer__cta {\\r\\n        width: 100%;\\r\\n    }\\r\\n}\", \"html\": \"<div class=\\\"home-offer ram-offer\\\">\\r\\n  <div class=\\\"ram-offer__inner\\\">\\r\\n    <span class=\\\"ram-offer__badge\\\">ALIANZAS RAM</span>\\r\\n\\r\\n    <h1 class=\\\"ram-offer__title\\\">\\r\\n      Ahorra <strong>10%–40%</strong> en comercios aliados por ser usuario <strong>RAM</strong>\\r\\n    </h1>\\r\\n\\r\\n    <p class=\\\"ram-offer__sub\\\">\\r\\n      Productos, servicios y promociones exclusivas en RAM Plaza.\\r\\n    </p>\\r\\n\\r\\n    <a class=\\\"ram-offer__cta\\\" href=\\\"/search\\\">Ver alianzas</a>\\r\\n  </div>\\r\\n</div>\"}'),(3,3,'es','{\"filters\": {\"sort\": \"asc\", \"limit\": 10, \"parent_id\": 1}}'),(4,4,'es','{\"title\": \"Nuevos Productos\", \"filters\": {\"new\": 1, \"sort\": \"name-asc\", \"limit\": 12}}'),(5,5,'es','{\"css\": \"/* ===== RAM Collections (Skyverse style) ===== */\\r\\n\\r\\nbody .skip-to-main-content-link ~ #app .ram-collections{\\r\\n  overflow: hidden;\\r\\n  padding: 60px 0 10px;\\r\\n}\\r\\n\\r\\n/* Header */\\r\\nbody .skip-to-main-content-link ~ #app .top-collection-header{\\r\\n  padding: 0 20px;\\r\\n  text-align: center;\\r\\n  margin-top: 40px;\\r\\n  color: #fff;\\r\\n}\\r\\n\\r\\nbody .skip-to-main-content-link ~ #app .top-collection-header h2{\\r\\n  margin: 0 auto;\\r\\n  max-width: 900px;\\r\\n  font-family: \'DM Serif Display\', serif;\\r\\n  font-size: 44px;\\r\\n  line-height: 1.15;\\r\\n  text-shadow: 0 0 22px rgba(255,62,154,.18), 0 0 18px rgba(0,0,0,.45);\\r\\n}\\r\\n\\r\\nbody .skip-to-main-content-link ~ #app .ram-collections__sub{\\r\\n  margin: 14px auto 0;\\r\\n  max-width: 800px;\\r\\n  font-size: 16px;\\r\\n  color: rgba(255,255,255,.72);\\r\\n}\\r\\n\\r\\nbody .skip-to-main-content-link ~ #app .ram-collections__sub strong{\\r\\n  background: linear-gradient(135deg, #ff3e9a, #8b5cf6);\\r\\n  -webkit-background-clip: text;\\r\\n  background-clip: text;\\r\\n  color: transparent;\\r\\n  font-weight: 700;\\r\\n}\\r\\n\\r\\n/* Grid */\\r\\nbody .skip-to-main-content-link ~ #app .top-collection-grid{\\r\\n  display: grid;\\r\\n  grid-template-columns: repeat(3, minmax(0, 1fr));\\r\\n  gap: 24px;\\r\\n  justify-content: center;\\r\\n\\r\\n  width: 100%;\\r\\n  margin: 40px auto 0;\\r\\n  padding: 0 30px;\\r\\n}\\r\\n\\r\\n/* Card (glass) */\\r\\nbody .skip-to-main-content-link ~ #app .top-collection-card.ram-card{\\r\\n  position: relative;\\r\\n  display: block;\\r\\n  overflow: hidden;\\r\\n  border-radius: 18px;\\r\\n  text-decoration: none;\\r\\n\\r\\n  background: rgba(255,255,255,.06);\\r\\n  border: 1px solid rgba(255,255,255,.12);\\r\\n  backdrop-filter: blur(12px);\\r\\n  -webkit-backdrop-filter: blur(12px);\\r\\n\\r\\n  box-shadow: 0 10px 30px rgba(0,0,0,.35);\\r\\n  transition: 0.3s ease;\\r\\n}\\r\\n\\r\\n/* Imagen */\\r\\nbody .skip-to-main-content-link ~ #app .top-collection-card.ram-card img{\\r\\n  width: 100%;\\r\\n  height: 280px;\\r\\n  object-fit: cover;\\r\\n  display: block;\\r\\n  transform: scale(1);\\r\\n  transition: transform 300ms ease;\\r\\n  filter: saturate(1.05) contrast(1.05);\\r\\n}\\r\\n\\r\\n/* Overlay para legibilidad del título */\\r\\nbody .skip-to-main-content-link ~ #app .top-collection-card.ram-card::after{\\r\\n  content:\\\"\\\";\\r\\n  position:absolute;\\r\\n  inset: 0;\\r\\n  background: linear-gradient(to top, rgba(10,10,10,.88), rgba(10,10,10,.05));\\r\\n  opacity: .9;\\r\\n  pointer-events:none;\\r\\n}\\r\\n\\r\\n/* Título encima */\\r\\nbody .skip-to-main-content-link ~ #app .top-collection-card.ram-card h3{\\r\\n  position: absolute;\\r\\n  left: 18px;\\r\\n  right: 18px;\\r\\n  bottom: 16px;\\r\\n  margin: 0;\\r\\n\\r\\n  font-family: \'DM Serif Display\', serif;\\r\\n  font-size: 26px;\\r\\n  color: #fff;\\r\\n  z-index: 2;\\r\\n\\r\\n  text-shadow: 0 0 18px rgba(0,0,0,.6);\\r\\n}\\r\\n\\r\\n/* Hover neon */\\r\\nbody .skip-to-main-content-link ~ #app .top-collection-card.ram-card:hover{\\r\\n  transform: translateY(-4px);\\r\\n  border-color: rgba(255,62,154,.45);\\r\\n  box-shadow: 0 0 22px rgba(255,62,154,.25), 0 12px 34px rgba(0,0,0,.45);\\r\\n}\\r\\n\\r\\nbody .skip-to-main-content-link ~ #app .top-collection-card.ram-card:hover img{\\r\\n  transform: scale(1.06);\\r\\n}\\r\\n\\r\\n/* Responsive */\\r\\n@media (max-width: 1024px){\\r\\n  body .skip-to-main-content-link ~ #app .top-collection-grid{\\r\\n    grid-template-columns: repeat(2, minmax(0, 1fr));\\r\\n    padding: 0 20px;\\r\\n  }\\r\\n}\\r\\n\\r\\n@media (max-width: 768px){\\r\\n  body .skip-to-main-content-link ~ #app .top-collection-header h2{\\r\\n    font-size: 28px;\\r\\n  }\\r\\n\\r\\n  body .skip-to-main-content-link ~ #app .ram-collections__sub{\\r\\n    font-size: 14px;\\r\\n  }\\r\\n\\r\\n  body .skip-to-main-content-link ~ #app .top-collection-card.ram-card img{\\r\\n    height: 210px;\\r\\n  }\\r\\n\\r\\n  body .skip-to-main-content-link ~ #app .top-collection-card.ram-card h3{\\r\\n    font-size: 20px;\\r\\n  }\\r\\n}\\r\\n\\r\\n@media (max-width: 520px){\\r\\n  body .skip-to-main-content-link ~ #app .top-collection-grid{\\r\\n    grid-template-columns: 1fr;\\r\\n  }\\r\\n}\", \"html\": \"<div class=\\\"top-collection-container ram-collections\\\">\\r\\n    <div class=\\\"top-collection-header\\\">\\r\\n        \\t<h2>Explora RAM Plaza</h2>\\r\\n\\r\\n        <p class=\\\"ram-collections__sub\\\">Productos, servicios y promociones con <strong>10%–40%</strong> en comercios aliados para usuarios RAM.</p>\\r\\n    </div>\\r\\n    <div class=\\\"top-collection-grid container\\\">\\t<a class=\\\"top-collection-card ram-card\\\" href=\\\"/search?type=product\\\">\\r\\n<img class=\\\"lazy\\\" data-src=\\\"https://plaza.redactivamexico.net/storage/theme/5/Qeb3b1b4g7yozjSKbepc7HRYAdxcA5rCIYabEnnL.webp\\\">\\r\\n          <h3>Productos</h3>\\r\\n\\t\\t</a>\\r\\n\\t<a class=\\\"top-collection-card ram-card\\\" href=\\\"/search?type=service\\\">\\r\\n      \\t\\t<img \\r\\n            \\tsrc=\\\"\\\"\\r\\n            \\tdata-src=\\\"https://plaza.redactivamexico.net/storage/theme/5/p70XyH1AqFY25LWm8XgJPUQfNXhnAbUXh86yTIlJ.webp\\\" \\r\\n                class=\\\"lazy\\\" width=\\\"396\\\" height=\\\"396\\\" alt=\\\"Servicios\\\"\\r\\n        \\t>\\r\\n      \\t\\t<h3>Servicios</h3>\\r\\n    \\t</a>\\r\\n\\t<a class=\\\"top-collection-card ram-card\\\" href=\\\"/search?promos=1\\\">\\r\\n\\t\\t\\t<img \\r\\n            \\tsrc=\\\"\\\" \\r\\n            \\tdata-src=\\\"https://plaza.redactivamexico.net/storage/theme/5/co9F4Fa1XfAPVh3OWhCVe290M5iBxea0uxB47N15.webp\\\" \\r\\n                class=\\\"lazy\\\" width=\\\"396\\\" height=\\\"396\\\" alt=\\\"Promociones\\\"\\r\\n        \\t>\\r\\n      \\t\\t<h3>Promociones</h3>\\r\\n    \\t</a>\\r\\n\\t<a class=\\\"top-collection-card ram-card\\\" href=\\\"/search\\\">\\r\\n      \\t\\t<img \\r\\n                src=\\\"\\\" \\r\\n                data-src=\\\"https://plaza.redactivamexico.net/storage/theme/5/SNxGuEpCDJBhbYfehpKjdzJJEnYXqoUJCJI9x94K.webp\\\" \\r\\n            \\tclass=\\\"lazy\\\" width=\\\"396\\\" height=\\\"396\\\" alt=\\\"Comercios aliados\\\"\\r\\n            >\\r\\n      \\t\\t<h3>Comercios Aliados</h3>\\r\\n    \\t</a>\\r\\n\\t<a class=\\\"top-collection-card ram-card\\\" href=\\\"/search?sort=discount-desc\\\">\\r\\n      \\t\\t<img \\r\\n                src=\\\"\\\" \\r\\n            \\tdata-src=\\\"https://plaza.redactivamexico.net/storage/theme/5/PbO7ku7foJ3RtmyZqb4b3YHIBSdZ8h1iSC0tju0b.webp\\\" \\r\\n                class=\\\"lazy\\\" width=\\\"396\\\" \\t\\t\\t\\r\\n                height=\\\"396\\\" alt=\\\"Mejores descuentos\\\">\\r\\n      \\t\\t<h3>Mejores Descuentos</h3>\\r\\n    \\t</a>\\r\\n\\t<a class=\\\"top-collection-card ram-card\\\" href=\\\"/#como-funciona\\\">\\r\\n      \\t\\t<img \\r\\n                 src=\\\"\\\" \\r\\n                data-src=\\\"https://plaza.redactivamexico.net/storage/theme/5/lGXxopOckVdGvMhniSQsRTjqEuyrHaF0sGxUnQ50.webp\\\" \\r\\n                 class=\\\"lazy\\\" width=\\\"396\\\" \\t\\t\\theight=\\\"396\\\" alt=\\\"Cómo funciona\\\"\\r\\n            >\\r\\n      \\t\\t<h3>¿Cómo funciona?</h3>\\r\\n    \\t</a>\\r\\n\\r\\n    </div>\\r\\n</div>\"}'),(6,6,'es','{\"css\": \"/* =========================\\r\\n   RAM Plaza Inline (estilo highlight)\\r\\n   ========================= */\\r\\n\\r\\n.ram-plaza-inline.section-gap {\\r\\n  margin-top: 80px;\\r\\n  margin-bottom: 80px;\\r\\n}\\r\\n\\r\\n/* Layout */\\r\\n.ram-plaza-inline .inline-col-wrapper {\\r\\n  display: grid;\\r\\n  grid-template-columns: minmax(0, 632px) 1fr;\\r\\n  gap: 60px;\\r\\n  align-items: center;\\r\\n}\\r\\n\\r\\n/* Imagen */\\r\\n.ram-plaza-inline .inline-col-image-wrapper {\\r\\n  width: 100%;\\r\\n  max-width: 632px;\\r\\n  overflow: hidden;\\r\\n  border-radius: 16px;\\r\\n\\r\\n  /* por si el theme mete estilos tipo card */\\r\\n  background: transparent !important;\\r\\n  border: 0 !important;\\r\\n  box-shadow: none !important;\\r\\n}\\r\\n\\r\\n.ram-plaza-inline .inline-col-image-wrapper img {\\r\\n  width: 100%;\\r\\n  height: auto;\\r\\n  display: block;\\r\\n  border-radius: 16px;\\r\\n\\r\\n  /* igual que tu highlight */\\r\\n  object-fit: initial !important;\\r\\n  object-position: initial !important;\\r\\n}\\r\\n\\r\\n/* Contenido */\\r\\n.ram-plaza-inline .inline-col-content-wrapper {\\r\\n  display: flex;\\r\\n  flex-wrap: wrap;\\r\\n  gap: 20px;\\r\\n  max-width: 520px;\\r\\n}\\r\\n\\r\\n/* Título */\\r\\n.ram-plaza-inline .inline-col-title {\\r\\n  max-width: 520px;\\r\\n  font-size: 56px;\\r\\n  font-weight: 600;\\r\\n  color: #ffffff;\\r\\n  line-height: 1.12;\\r\\n  font-family: \\\"DM Serif Display\\\", serif;\\r\\n  margin: 0;\\r\\n}\\r\\n\\r\\n/* Acento (tu HTML usa .ram-accent) */\\r\\n.ram-plaza-inline .ram-accent {\\r\\n  background: linear-gradient(90deg, #ff3e9a 0%, #8b5cf6 100%);\\r\\n  -webkit-background-clip: text;\\r\\n  background-clip: text;\\r\\n  -webkit-text-fill-color: transparent;\\r\\n}\\r\\n\\r\\n/* Descripción */\\r\\n.ram-plaza-inline .inline-col-description {\\r\\n  margin: 0;\\r\\n  font-size: 18px;\\r\\n  color: rgba(255, 255, 255, 0.72);\\r\\n  font-family: Poppins, system-ui, -apple-system, sans-serif;\\r\\n  line-height: 1.7;\\r\\n}\\r\\n\\r\\n/* Botón (sin cambiar tu \\\"primary-button\\\", solo alineación) */\\r\\n.ram-plaza-inline .primary-button {\\r\\n  margin-top: 6px;\\r\\n}\\r\\n\\r\\n/* ====== Responsive ====== */\\r\\n@media (max-width: 991px) {\\r\\n  .ram-plaza-inline .inline-col-wrapper {\\r\\n    grid-template-columns: 1fr;\\r\\n    gap: 16px;\\r\\n  }\\r\\n\\r\\n  .ram-plaza-inline .inline-col-content-wrapper {\\r\\n    gap: 12px;\\r\\n    max-width: 100%;\\r\\n  }\\r\\n\\r\\n  .ram-plaza-inline .inline-col-image-wrapper {\\r\\n    max-width: 100%;\\r\\n  }\\r\\n}\\r\\n\\r\\n@media (max-width: 768px) {\\r\\n  .ram-plaza-inline.section-gap {\\r\\n    padding: 0 30px;\\r\\n    margin-top: 24px;\\r\\n    margin-bottom: 40px;\\r\\n  }\\r\\n\\r\\n  .ram-plaza-inline .inline-col-content-wrapper {\\r\\n    justify-content: center;\\r\\n    text-align: center;\\r\\n  }\\r\\n\\r\\n  .ram-plaza-inline .inline-col-title {\\r\\n    font-size: 30px;\\r\\n    line-height: 1.2;\\r\\n  }\\r\\n\\r\\n  .ram-plaza-inline .primary-button {\\r\\n    margin-inline: auto; /* centra el botón en móvil */\\r\\n  }\\r\\n}\\r\\n\\r\\n@media (max-width: 525px) {\\r\\n  .ram-plaza-inline.section-gap {\\r\\n    padding: 0 15px;\\r\\n    margin-top: 10px;\\r\\n    margin-bottom: 28px;\\r\\n  }\\r\\n\\r\\n  .ram-plaza-inline .inline-col-title {\\r\\n    font-size: 22px;\\r\\n    line-height: 1.25;\\r\\n  }\\r\\n\\r\\n  .ram-plaza-inline .inline-col-description {\\r\\n    font-size: 16px;\\r\\n  }\\r\\n}\", \"html\": \"<div class=\\\"section-gap bold-collections container ram-plaza-inline\\\">\\r\\n    <div class=\\\"inline-col-wrapper\\\">\\r\\n        <div class=\\\"inline-col-image-wrapper\\\">\\r\\n            <img src=\\\"\\\" data-src=\\\"https://plaza.redactivamexico.net/storage/theme/6/e1GIq2rpvDbLiM1lHNEciZh9CKBGgvLVSATsATmY.webp\\\" class=\\\"lazy\\\" width=\\\"632\\\" height=\\\"510\\\" alt=\\\"¡Lo nuevo en RAM Plaza!\\\">\\r\\n        </div>\\r\\n        <div class=\\\"inline-col-content-wrapper\\\">\\r\\n             <h2 class=\\\"inline-col-title\\\">¡Lo nuevo en <span class=\\\"ram-accent\\\">RAM Plaza</span>!</h2> \\r\\n            <p class=\\\"inline-col-description\\\">En colaboración con nuestros comercios aliados, llega lo nuevo a RAM Plaza: diseños con actitud, colores que resaltan y estilo que se nota. Disfruta de descuentos exclusivos y apoya al comercio local dentro de RedActiva México.</p>\\r\\n<button\\r\\n  class=\\\"primary-button max-md:rounded-lg max-md:px-4 max-md:py-2.5 max-md:text-sm\\\"\\r\\n  onclick=\\\"window.location.href=\'https://plaza.redactivamexico.net/search\'\\\">\\r\\n  Explorar RAM Plaza\\r\\n</button>\\r\\n\\r\\n        </div>\\r\\n    </div>\\r\\n</div>\"}'),(7,7,'es','{\"title\": \"Productos Destacados\", \"filters\": {\"sort\": \"name-desc\", \"limit\": 12, \"featured\": 1}}'),(8,8,'es','{\"css\": \".section-game{\\r\\n  overflow: visible;\\r\\n  padding-bottom: 20px;\\r\\n}\\r\\n.section-title, .section-title h2 {\\r\\n    font-weight:400;\\r\\n    font-family:DM Serif Display\\r\\n}\\r\\n.section-title {\\r\\n    margin-top:80px;\\r\\n    padding-left:15px;\\r\\n    padding-right:15px;\\r\\n    text-align:center;\\r\\n    line-height:90px\\r\\n}\\r\\n.section-title h2 {\\r\\n    font-size:70px;\\r\\n    color:#060c3b;\\r\\n    max-width:595px;\\r\\n    margin:auto\\r\\n}\\r\\n.collection-card-wrapper {\\r\\n    display:flex;\\r\\n    flex-wrap:wrap;\\r\\n    justify-content:center;\\r\\n    gap:30px\\r\\n}\\r\\n.collection-card-wrapper .single-collection-card {\\r\\n    position:relative\\r\\n}\\r\\n.collection-card-wrapper .single-collection-card img {\\r\\n    border-radius:16px;\\r\\n    background-color:#f5f5f5;\\r\\n    max-width:100%;\\r\\n    height:auto;\\r\\n    text-indent:-9999px\\r\\n}\\r\\n.collection-card-wrapper .single-collection-card .overlay-text {\\r\\n    font-size:50px;\\r\\n    font-weight:400;\\r\\n    max-width:234px;\\r\\n    font-style:italic;\\r\\n    color:#060c3b;\\r\\n    font-family:DM Serif Display;\\r\\n    position:absolute;\\r\\n    bottom:30px;\\r\\n    left:30px;\\r\\n    margin:0\\r\\n}\\r\\n@media (max-width:1024px) {\\r\\n    .section-title {\\r\\n        padding:0 30px\\r\\n    }\\r\\n}\\r\\n@media (max-width:991px) {\\r\\n    .collection-card-wrapper {\\r\\n        flex-wrap:wrap\\r\\n    }\\r\\n}\\r\\n@media (max-width:768px) {\\r\\n    .collection-card-wrapper .single-collection-card .overlay-text {\\r\\n        font-size:32px;\\r\\n        bottom:20px\\r\\n    }\\r\\n    .section-title {\\r\\n        margin-top:32px\\r\\n    }\\r\\n    .section-title h2 {\\r\\n        font-size:28px;\\r\\n        line-height:normal\\r\\n    }\\r\\n}\\r\\n@media (max-width:525px) {\\r\\n    .collection-card-wrapper .single-collection-card .overlay-text {\\r\\n        font-size:18px;\\r\\n        bottom:10px\\r\\n    }\\r\\n    .section-title {\\r\\n        margin-top:28px\\r\\n    }\\r\\n    .section-title h2 {\\r\\n        font-size:20px;\\r\\n    }\\r\\n    .collection-card-wrapper {\\r\\n        gap:10px;\\r\\n        15px;\\r\\n        row-gap:15px;\\r\\n        column-gap:0px;\\r\\n        justify-content: space-between;\\r\\n        margin-top: 15px;\\r\\n    }\\r\\n    .collection-card-wrapper .single-collection-card {\\r\\n        width:48%;\\r\\n    }\\r\\n}\", \"html\": \"<div class=\\\"section-game\\\">\\r\\n    <div class=\\\"section-title\\\">\\r\\n         <h2>¡Descubre las nuevas adiciones de RAM Plaza!</h2> \\r\\n    </div>\\r\\n    <div class=\\\"section-gap container\\\">\\r\\n        <div class=\\\"collection-card-wrapper\\\">\\r\\n            <div class=\\\"single-collection-card\\\">\\r\\n                <img src=\\\"\\\" \\r\\n                     data-src=\\\"https://plaza.redactivamexico.net/storage/theme/8/VloQ4ujjBmAPw2JUGVtGy6iwQaTvTr2VYL9VonpU.webp\\\" \\r\\n                     class=\\\"lazy\\\" width=\\\"615\\\" height=\\\"600\\\" alt=\\\"¡El juego con nuestras nuevas adiciones!\\\">\\r\\n                 <h3 class=\\\"overlay-text\\\"></h3> \\r\\n            </div>\\r\\n            <div class=\\\"single-collection-card\\\">\\r\\n                <img src=\\\"\\\" \\r\\n                     data-src=\\\"https://plaza.redactivamexico.net/storage/theme/8/b0fphYxNwEiuQWLBLkok51WWjFtACEwslYAa3gVO.webp\\\" \\r\\n                     class=\\\"lazy\\\" width=\\\"615\\\" height=\\\"600\\\" alt=\\\"¡El juego con nuestras nuevas adiciones!\\\">\\r\\n                 <h3 class=\\\"overlay-text\\\"></h3> \\r\\n            </div>\\r\\n        </div>\\r\\n    </div>\\r\\n</div>\"}'),(9,9,'es','{\"title\": \"Todos los Productos\", \"filters\": {\"sort\": \"name-desc\", \"limit\": 12}}'),(10,10,'es','{\"css\": \".ramplaza-highlight.section-gap{\\r\\n  margin-top: 80px;\\r\\n  margin-bottom: 80px; /* <- espacio inferior consistente */\\r\\n}\\r\\n\\r\\n.ramplaza-highlight .inline-col-wrapper{\\r\\n  display: grid;\\r\\n  grid-template-columns: minmax(0, 632px) 1fr;\\r\\n  grid-gap: 60px;\\r\\n  align-items: center;\\r\\n}\\r\\n\\r\\n.ramplaza-highlight .inline-col-image-wrapper{\\r\\n  width: 100%;\\r\\n  max-width: 632px;\\r\\n  overflow: hidden;\\r\\n  border-radius: 16px;\\r\\n\\r\\n  background: transparent !important;\\r\\n  border: 0 !important;\\r\\n  box-shadow: none !important;\\r\\n}\\r\\n\\r\\n.ramplaza-highlight .inline-col-image-wrapper img{\\r\\n  width: 100%;\\r\\n  height: auto;\\r\\n  display: block;\\r\\n  border-radius: 16px;\\r\\n\\r\\n  object-fit: initial !important;\\r\\n  object-position: initial !important;\\r\\n}\\r\\n\\r\\n.ramplaza-highlight .inline-col-content-wrapper{\\r\\n  display: flex;\\r\\n  flex-wrap: wrap;\\r\\n  gap: 20px;\\r\\n  max-width: 520px;\\r\\n}\\r\\n\\r\\n.ramplaza-highlight .inline-col-title{\\r\\n  max-width: 520px;\\r\\n  font-size: 56px;\\r\\n  font-weight: 600;\\r\\n  color: #ffffff;\\r\\n  line-height: 1.12;\\r\\n  font-family: \\\"DM Serif Display\\\", serif;\\r\\n  margin: 0;\\r\\n}\\r\\n\\r\\n.ramplaza-highlight .ramplaza-accent{\\r\\n  background: linear-gradient(90deg, #ff3e9a 0%, #8b5cf6 100%);\\r\\n  -webkit-background-clip: text;\\r\\n  background-clip: text;\\r\\n  -webkit-text-fill-color: transparent;\\r\\n}\\r\\n\\r\\n.ramplaza-highlight .inline-col-description{\\r\\n  margin: 0;\\r\\n  font-size: 18px;\\r\\n  color: rgba(255, 255, 255, .72);\\r\\n  font-family: Poppins, system-ui, -apple-system, sans-serif;\\r\\n  line-height: 1.7;\\r\\n}\\r\\n\\r\\n@media (max-width: 991px){\\r\\n  .ramplaza-highlight .inline-col-wrapper{\\r\\n    grid-template-columns: 1fr;\\r\\n    grid-gap: 16px;\\r\\n  }\\r\\n\\r\\n  .ramplaza-highlight .inline-col-content-wrapper{\\r\\n    gap: 12px;\\r\\n    max-width: 100%;\\r\\n  }\\r\\n\\r\\n  .ramplaza-highlight .inline-col-image-wrapper{\\r\\n    max-width: 100%;\\r\\n  }\\r\\n}\\r\\n\\r\\n@media (max-width: 768px){\\r\\n  .ramplaza-highlight.section-gap{\\r\\n    padding: 0 30px;\\r\\n    margin-top: 24px;\\r\\n    margin-bottom: 40px; /* <- espacio inferior en móvil */\\r\\n  }\\r\\n\\r\\n  .ramplaza-highlight .inline-col-content-wrapper{\\r\\n    justify-content: center;\\r\\n    text-align: center;\\r\\n  }\\r\\n\\r\\n  .ramplaza-highlight .inline-col-title{\\r\\n    font-size: 30px;\\r\\n    line-height: 1.2;\\r\\n  }\\r\\n}\\r\\n\\r\\n@media (max-width: 525px){\\r\\n  .ramplaza-highlight.section-gap{\\r\\n    padding: 0 15px;\\r\\n    margin-top: 10px;\\r\\n    margin-bottom: 28px;\\r\\n  }\\r\\n\\r\\n  .ramplaza-highlight .inline-col-title{\\r\\n    font-size: 22px;\\r\\n    line-height: 1.25;\\r\\n  }\\r\\n\\r\\n  .ramplaza-highlight .inline-col-description{\\r\\n    font-size: 16px;\\r\\n  }\\r\\n}\", \"html\": \"<div class=\\\"section-gap bold-collections container ramplaza-highlight\\\">\\r\\n    <div class=\\\"inline-col-wrapper direction-rtl\\\">\\r\\n        <div class=\\\"inline-col-image-wrapper\\\">\\r\\n            <img class=\\\"lazy\\\" data-src=\\\"https://plaza.redactivamexico.net/storage/theme/10/UOgOQ2CNNicaMEUoAUCEbcBqYjm50cLVvJgJxGJ6.webp\\\">\\r\\n        </div>\\r\\n        <div class=\\\"inline-col-content-wrapper direction-ltr\\\">\\r\\n             <h2 class=\\\"inline-col-title\\\">Tu Tienda en Línea en <span class=\\\"ramplaza-accent\\\">RAM Plaza</span></h2>\\r\\n\\r\\n            <p class=\\\"inline-col-description\\\">Explora <strong>productos</strong>, <strong>servicios</strong> y <strong>promociones</strong> de comercios aliados. Los negocios registrados en RAM ofrecen descuentos del <strong>10% al 40%</strong> para miembros. Descubre beneficios reales y apoya comercios locales dentro del ecosistema <strong>RedActivaMéxico</strong>.</p>\\r\\n            <button \\r\\n                    class=\\\"primary-button max-md:rounded-lg max-md:px-4 max-md:py-2.5 max-md:text-sm\\\"\\r\\n                    onclick=\\\"window.location.href=\'https://plaza.redactivamexico.net/search\'\\\"\\r\\n                    >Explorar RAM Plaza</button>\\r\\n        </div>\\r\\n    </div>\\r\\n</div>\"}'),(11,11,'es','{\"column_1\": [{\"url\": \"https://plaza.redactivamexico.net/page/about-us\", \"title\": \"Acerca de Nosotros\", \"sort_order\": \"1\"}, {\"url\": \"https://plaza.redactivamexico.net/contact-us\", \"title\": \"Contáctenos\", \"sort_order\": \"2\"}, {\"url\": \"https://plaza.redactivamexico.net/page/customer-service\", \"title\": \"Servicio al Cliente\", \"sort_order\": \"3\"}, {\"url\": \"https://plaza.redactivamexico.net/page/whats-new\", \"title\": \"Novedades\", \"sort_order\": \"4\"}, {\"url\": \"https://plaza.redactivamexico.net/page/terms-of-use\", \"title\": \"Términos de Uso\", \"sort_order\": \"5\"}, {\"url\": \"https://plaza.redactivamexico.net/page/terms-conditions\", \"title\": \"Términos y Condiciones\", \"sort_order\": \"6\"}], \"column_2\": [{\"url\": \"https://plaza.redactivamexico.net/page/privacy-policy\", \"title\": \"Política de Privacidad\", \"sort_order\": \"1\"}, {\"url\": \"https://plaza.redactivamexico.net/page/payment-policy\", \"title\": \"Política de Pago\", \"sort_order\": \"2\"}, {\"url\": \"https://plaza.redactivamexico.net/page/shipping-policy\", \"title\": \"Política de Envío\", \"sort_order\": \"3\"}, {\"url\": \"https://plaza.redactivamexico.net/page/refund-policy\", \"title\": \"Política de Devolución\", \"sort_order\": \"4\"}, {\"url\": \"https://plaza.redactivamexico.net/page/return-policy\", \"title\": \"Política de Retorno\", \"sort_order\": \"5\"}], \"column_3\": [{\"url\": \"https://redactivamexico.net/\", \"title\": \"Red Activa México (Red Social)\", \"sort_order\": \"1\"}, {\"url\": \"https://redactivamexico.net/muro-loco\", \"title\": \"RAM Muro Loco\", \"sort_order\": \"2\"}, {\"url\": \"https://redactivamexico.net/maps\", \"title\": \"RAM Mapas\", \"sort_order\": \"3\"}, {\"url\": \"https://redactivamexico.net/iptv\", \"title\": \"RAM IPTV\", \"sort_order\": \"4\"}, {\"url\": \"https://redactivamexico.net/musica\", \"title\": \"RAM Música\", \"sort_order\": \"5\"}, {\"url\": \"https://redactivamexico.net/apps/skyverse/\", \"title\": \"RAM Skyverse\", \"sort_order\": \"6\"}]}'),(12,12,'es','{\"services\": [{\"title\": \"Envío gratuito\", \"description\": \"Envío gratuito en todos los pedidos\", \"service_icon\": \"icon-truck\"}, {\"title\": \"Reemplazo de producto\", \"description\": \"¡Reemplazo de producto sencillo disponible!\", \"service_icon\": \"icon-product\"}, {\"title\": \"EMI disponible\", \"description\": \"EMI sin costo disponible en todas las tarjetas de crédito comunes\", \"service_icon\": \"icon-dollar-sign\"}, {\"title\": \"Soporte 24/7\", \"description\": \"Soporte dedicado 24/7 por chat y correo electrónico\", \"service_icon\": \"icon-support\"}]}');
/*!40000 ALTER TABLE `theme_customization_translations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `theme_customizations`
--

DROP TABLE IF EXISTS `theme_customizations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `theme_customizations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `theme_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'default',
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `channel_id` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `theme_customizations_channel_id_foreign` (`channel_id`),
  CONSTRAINT `theme_customizations_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `theme_customizations`
--

LOCK TABLES `theme_customizations` WRITE;
/*!40000 ALTER TABLE `theme_customizations` DISABLE KEYS */;
INSERT INTO `theme_customizations` VALUES (1,'default','image_carousel','Carrusel de Imágenes',1,1,1,'2025-12-11 21:04:09','2025-12-28 01:46:59'),(2,'default','static_content','Información de Oferta',2,1,1,'2025-12-11 21:04:09','2026-01-03 10:06:36'),(3,'default','category_carousel','Colecciones de Categorías',3,1,1,'2025-12-11 21:04:09','2025-12-11 21:04:09'),(4,'default','product_carousel','Nuevos Productos',4,1,1,'2025-12-11 21:04:09','2025-12-11 21:04:09'),(5,'default','static_content','Explora RAM Plaza',5,1,1,'2025-12-11 21:04:09','2026-01-05 17:16:43'),(6,'default','static_content','Colecciones Audaces',6,1,1,'2025-12-11 21:04:09','2026-01-05 17:53:51'),(7,'default','product_carousel','Colecciones Destacadas',7,1,1,'2025-12-11 21:04:09','2025-12-11 21:04:09'),(8,'default','static_content','Nuevas adiciones',8,1,1,'2025-12-11 21:04:09','2026-01-05 17:50:00'),(9,'default','product_carousel','Todos los Productos',9,1,1,'2025-12-11 21:04:09','2025-12-11 21:04:09'),(10,'default','static_content','Colecciones Audaces',10,1,1,'2025-12-11 21:04:09','2026-01-05 17:55:02'),(11,'default','footer_links','Enlaces del Pie de Página',11,1,1,'2025-12-11 21:04:09','2025-12-29 12:06:31'),(12,'default','services_content','Contenido de Servicios',12,1,1,'2025-12-11 21:04:09','2025-12-11 21:04:09');
/*!40000 ALTER TABLE `theme_customizations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `url_rewrites`
--

DROP TABLE IF EXISTS `url_rewrites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `url_rewrites` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entity_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `request_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `url_rewrites_et_rp_lc_idx` (`entity_type`,`request_path`,`locale`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `url_rewrites`
--

LOCK TABLES `url_rewrites` WRITE;
/*!40000 ALTER TABLE `url_rewrites` DISABLE KEYS */;
INSERT INTO `url_rewrites` VALUES (1,'category','root','productos-ram','301','es','2025-12-12 13:10:12','2025-12-12 13:10:12');
/*!40000 ALTER TABLE `url_rewrites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visits`
--

DROP TABLE IF EXISTS `visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request` mediumtext COLLATE utf8mb4_unicode_ci,
  `url` mediumtext COLLATE utf8mb4_unicode_ci,
  `referer` mediumtext COLLATE utf8mb4_unicode_ci,
  `languages` text COLLATE utf8mb4_unicode_ci,
  `useragent` text COLLATE utf8mb4_unicode_ci,
  `headers` text COLLATE utf8mb4_unicode_ci,
  `device` text COLLATE utf8mb4_unicode_ci,
  `platform` text COLLATE utf8mb4_unicode_ci,
  `browser` text COLLATE utf8mb4_unicode_ci,
  `ip` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visitable_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visitable_id` bigint unsigned DEFAULT NULL,
  `visitor_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visitor_id` bigint unsigned DEFAULT NULL,
  `channel_id` int unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visits_visitable_type_visitable_id_index` (`visitable_type`,`visitable_id`),
  KEY `visits_visitor_type_visitor_id_index` (`visitor_type`,`visitor_id`),
  KEY `visits_cid_ip_m_vid_vt_ca_idx` (`channel_id`,`ip`,`method`,`visitor_id`,`visitor_type`,`created_at`),
  CONSTRAINT `visits_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visits`
--

LOCK TABLES `visits` WRITE;
/*!40000 ALTER TABLE `visits` DISABLE KEYS */;
/*!40000 ALTER TABLE `visits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlist`
--

DROP TABLE IF EXISTS `wishlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wishlist` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `channel_id` int unsigned NOT NULL,
  `product_id` int unsigned NOT NULL,
  `customer_id` int unsigned NOT NULL,
  `item_options` json DEFAULT NULL,
  `moved_to_cart` date DEFAULT NULL,
  `shared` tinyint(1) DEFAULT NULL,
  `time_of_moving` date DEFAULT NULL,
  `additional` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wishlist_channel_id_foreign` (`channel_id`),
  KEY `wishlist_product_id_foreign` (`product_id`),
  KEY `wishlist_customer_id_foreign` (`customer_id`),
  CONSTRAINT `wishlist_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wishlist_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wishlist_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlist`
--

LOCK TABLES `wishlist` WRITE;
/*!40000 ALTER TABLE `wishlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `wishlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlist_items`
--

DROP TABLE IF EXISTS `wishlist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wishlist_items` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `channel_id` int unsigned NOT NULL,
  `product_id` int unsigned NOT NULL,
  `customer_id` int unsigned NOT NULL,
  `additional` json DEFAULT NULL,
  `moved_to_cart` date DEFAULT NULL,
  `shared` tinyint(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `wishlist_items_channel_id_foreign` (`channel_id`),
  KEY `wishlist_items_product_id_foreign` (`product_id`),
  KEY `wishlist_items_customer_id_foreign` (`customer_id`),
  CONSTRAINT `wishlist_items_channel_id_foreign` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wishlist_items_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wishlist_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlist_items`
--

LOCK TABLES `wishlist_items` WRITE;
/*!40000 ALTER TABLE `wishlist_items` DISABLE KEYS */;
INSERT INTO `wishlist_items` VALUES (1,1,38,1,NULL,NULL,NULL,'2025-12-28 01:47:38','2025-12-28 01:47:38'),(2,1,46,1,NULL,NULL,NULL,'2025-12-28 01:47:40','2025-12-28 01:47:40'),(4,1,11,1,NULL,NULL,NULL,'2025-12-28 01:47:54','2025-12-28 01:47:54');
/*!40000 ALTER TABLE `wishlist_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-06 22:28:34
